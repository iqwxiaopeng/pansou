package com.iqw.eserver;

import com.iqw.eserver.config.MyProperties;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@ServletComponentScan
@EnableConfigurationProperties({MyProperties.class})
@EnableTransactionManagement
@SpringBootApplication
public class EserverApplication {

    public static void main(String[] args) {

        SpringApplication.run(EserverApplication.class, args);
    }

}

//目录树构建至关重要的一个

//{
//
//        "query": {
//        "bool": {
//        "must": [
//        {
//        "term": {
//        "keyword": "南方"
//        }
//        },
//        {
//        "term": {
//        "keyword": "蓝色"
//        }
//        }
//
//        ]
//        }
//        },
//        "aggs": {
//        "all_keyword":{
//        "terms":{"field":"keyword"}
//        }
//        }
//
//        }