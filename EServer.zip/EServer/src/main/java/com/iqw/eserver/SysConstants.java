package com.iqw.eserver;

public class SysConstants {

    //系统默认归类定义
    public static final String NOTE_BOOK = "NOTEBOOK"; //随笔默认文件夹


    public static final int VNODENUM_PERNODE = 10; //物理节点对应的虚拟节点数


    //文件类型枚举 将文件归为以下几类
    public static final int FILE_TYPE_DIRECTORY = 0; //目录类型文件
    public static final int FILE_TYPE_NOTE = 1;      //随笔类型文件
    public static final int FILE_TYPE_ZIP  = 2;      //压缩包类型文件
    public static final int FILE_TYPE_PIC  = 3;      //图片类型文件
    public static final int FILE_TYPE_BT   = 4;      //bt类型文件
    public static final int FILE_TYPE_PDF  = 5;      //PDF类型文件
    public static final int FILE_TYPE_WORD    = 6;      //文档类型文件
    public static final int FILE_TYPE_VIDEO   = 7;      //视频类型文件
    public static final int FILE_TYPE_MUSIC   = 8;      //音频类型文件
    public static final int FILE_TYPE_UNKNOWN = 9;      //未知类型文件





    //检索类型定义
    public static final int SEARCH_BY_NAME    = 0; //根据文件名检索
    public static final int SEARCH_BY_DESC    = 1; //根据描述信息检索
    public static final int SEARCH_BY_KEYWORD = 2; //根据关键词检索


    //t_pan_type 表
    public static final int PANFILETYPE_FILE     = 1;
    public static final int PANFILETYPE_ADDRESS  = 2;
    public static final int PANFILETYPE_CARD     = 3;
    public static final int PANFILETYPE_NOTE     = 4;
}
