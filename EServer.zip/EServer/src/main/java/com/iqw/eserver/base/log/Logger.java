package com.iqw.eserver.base.log;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.spi.AbstractLogger;
import org.apache.logging.log4j.spi.ExtendedLoggerWrapper;

 /**
 * 统一日志输出类
 *
 * @author tyd
 */
public class Logger extends ExtendedLoggerWrapper {
	private static final long serialVersionUID = 128227466514021L;
	private final ExtendedLoggerWrapper logger;

	private String FQCN = Logger.class.getName();
	private static final Level LF = Level.forName("fatal", 150);
	private static final Level LE = Level.forName("error", 250);
	private static final Level LW = Level.forName("warn", 350);
	private static final Level LI = Level.forName("info", 450);
	private static final Level LD = Level.forName("debug", 550);

	private Logger(final org.apache.logging.log4j.Logger logger) {
		super((AbstractLogger) logger, logger.getName(), logger.getMessageFactory());
		this.logger = this;
	}

	public static Logger getLogger() {
		String className = Thread.currentThread().getStackTrace()[3].getClassName();
		final org.apache.logging.log4j.Logger wrapped = LogManager.getLogger(className);
		return new Logger(wrapped);
	}

	public static void d(String msg) {
		getLogger().debug(msg);
	}

	public static void d(Object msg) {
		getLogger().debug(msg);
	}

	public static void d(String msg, Throwable t) {
		getLogger().debug(msg, t);
	}

	public static void d(Object msg, Throwable t) {
		getLogger().debug(msg, t);
	}

	public static void d(String msg, Object... params) {
		getLogger().debug(msg, params);
	}

	public static void i(String msg) {
		getLogger().info(msg);
	}

	public static void i(Object msg) {
		getLogger().info(msg);
	}

	public static void i(String msg, Throwable t) {
		getLogger().info(msg, t);
	}

	public static void i(Object msg, Throwable t) {
		getLogger().info(msg, t);
	}

	public static void i(String msg, Object... params) {
		getLogger().info(msg, params);
	}

	public static void w(String msg) {
		getLogger().warn(msg);
	}

	public static void w(Object msg) {
		getLogger().warn(msg);
	}

	public static void w(String msg, Throwable t) {
		getLogger().warn(msg, t);
	}

	public static void w(Object msg, Throwable t) {
		getLogger().warn(msg, t);
	}

	public static void w(String msg, Object... params) {
		getLogger().warn(msg, params);
	}

	public static void e(String msg) {
		getLogger().error(msg);
	}

	public static void e(Object msg) {
		getLogger().error(msg);
	}

	public static void e(String msg, Throwable t) {
		getLogger().error(msg, t);
	}

	public static void e(Object msg, Throwable t) {
		getLogger().error(msg, t);
	}

	public static void e(String msg, Object... params) {
		getLogger().error(msg, params);
	}

	public void debug(final Object message) {
		logger.logIfEnabled(FQCN, LD, null, message, (Throwable) null);
	}

	public void debug(final Object message, final Throwable t) {
		logger.logIfEnabled(FQCN, LD, null, message, t);
	}

	public void debug(final String message) {
		logger.logIfEnabled(FQCN, LD, null, message, (Throwable) null);
	}

	public void debug(final String message, final Object... params) {
		logger.logIfEnabled(FQCN, LD, null, message, params);
	}

	public void debug(final String message, final Throwable t) {
		logger.logIfEnabled(FQCN, LD, null, message, t);
	}

	public void warn(final Object message) {
		logger.logIfEnabled(FQCN, LW, null, message, (Throwable) null);
	}

	public void warn(final Object message, final Throwable t) {
		logger.logIfEnabled(FQCN, LW, null, message, t);
	}

	public void warn(final String message) {
		logger.logIfEnabled(FQCN, LW, null, message, (Throwable) null);
	}

	public void warn(final String message, final Object... params) {
		logger.logIfEnabled(FQCN, LW, null, message, params);
	}

	public void warn(final String message, final Throwable t) {
		logger.logIfEnabled(FQCN, LW, null, message, t);
	}

	public void info(final Object message) {
		logger.logIfEnabled(FQCN, LI, null, message, (Throwable) null);
	}

	public void info(final Object message, final Throwable t) {
		logger.logIfEnabled(FQCN, LI, null, message, t);
	}

	public void info(final String message) {
		logger.logIfEnabled(FQCN, LI, null, message, (Throwable) null);
	}

	public void info(final String message, final Object... params) {
		logger.logIfEnabled(FQCN, LI, null, message, params);
	}

	public void info(final String message, final Throwable t) {
		logger.logIfEnabled(FQCN, LI, null, message, t);
	}

	public void error(final Object message) {
		logger.logIfEnabled(FQCN, LE, null, message, (Throwable) null);
	}

	public void error(final Object message, final Throwable t) {
		logger.logIfEnabled(FQCN, LE, null, message, t);
	}

	public void error(final String message) {
		logger.logIfEnabled(FQCN, LE, null, message, (Throwable) null);
	}

	public void error(final String message, final Object... params) {
		logger.logIfEnabled(FQCN, LE, null, message, params);
	}

	public void error(final String message, final Throwable t) {
		logger.logIfEnabled(FQCN, LE, null, message, t);
	}

	public void fatal(final Object message) {
		logger.logIfEnabled(FQCN, LF, null, message, (Throwable) null);
	}

	public void fatal(final Object message, final Throwable t) {
		logger.logIfEnabled(FQCN, LF, null, message, t);
	}

	public void fatal(final String message) {
		logger.logIfEnabled(FQCN, LF, null, message, (Throwable) null);
	}

	public void fatal(final String message, final Object... params) {
		logger.logIfEnabled(FQCN, LF, null, message, params);
	}

	public void fatal(final String message, final Throwable t) {
		logger.logIfEnabled(FQCN, LF, null, message, t);
	}
}
