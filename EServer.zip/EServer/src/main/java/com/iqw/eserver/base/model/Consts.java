package com.iqw.eserver.base.model;

/**
 * 常用变量
 *
 */
public interface Consts {

    public static final String CHARTSET = "UTF-8";
    public static final String URL_LOGIN = "/login";
    public static final String SESSION_LOGIN = "SESSION_LOGIN";
    public static final String CONTENT_TYPE = "application/json;charset=UTF-8";

}
