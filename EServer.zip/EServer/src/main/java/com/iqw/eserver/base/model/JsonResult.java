package com.iqw.eserver.base.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.alibaba.fastjson.serializer.ValueFilter;


/**
 * 返回给前台的json结果
 */
public class JsonResult {

    /**
     * 构造函数
     */
    public JsonResult() {
        this.type = JsonResultType.ERROR;
    }

    /**
     * 构造函数
     * @param type 结果类型
     */
    public JsonResult(JsonResultType type) {
        this.setType(type);
    }

    /**
     * 设置结果类型
     * @param type
     */
    public void setType(JsonResultType type) {
        this.type = type;
        this.setMessage(type.toString());
    }

    /**
     * 获得结果类型
     * @return
     */
    public JsonResultType getType() {
        return type;
    }

    public String getMessage() {
        return message;
    }

    /**
     * 设置返回的消息
     * @param message
     */
    public JsonResult setMessage(String message) {
        this.message = message;
        return this;
    }

    /**
     * 增加传出的结果
     * @param key
     * @param value
     */
    public void add(String key, Object value) {
        if (this.items.containsKey(key)) {
            this.items.remove(key);
        }
        boolean bsuccess = false;
        if (value instanceof String) {
            String tmp = (String) value;
            try {
                if (tmp.startsWith("{") && tmp.endsWith("}")) {
                    JSONObject obj = JSONObject.parseObject(tmp);
                    this.items.put(key, obj);
                    bsuccess = true;
                } else if (tmp.startsWith("[") && tmp.endsWith("]")) {
                    JSONArray obj = JSONArray.parseArray(tmp);
                    this.items.put(key, obj);
                    bsuccess = true;
                }
            } catch (Exception e) {
            }
        }
        if (!bsuccess) {
            this.items.put(key, value);
        }
    }
    
    /**
     * 增加集合到集合中
     * @param data
     * @param total
     */
    public void add(List<?> data, int total) {
        this.add(TAGDATA, data);
        this.add("iTotalRecords", total);
        this.add("iTotalDisplayRecords", total);
    }
    
    /**
     * 增加单个数据对象到集合中
     * @param data
     */
    public void add(Object data) {
        this.add(TAGDATA, data);
    }

    /**
     * 移除传出的结果
     * @param key
     */
    public void remove(String key) {
        this.items.remove(key);
    }

    /**
     * 输出JSON
     * @return
     */
    public String toJSON() {
        this.items.put(TAGCODE, this.getType().getValue());
        if (type == JsonResultType.SESSIONTIMEOUT) {
            this.setMessage("Session timeout.");
            this.items.put(TAGURL, Consts.URL_LOGIN);
        }
        this.items.put(TAGMSG, this.getMessage());
        JSONObject json = new JSONObject();
        json.putAll(this.items);
        return JSONObject.toJSONString(json, JsonSerialize.instance(), filter, SerializerFeature.WriteNullStringAsEmpty, SerializerFeature.WriteNullListAsEmpty);
    }

    public String mapToJSON() {
        this.items.put(TAGCODE, this.getType().getValue());
        if (type == JsonResultType.SESSIONTIMEOUT) {
            this.setMessage("Session timeout.");
            this.items.put(TAGURL, Consts.URL_LOGIN);
        }
        this.items.put(TAGMSG, this.getMessage());
        JSONObject json = new JSONObject();
        json.putAll(this.items);
        return JSONObject.toJSONString(json);
    }

    public Object toJsonObj() {
        this.items.put(TAGCODE, this.getType().getValue());
        if (type == JsonResultType.SESSIONTIMEOUT) {
            this.setMessage("Session timeout.");
            this.items.put(TAGURL, Consts.URL_LOGIN);
        }
        this.items.put(TAGMSG, this.getMessage());
        JSONObject json = new JSONObject();
        json.putAll(this.items);
        return json;
    }

    /**
     * 处理空值
     */
    protected ValueFilter filter = new ValueFilter() {
        @Override
        public Object process(Object obj, String s, Object v) {
            return v == null ? "" : v;
        }
    };

    /**
     * 输出参数列表
     * @return
     */
    public Map<String, Object> getResult() {
        this.items.put(TAGCODE, this.getType().getValue());
        return items;
    }



    /**
     * 结果类型
     */
    protected JsonResultType type;
    protected String message = null;
    protected final static String TAGCODE = "code";
    protected final static String TAGMSG = "msg";
    protected final static String TAGDATA = "data";
    protected final static String TAGURL = "url";
    protected Map<String, Object> items = new HashMap<String, Object>();
}
