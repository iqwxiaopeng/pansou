package com.iqw.eserver.base.model;

import java.io.IOException;
import java.lang.reflect.Type;
import java.text.DecimalFormat;
import java.util.Date;

import com.alibaba.fastjson.serializer.DoubleSerializer;
import com.alibaba.fastjson.serializer.JSONSerializer;
import com.alibaba.fastjson.serializer.SerializeConfig;
import com.alibaba.fastjson.serializer.SerializeWriter;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.alibaba.fastjson.serializer.SimpleDateFormatSerializer;
import com.iqw.eserver.base.utils.DateTimeUtil;


/**
 * JSON序列，针对fastjson
 * @ClassName: JsonSerialize
 * @author tyd
 * @version 1.0.0
 */
public class JsonSerialize {
    private static SerializeConfig globalInstance = SerializeConfig.getGlobalInstance();
    static {
        // 配置需要序列的指定类
        globalInstance.put(Double.class, new DoubleSerializerConfig(new DecimalFormat("0.00")));
        globalInstance.put(Date.class, new SimpleDateFormatSerializer(DateTimeUtil.getDateTimePattern()));
    }

    public static SerializeConfig instance() {
        return globalInstance;
    }

    /**
     * Double格式保留两位小数点（0.00）
     */
    public static class DoubleSerializerConfig extends DoubleSerializer {
        public DoubleSerializerConfig(DecimalFormat decimalFormat) {
            this.decimalFormat = decimalFormat;
        }

        private DecimalFormat decimalFormat = null;

        public void write(JSONSerializer serializer, Object object, Object fieldName, Type fieldType, int features)
                throws IOException {
            SerializeWriter out = serializer.out;

            if (object == null) {
                out.writeNull(SerializerFeature.WriteNullNumberAsZero);
                return;
            }

            double doubleValue = ((Double) object).doubleValue();

            if (Double.isNaN(doubleValue) || Double.isInfinite(doubleValue)) {
                out.writeNull();
            } else {
                if (decimalFormat == null) {
                    out.writeDouble(doubleValue, true);
                } else {
                    String doubleText = decimalFormat.format(doubleValue);
                    out.write("\"" + doubleText + "\"");
                }
            }
        }
    }
}