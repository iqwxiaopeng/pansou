package com.iqw.eserver.base.utils;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.CharArrayWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.iqw.eserver.base.log.Logger;
import org.apache.commons.lang3.StringEscapeUtils;

/**
 * File Util
 * <ul>
 * Read or write file
 * <li>{@link #readFile(String)} read file</li>
 * <li>{@link #writeFile(String, String, boolean)} write file from String</li>
 * <li>{@link #writeFile(String, String)} write file from String</li>
 * <li>{@link #writeFile(String, List, boolean)} write file from String List</li>
 * <li>{@link #writeFile(String, List)} write file from String List</li>
 * <li>{@link #writeFile(String, InputStream)} write file</li>
 * <li>{@link #writeFile(String, InputStream, boolean)} write file</li>
 * <li>{@link #writeFile(File, InputStream)} write file</li>
 * <li>{@link #writeFile(File, InputStream, boolean)} write file</li>
 * </ul>
 * <ul>
 * Operate file
 * <li>{@link #copyFile(String, String)}</li>
 * <li>{@link #getFileExtension(String)}</li>
 * <li>{@link #getFileName(String)}</li>
 * <li>{@link #getFileNameWithoutExtension(String)}</li>
 * <li>{@link #getFileSize(String)}</li>
 * <li>{@link #deleteFile(String)}</li>
 * <li>{@link #isFileExist(String)}</li>
 * <li>{@link #isFolderExist(String)}</li>
 * <li>{@link #makeFolders(String)}</li>
 * <li>{@link #makeDirs(String)}</li>
 * </ul>
 *
 * @author
 */
public class FileUtil {

    public static final String FILE_EXTENSION_SEPARATOR = ".";
    public static final String PATH_SEPARATOR = "/";
    private static final String ENCODING = "UTF-8";

    private FileUtil() {

    }

    /**
     * 查找指定目录下指定后缀名的文件,无递归查询
     *
     * @param dirPath
     * @return
     */
    public static List<String> getFiles(String dirPath) {
        List<String> fileNames = new ArrayList<>();
        File directory = new File(dirPath);
        if (!directory.exists() || directory.isFile()) {
            return fileNames;
        } else {
            File[] children = directory.listFiles();
            for (File child : children) {
                fileNames.add(child.getAbsolutePath());
            }
            return fileNames;
        }
    }

    /**
     * 将源文件复制到目标文件
     *
     * @param srcFile  源文件的完整路径
     * @param destFile 目标文件的完整路径
     */
    public static void copyFile(File srcFile, File destFile) throws IOException {
        File outputFolder = destFile.getParentFile();
        if (!outputFolder.exists()) {
            outputFolder.mkdirs();
        }
        try (FileInputStream in = new FileInputStream(srcFile);
             FileOutputStream out = new FileOutputStream(destFile);
             BufferedInputStream bufferIn = new BufferedInputStream(in);
             BufferedOutputStream bufferOut = new BufferedOutputStream(out)) {
            byte[] b = new byte[1024];
            int i = 0;
            while ((i = bufferIn.read(b)) != -1) {
                bufferOut.write(b, 0, i);
            }
            bufferOut.flush();
            out.flush();
        }
    }

    /**
     * 拷贝srcPath目录下所有文件及子目录下的文件
     *
     * @param srcPath
     * @param destPath
     */
    public static void copyFiles(String srcPath, String destPath) {
        File srcFile = new File(srcPath);
        if (!srcFile.exists()) {
            return;
        }

        try {
            File destFile = new File(destPath);
            if (srcFile.isDirectory()) {
                if (!destFile.exists()) {
                    destFile.mkdirs();
                }
                for (File tmpFile : srcFile.listFiles()) {
                    if (tmpFile.isDirectory()) {
                        copyFiles(tmpFile.getAbsolutePath(), destPath + "/" + tmpFile.getName());
                    } else {
                        copyFile(tmpFile, new File(destPath, tmpFile.getName()));
                    }
                }
            } else {
                copyFile(srcFile, destFile);
            }
        } catch (Exception e) {
            Logger.e(e);
        }
    }

    /**
     * 剪切源文件到目标文件
     *
     * @param srcFile
     * @param destFile
     * @throws IOException
     */
    public static void cutFile(String srcFile, String destFile) throws IOException {
        copyFile(new File(srcFile), new File(destFile));
        Files.delete(Paths.get(srcFile));
    }

    /**
     * 得到文件的字节数组
     *
     * @param filePath
     * @return
     * @throws IOException
     */
    public static byte[] getFileByteArray(String filePath) throws IOException {
        if (!new File(filePath).exists()) {
            Logger.e("The file is not exist in specified file path! " + filePath);
            return new byte[0];
        }
        if (new File(filePath).isDirectory()) {
            Logger.e("The directory path is specified!" + filePath);
            return new byte[0];
        }
        byte[] result;
        try (ByteArrayOutputStream out = new ByteArrayOutputStream();
             InputStream in = new FileInputStream(filePath)) {
            byte[] b = new byte[1024];
            int i = 0;
            while ((i = in.read(b)) != -1) {
                out.write(b, 0, i);
            }
            result = out.toByteArray();
        }
        return result;
    }

    /**
     * 将字节数组写入文件
     *
     * @param buffer
     * @param filePath
     * @param append
     * @throws IOException
     */
    public static void writeByteArrayToFile(byte[] buffer, String filePath, boolean append) throws IOException {
        File file = new File(filePath);
        if (!file.getParentFile().exists()) {
            file.getParentFile().mkdirs();
        }
        try (OutputStream out = new FileOutputStream(file, append);
             BufferedOutputStream bufferOut = new BufferedOutputStream(out);) {
            bufferOut.write(buffer);
            bufferOut.flush();
        }
    }

    /**
     * 读取文件内容
     *
     * @param fileName
     * @return
     */
    public static String readFile(String fileName) {
        StringBuilder sb = new StringBuilder();
        File file = new File(fileName);
        if (file.exists()) {
            try (FileInputStream input = new FileInputStream(file);
                 InputStreamReader read = new InputStreamReader(input, ENCODING);
                 BufferedReader buf = new BufferedReader(read)) {
                String lineTxt;
                while ((lineTxt = buf.readLine()) != null) {
                    sb.append(lineTxt + "\r\n");
                }
            } catch (Exception ex) {
                Logger.e(ex);
            }
        }
        return sb.toString().trim();
    }

    /**
     * read file
     *
     * @param filePath
     * @param charsetName The name of a supported {@link java.nio.charset.Charset <code>charset</code>}
     * @return if file not exist, return null, else return content of file
     * @throws RuntimeException if an error occurs while operator BufferedReader
     */
    public static StringBuilder readFile(String filePath, String charsetName) {
        File file = new File(filePath);
        StringBuilder fileContent = new StringBuilder();
        if (!file.isFile()) {
            return null;
        }
        try (InputStreamReader is = new InputStreamReader(new FileInputStream(file), charsetName);
             BufferedReader reader = new BufferedReader(is)) {
            String line = null;
            while ((line = reader.readLine()) != null) {
                if (!fileContent.toString().equals("")) {
                    fileContent.append("\r\n");
                }
                fileContent.append(line);
            }
        } catch (IOException e) {
            Logger.e(e);
        }
        return fileContent;
    }

    /**
     * write file
     *
     * @param filePath
     * @param content
     * @param append   is append, if true, write to the end of file, else clear content of file and write into it
     * @return return false if content is empty, true otherwise
     * @throws RuntimeException if an error occurs while operator FileWriter
     */
    public static boolean writeFile(String filePath, String content, boolean append) {
        if (StringUtil.isEmpty(content)) {
            return false;
        }
        File file = new File(filePath);
        File dir = new File(file.getParent());
        if (!dir.exists()) {
            dir.mkdirs();
        }
        try (FileOutputStream fs = new FileOutputStream(filePath, append);
             OutputStreamWriter out = new OutputStreamWriter(fs, ENCODING)) {
            out.write(content);
            out.flush();
            fs.flush();
            out.close();
            fs.close();
            return true;
        } catch (IOException e) {
            Logger.e(e);
        }
        return false;
    }

    /**
     * write file
     *
     * @param filePath
     * @param contentList
     * @param append      is append, if true, write to the end of file, else clear content of file and write into it
     * @return return false if contentList is empty, true otherwise
     * @throws RuntimeException if an error occurs while operator FileWriter
     */
    public static boolean writeFile(String filePath, List<String> contentList, boolean append) {
        if (ListUtil.isEmpty(contentList)) {
            return false;
        }
        makeDirs(filePath);
        try (FileWriter fileWriter = new FileWriter(filePath, append)) {
            int i = 0;
            for (String line : contentList) {
                if (i++ > 0) {
                    fileWriter.write("\r\n");
                }
                fileWriter.write(line);
            }
            return true;
        } catch (IOException e) {
            Logger.e(e);
        }
        return false;
    }

    /**
     * write file, the string will be written to the begin of the file
     *
     * @param filePath
     * @param content
     * @return
     */
    public static boolean writeFile(String filePath, String content) {
        return writeFile(filePath, content, false);
    }

    /**
     * write file, the string list will be written to the begin of the file
     *
     * @param filePath
     * @param contentList
     * @return
     */
    public static boolean writeFile(String filePath, List<String> contentList) {
        return writeFile(filePath, contentList, false);
    }

    /**
     * write file, the bytes will be written to the begin of the file
     *
     * @param filePath
     * @param stream
     * @return
     * @see {@link #writeFile(String, InputStream, boolean)}
     */
    public static boolean writeFile(String filePath, InputStream stream) {
        return writeFile(filePath, stream, false);
    }

    /**
     * write file
     *
     * @param filePath the file to be opened for writing.
     * @param stream   the input stream
     * @param append   if <code>true</code>, then bytes will be written to the end of the file rather than the beginning
     * @return return true
     * @throws RuntimeException if an error occurs while operator FileOutputStream
     */
    public static boolean writeFile(String filePath, InputStream stream, boolean append) {
        return writeFile(new File(filePath), stream, append);
    }

    /**
     * write file, the bytes will be written to the begin of the file
     *
     * @param file
     * @param stream
     * @return
     * @see {@link #writeFile(File, InputStream, boolean)}
     */
    public static boolean writeFile(File file, InputStream stream) {
        return writeFile(file, stream, false);
    }

    /**
     * write file
     *
     * @param file   the file to be opened for writing.
     * @param stream the input stream
     * @param append if <code>true</code>, then bytes will be written to the end of the file rather than the beginning
     * @return return true
     * @throws RuntimeException if an error occurs while operator FileOutputStream
     */
    public static boolean writeFile(File file, InputStream stream, boolean append) {
        makeDirs(file.getAbsolutePath());
        try (OutputStream o = new FileOutputStream(file, append)) {
            byte[] data = new byte[1024];
            int length = -1;
            while ((length = stream.read(data)) != -1) {
                o.write(data, 0, length);
            }
            o.flush();
            return true;
        } catch (IOException e) {
            Logger.e(e);
        }
        return false;
    }

    /**
     * copy file
     *
     * @param sourceFilePath
     * @param destFilePath
     * @return
     * @throws RuntimeException if an error occurs while operator FileOutputStream
     */
    public static boolean copyFile(String sourceFilePath, String destFilePath) {
        InputStream inputStream = null;
        try {
            inputStream = new FileInputStream(sourceFilePath);
        } catch (FileNotFoundException e) {
            Logger.e(e);
        }
        return writeFile(destFilePath, inputStream);
    }

    /**
     * read file to string list, a element of list is a line
     *
     * @param filePath
     * @param charsetName The name of a supported {@link java.nio.charset.Charset <code>charset</code>}
     * @return if file not exist, return null, else return content of file
     * @throws RuntimeException if an error occurs while operator BufferedReader
     */
    public static List<String> readFileToList(String filePath, String charsetName) {
        File file = new File(filePath);
        List<String> fileContent = new ArrayList<>();
        if (!file.isFile()) {
            return fileContent;
        }
        try (InputStreamReader is = new InputStreamReader(new FileInputStream(file), charsetName);
             BufferedReader reader = new BufferedReader(is)) {
            String line;
            while ((line = reader.readLine()) != null) {
                fileContent.add(line);
            }
        } catch (IOException e) {
            Logger.e(e);
        }
        return fileContent;
    }

    /**
     * get file name from path, not include suffix
     *
     * <pre>
     *      getFileNameWithoutExtension(null)               =   null
     *      getFileNameWithoutExtension("")                 =   ""
     *      getFileNameWithoutExtension("   ")              =   "   "
     *      getFileNameWithoutExtension("abc")              =   "abc"
     *      getFileNameWithoutExtension("a.mp3")            =   "a"
     *      getFileNameWithoutExtension("a.b.rmvb")         =   "a.b"
     *      getFileNameWithoutExtension("c:\\")              =   ""
     *      getFileNameWithoutExtension("c:\\a")             =   "a"
     *      getFileNameWithoutExtension("c:\\a.b")           =   "a"
     *      getFileNameWithoutExtension("c:a.txt\\a")        =   "a"
     *      getFileNameWithoutExtension("/home/admin")      =   "admin"
     *      getFileNameWithoutExtension("/home/admin/a.txt/b.mp3")  =   "b"
     * </pre>
     *
     * @param filePath
     * @return file name from path, not include suffix
     * @see
     */
    public static String getFileNameWithoutExtension(String filePath) {
        if (StringUtil.isEmpty(filePath)) {
            return filePath;
        }

        int extenPosi = filePath.lastIndexOf(FILE_EXTENSION_SEPARATOR);
        int filePosi = filePath.lastIndexOf(File.separator);
        if (filePosi == -1) {
            return (extenPosi == -1 ? filePath : filePath.substring(0, extenPosi));
        }
        if (extenPosi == -1) {
            return filePath.substring(filePosi + 1);
        }
        return (filePosi < extenPosi ? filePath.substring(filePosi + 1, extenPosi)
                : filePath.substring(filePosi + 1));
    }

    /**
     * get file name from path, include suffix
     *
     * <pre>
     *      getFileName(null)               =   null
     *      getFileName("")                 =   ""
     *      getFileName("   ")              =   "   "
     *      getFileName("a.mp3")            =   "a.mp3"
     *      getFileName("a.b.rmvb")         =   "a.b.rmvb"
     *      getFileName("abc")              =   "abc"
     *      getFileName("c:\\")              =   ""
     *      getFileName("c:\\a")             =   "a"
     *      getFileName("c:\\a.b")           =   "a.b"
     *      getFileName("c:a.txt\\a")        =   "a"
     *      getFileName("/home/admin")      =   "admin"
     *      getFileName("/home/admin/a.txt/b.mp3")  =   "b.mp3"
     * </pre>
     *
     * @param filePath
     * @return file name from path, include suffix
     */
    public static String getFileName(String filePath) {
        if (StringUtil.isEmpty(filePath)) {
            return filePath;
        }

        int filePosi = filePath.lastIndexOf(File.separator);
        return (filePosi == -1) ? filePath : filePath.substring(filePosi + 1);
    }

    /**
     * get folder name from path
     *
     * <pre>
     *      getFolderName(null)               =   null
     *      getFolderName("")                 =   ""
     *      getFolderName("   ")              =   ""
     *      getFolderName("a.mp3")            =   ""
     *      getFolderName("a.b.rmvb")         =   ""
     *      getFolderName("abc")              =   ""
     *      getFolderName("c:\\")              =   "c:"
     *      getFolderName("c:\\a")             =   "c:"
     *      getFolderName("c:\\a.b")           =   "c:"
     *      getFolderName("c:a.txt\\a")        =   "c:a.txt"
     *      getFolderName("c:a\\b\\c\\d.txt")    =   "c:a\\b\\c"
     *      getFolderName("/home/admin")      =   "/home"
     *      getFolderName("/home/admin/a.txt/b.mp3")  =   "/home/admin/a.txt"
     * </pre>
     *
     * @param filePath
     * @return
     */
    public static String getFolderName(String filePath) {

        if (StringUtil.isEmpty(filePath)) {
            return filePath;
        }

        int filePosi = filePath.lastIndexOf(File.separator);
        return (filePosi == -1) ? "" : filePath.substring(0, filePosi);
    }

    /**
     * get suffix of file from path
     *
     * <pre>
     *      getFileExtension(null)               =   ""
     *      getFileExtension("")                 =   ""
     *      getFileExtension("   ")              =   "   "
     *      getFileExtension("a.mp3")            =   "mp3"
     *      getFileExtension("a.b.rmvb")         =   "rmvb"
     *      getFileExtension("abc")              =   ""
     *      getFileExtension("c:\\")              =   ""
     *      getFileExtension("c:\\a")             =   ""
     *      getFileExtension("c:\\a.b")           =   "b"
     *      getFileExtension("c:a.txt\\a")        =   ""
     *      getFileExtension("/home/admin")      =   ""
     *      getFileExtension("/home/admin/a.txt/b")  =   ""
     *      getFileExtension("/home/admin/a.txt/b.mp3")  =   "mp3"
     * </pre>
     *
     * @param filePath
     * @return
     */
    public static String getFileExtension(String filePath) {
        if (StringUtil.isBlank(filePath)) {
            return filePath;
        }

        int extenPosi = filePath.lastIndexOf(FILE_EXTENSION_SEPARATOR);
        int filePosi = filePath.lastIndexOf(File.separator);
        if (extenPosi == -1) {
            return "";
        }
        return (filePosi >= extenPosi) ? "" : filePath.substring(extenPosi + 1);
    }

    /**
     * Creates the directory named by the trailing filename of this file, including the complete directory path required
     * to create this directory. <br/>
     * <br/>
     * <ul>
     * <strong>Attentions:</strong>
     * <li>makeDirs("C:\\Users\\Trinea") can only create users folder</li>
     * <li>makeFolder("C:\\Users\\Trinea\\") can create Trinea folder</li>
     * </ul>
     *
     * @param filePath
     * @return true if the necessary directories have been created or the target directory already exists, false one of
     * the directories can not be created.
     * <ul>
     * <li>if {@link FileUtil#getFolderName(String)} return null, return false</li>
     * <li>if target directory already exists, return true</li>
     * <li>return boolean</li>
     * </ul>
     */
    public static boolean makeDirs(String filePath) {
        String folderName = getFolderName(filePath);
        if (StringUtil.isEmpty(folderName)) {
            return false;
        }

        File folder = new File(folderName);
        if (folder.exists() && folder.isDirectory()) {
            return true;
        } else {
            return folder.mkdirs();
        }
    }

    /**
     * @param filePath
     * @return
     * @see #makeDirs(String)
     */
    public static boolean makeFolders(String filePath) {
        return makeDirs(filePath);
    }

    /**
     * Indicates if this file represents a file on the underlying file system.
     *
     * @param filePath
     * @return
     */
    public static boolean isFileExist(String filePath) {
        if (StringUtil.isBlank(filePath)) {
            return false;
        }

        File file = new File(filePath);
        return (file.exists() && file.isFile());
    }

    /**
     * Indicates if this file represents a directory on the underlying file system.
     *
     * @param directoryPath
     * @return
     */
    public static boolean isFolderExist(String directoryPath) {
        if (StringUtil.isBlank(directoryPath)) {
            return false;
        }

        File dire = new File(directoryPath);
        return (dire.exists() && dire.isDirectory());
    }

    /**
     * delete file or directory
     * <ul>
     * <li>if path is null or empty, return true</li>
     * <li>if path not exist, return true</li>
     * <li>if path exist, delete recursion. return true</li>
     * </ul>
     *
     * @param path
     */
    public static void deleteFile(String path) throws IOException {
        if (StringUtil.isBlank(path)) {
            return;
        }
        File file = new File(path);
        if (!file.exists()) {
            return;
        }
        if (file.isFile()) {
            if(!file.delete()) {
                Logger.e("delete file fail");
            }
            return;
        }
        for (File f : file.listFiles()) {
            if (f.isFile()) {
                Files.delete(Paths.get(f.getPath()));
            } else if (f.isDirectory()) {
                deleteFile(f.getAbsolutePath());
            }
        }
        Files.delete(Paths.get(path));
    }

    /**
     * get file size
     * <ul>
     * <li>if path is null or empty, return -1</li>
     * <li>if path exist and it is a file, return file size, else return -1</li>
     * </ul>
     *
     * @param path
     * @return returns the length of this file in bytes. returns -1 if the file does not exist.
     */
    public static long getFileSize(String path) {
        if (StringUtil.isBlank(path)) {
            return -1;
        }

        File file = new File(path);
        return (file.exists() && file.isFile() ? file.length() : -1);
    }

    /**
     * 刪除文件夾
     *
     * @param folderPath
     */
    public static void deleteFolder(String folderPath) {
        try {
            // 删除完里面所有内容
            deleteFile(folderPath);

            //删除目录
            File file = new File(folderPath);
            if (!file.delete()) {
                Logger.e("delete file fail");
            }
        } catch (Exception e) {
            Logger.e(e);
        }
    }

    /**
     * 创建文件
     *
     * @throws IOException
     */
    public static boolean creatTxtFile(File file) {
        boolean flag = false;
        try {
            if (!file.exists()) {
                if (file.createNewFile()) {
                    flag = true;
                }
            } else {
                flag = true;
            }
        } catch (IOException e) {
            Logger.e(e);
        }
        return flag;
    }

    /**
     * 写文件
     *
     * @param newStr 新内容
     * @throws IOException
     */
    public static boolean writeTxtFile(File file, String newStr) throws IOException {
        // 先读取原有文件内容，然后进行写入操作
        boolean flag = false;
        String filein = newStr + "\r\n";
        String temp = "";
        StringBuilder buf = new StringBuilder();
        try (FileInputStream fis = new FileInputStream(file);
             InputStreamReader isr = new InputStreamReader(fis);
             BufferedReader br = new BufferedReader(isr)) {
            while ((temp = br.readLine()) != null) {
                buf = buf.append(temp);
                // 行与行之间的分隔符 相当于“\n”
                buf = buf.append(System.getProperty("line.separator"));
            }
            buf.append(filein);
        }
        try (FileOutputStream fos = new FileOutputStream(file);
             PrintWriter pw = new PrintWriter(fos)) {
            pw.write(buf.toString().toCharArray());
            pw.flush();
            flag = true;
        }
        return flag;
    }

    public static char[] loadFile(String file) throws IOException {
        char[] buffer = new char[16 * 1024]; // 16k buffer
        int read;
        try (UnicodeReader r = new UnicodeReader(new FileInputStream(file), null);
             BufferedReader reader = new BufferedReader(r);
             CharArrayWriter writer = new CharArrayWriter();) {

            while ((read = reader.read(buffer)) != -1) {
                writer.write(buffer, 0, read);
            }
            writer.flush();
            return writer.toCharArray();
        }
    }

    /**
     * Save text file as UTF-8 with BOM.
     *
     * @param file   filename
     * @param data   data to be written
     * @param append true, append to existing file. false, overwrite file
     */
    public static void saveFile(String file, String data, boolean append) throws IOException {
        File f = new File(file);
        try (FileOutputStream fos = new FileOutputStream(f, append);
             OutputStreamWriter osw = new OutputStreamWriter(fos, ENCODING);
             BufferedWriter bw = new BufferedWriter(osw)) {
            // write UTF8 BOM mark if file is empty
            if (f.length() < 1) {
                final byte[] bom = new byte[]{(byte) 0xEF, (byte) 0xBB, (byte) 0xBF};
                fos.write(bom);
            }
            if (data != null) {
                bw.write(data);
            }
        }
    }

    /**
     * Load unicode properties file.
     *
     * @param file filename
     */
    public static Map<String, String> loadProperties(String file) throws IOException {
        HashMap<String, String> map = new HashMap<>();
        try (UnicodeReader r = new UnicodeReader(new FileInputStream(file), null);
             BufferedReader reader = new BufferedReader(r)) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.equals("")) {
                    continue; // empty line
                }
                int idx = line.indexOf('=');
                if (idx < 1) {
                    continue; // no name=value pair
                }
                String key = line.substring(0, idx).trim();
                if (key.charAt(0) == '#') {
                    continue; // comment line
                }
                String val = line.substring(idx + 1).trim();

                map.put(key, val);
            }
        }
        return map;
    }

    /**
     * Save properties as UTF-8 with BOM file.
     *
     * @param file  filename
     * @param title title row is written to start of file, or null
     * @param props properties
     */
    public static void saveProperties(String file, String title, Map<?, ?> props) throws IOException {
        final char[] newline = System.getProperty("line.separator").toCharArray();
        File f = new File(file);
        try (FileOutputStream fos = new FileOutputStream(f, false);
             OutputStreamWriter osw = new OutputStreamWriter(fos, ENCODING);
             BufferedWriter bw = new BufferedWriter(osw)) {
            // write UTF8 BOM mark
            final byte[] bom = new byte[]{(byte) 0xEF, (byte) 0xBB, (byte) 0xBF};
            fos.write(bom);
            if (title != null) {
                title = "## " + title;
                osw.write(title.toCharArray(), 0, title.length());
                osw.write(newline, 0, newline.length);
            }
            Iterator<?> iter = props.entrySet().iterator();
            while (iter.hasNext()) {
                Map.Entry<?, ?> entry = (Map.Entry<?, ?>) iter.next();
                String key = (String) entry.getKey();
                String val = (String) entry.getValue();
                osw.write(key.toCharArray(), 0, key.length());
                osw.write('=');
                if (val.length() > 0) {
                    osw.write(val.toCharArray(), 0, val.length());
                }
                osw.write(newline, 0, newline.length);
            }
        }
    }

    /**
     * 去掉fileName中的不合法字符\/:*?<>|
     * 同时对html转义符号进行反转义
     *
     * @param fileName
     * @return
     */
//    public static String escapeFileName(String fileName) {
//        if (StringUtil.isNullOrEmpty(fileName)) {
//            return fileName;
//        }
//
//        Pattern pattern = Pattern.compile("[\\s\\\\/:\\*\\?\\\"<>\\|]");
//        Matcher matcher = pattern.matcher(fileName);
//
//        fileName = matcher.replaceAll(""); // 将匹配到的非法字符以空替换
//
//        return StringEscapeUtils.unescapeHtml(fileName);
//    }


    /**
     * 发起http请求获取返回结果
     *
     * @param reqUrl 请求地址
     * @return
     */
    public static String httpRequest(String reqUrl) {
        StringBuilder buffer = new StringBuilder();
        try {
            URL url = new URL(reqUrl);
            HttpURLConnection httpUrlConn = (HttpURLConnection) url.openConnection();
            httpUrlConn.setDoOutput(false);
            httpUrlConn.setDoInput(true);
            httpUrlConn.setUseCaches(false);

            httpUrlConn.setRequestMethod("GET");
            httpUrlConn.connect();

            // 将返回的输入流转换成字符串  
            InputStream inputStream = httpUrlConn.getInputStream();
            InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "utf-8");
            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

            String str = null;
            while ((str = bufferedReader.readLine()) != null) {
                buffer.append(str);
            }
            bufferedReader.close();
            inputStreamReader.close();
            // 释放资源  
            inputStream.close();
            httpUrlConn.disconnect();

        } catch (Exception e) {
            Logger.e(e);
        }
        return buffer.toString();
    }

    /**
     * 统一不同系统的路径
     * @param filePath
     * @return
     */
    public static String unifyFilePath(String filePath) {
        if (StringUtil.isNullOrEmpty(filePath)) {
            return filePath;
        }
        return filePath.replace('\\', '/');

    }

    /**
     * 合并文件路径和文件名 返回合并后的文件路径
     * @param filePath 文件所在目录
     * @param fileName 文件名
     * @return
     */
    public static String getFilePathName(String filePath, String fileName) {
        filePath = unifyFilePath(filePath);
        return filePath + "/" + fileName;
    }

    /**
     * 合并文件路径和文件名 返回合并后的文件路径
     * @param filePath 文件所在目录
     * @param fileName 文件名
     * @param fileExt 文件后缀
     * @return
     */
    public static String getFilePathName(String filePath, String fileName, String fileExt) {
        filePath = unifyFilePath(filePath);
        if(StringUtil.isNullOrEmpty(fileExt)){
            return filePath + "/" + fileName;
        }
        return filePath + "/" + fileName + "."+fileExt;
    }


    public static List<String> splitPathAndName(String filePath) {
        if (StringUtil.isEmpty(filePath)) {
            return null;
        }

        int splitPosi = filePath.lastIndexOf(PATH_SEPARATOR);

        String path = "";
        if (splitPosi == 0){
            path = PATH_SEPARATOR;
        }else
        {
            path = filePath.substring(0, splitPosi);
        }
        String name = filePath.substring(splitPosi + 1);

        List<String> strList = new ArrayList<>();
        strList.add(path);
        strList.add(name);
        return strList;
    }



    /**
     * 保证路径存在
     * @param filePath
     * @return
     */
//    public static boolean ensureFilePath(String filePath) {
//        File fd = null;
//        try {
//            fd = new File(filePath);
//            if (!fd.exists()) {
//                fd.mkdirs();
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//            return false;
//        } finally {
//            fd = null;
//        }
//        return true;
//    }

}
