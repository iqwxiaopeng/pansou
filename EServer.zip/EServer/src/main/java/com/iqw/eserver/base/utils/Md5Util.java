package com.iqw.eserver.base.utils;

import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;


public class Md5Util {


    public static String GetBytesMd5(byte[] data){
        return DigestUtils.md5Hex(data);
    }

    public static String GetStringMd5(String data){
        return DigestUtils.md5Hex(data);
    }

    public static String GetFileMd5(File file){

        FileInputStream inputStream = null;
        try {
            String md5 = "";
            inputStream = new FileInputStream(file);
            md5= DigestUtils.md5Hex(inputStream);
            inputStream.close();
            return md5;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "";
    }

    public static String GetFileMd5(String filePath){
        FileInputStream inputStream = null;
        try {
            String md5 = "";
            inputStream = new FileInputStream(filePath);
            md5= DigestUtils.md5Hex(inputStream);
            inputStream.close();
            return md5;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "";
    }


    /**
     * 获取上传文件的md5
     * @param file
     * @return
     * @throws IOException
     */
    public static String GetFileMd5(MultipartFile file) {
        try {

            String md5 = DigestUtils.md5Hex(file.getInputStream());
            return md5;
        } catch (Exception e) {
           e.printStackTrace();
        }
        return null;
    }

}
