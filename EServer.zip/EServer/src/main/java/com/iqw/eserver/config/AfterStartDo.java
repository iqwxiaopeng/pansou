package com.iqw.eserver.config;

import com.iqw.eserver.SysConstants;
import com.iqw.eserver.config.security.token.TokenUtil;


import com.iqw.eserver.modules.es.entity.EsFile;
import com.iqw.eserver.modules.es.entity.EsNote;
import com.iqw.eserver.modules.es.mapper.EsDaoUtil;
import jdk.nashorn.internal.parser.Token;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class AfterStartDo implements CommandLineRunner {

    @Autowired
    private MyProperties myProperties;

    @Autowired
    private EsDaoUtil esDaoUtil;




    //https://github.com/bytefish/ElasticUtils



    @Override
    public void run(String... args) throws Exception {
        System.out.println("正在检查并创建ES检索表.....");
        EsFile item = new EsFile();
        boolean haveTable = esDaoUtil.IsTableExist(item);
        if (haveTable == false){
            esDaoUtil.Create(item);
        }

        EsNote note = new EsNote();
        haveTable = esDaoUtil.IsTableExist(note);
        if (haveTable == false){
            esDaoUtil.Create(note);
        }

        //token过期时间设置
        TokenUtil.SetAuthCfg(myProperties);

    }


}
