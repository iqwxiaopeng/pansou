package com.iqw.eserver.config;
/**
 * 解决跨域请求的
 */

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;

@Configuration
public class CorsConfig {

    private CorsConfiguration buildConfig() {
        CorsConfiguration corsConfiguration = new CorsConfiguration();
        //  你需要跨域的地址  注意这里的 127.0.0.1 != localhost
        // * 表示对所有的地址都可以访问
        // corsConfiguration.addAllowedOrigin("http://localhost:3030");
        corsConfiguration.addAllowedOrigin("*"); // 1允许任何域名使用
        //  跨域的请求头
        corsConfiguration.addAllowedHeader("*"); // 2允许任何头
        //  跨域的请求方法
        corsConfiguration.addAllowedMethod("*"); // 3允许任何方法（post、get等）
        //加上了这一句，大致意思是可以携带 cookie
        //最终的结果是可以 在跨域请求的时候获取同一个 session
        corsConfiguration.setAllowCredentials(true);

        return corsConfiguration;
    }

    @Bean
    public CorsFilter corsFilter() {
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", buildConfig()); // 4配置 可以访问的地址
        return new CorsFilter(source);
    }

}



