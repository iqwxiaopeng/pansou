package com.iqw.eserver.config.security;



import com.iqw.eserver.base.model.JsonResult;
import com.iqw.eserver.base.model.JsonResultType;
import com.iqw.eserver.config.security.token.TokenUtil;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.security.web.authentication.logout.LogoutSuccessHandler;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;


@Configuration
public class SecurityHandlerConfig {

	public static void ResponseJson(HttpServletResponse response, int status, String data) {
		try {
//			response.setCharacterEncoding("UTF-8");
//			response.setContentType("application/json");
			response.setHeader("Access-Control-Allow-Origin", "*");
			response.setHeader("Access-Control-Allow-Methods", "*");
			response.setContentType("application/json;charset=UTF-8");
			response.setStatus(status);

			response.getWriter().write(data);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 登陆成功，返回Token
	 *
	 * @return
	 */
	@Bean
	public AuthenticationSuccessHandler loginSuccessHandler() {
		return new AuthenticationSuccessHandler() {

			@Override
			public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response,
                                                Authentication authentication) throws IOException, ServletException {

				String token = TokenUtil.createToken(authentication);
				JsonResult jsonResult = new JsonResult(JsonResultType.SUCCESS);
				jsonResult.setMessage("登录成功");
				jsonResult.add(token);
				
				ResponseJson(response,HttpStatus.OK.value(), jsonResult.toJSON());
			    System.out.println("登录成功回调 token="+token);
			}
		};
	}

	/**
	 * 登陆失败
	 *
	 * @return
	 */
	@Bean
	public AuthenticationFailureHandler loginFailureHandler() {
		return new AuthenticationFailureHandler() {

			@Override
			public void onAuthenticationFailure(HttpServletRequest request, HttpServletResponse response,
                                                AuthenticationException exception) throws IOException, ServletException {
				JsonResult jsonResult = new JsonResult(JsonResultType.ERROR);
				jsonResult.setMessage("登录失败");

				ResponseJson(response,HttpStatus.OK.value(), jsonResult.toJSON());
                System.out.println("登录失败回调");
			}
		};

	}

	/**
	 * 未登录，返回401
	 *
	 * @return
	 */
	@Bean
	public AuthenticationEntryPoint authenticationEntryPoint() {
		return new AuthenticationEntryPoint() {

			@Override
			public void commence(HttpServletRequest request, HttpServletResponse response,
                                 AuthenticationException authException) throws IOException, ServletException {

				JsonResult jsonResult = new JsonResult(JsonResultType.NOLOGIN);
				if (authException instanceof BadCredentialsException){
					jsonResult.setMessage(authException.getMessage());

				}else {
					jsonResult.setMessage("请先登录");
				}


				ResponseJson(response,HttpStatus.UNAUTHORIZED.value(), jsonResult.toJSON());

                System.out.println("未有登录回调");
			}
		};
	}

	/**
	 * 退出处理
	 *
	 * @return
	 */
	@Bean
	public LogoutSuccessHandler logoutSussHandler() {
		return new LogoutSuccessHandler() {

			@Override
			public void onLogoutSuccess(HttpServletRequest request, HttpServletResponse response,
                                        Authentication authentication) throws IOException, ServletException {
				System.out.println("退出登录回调");
			}
		};

	}

	/**
	 * 拒绝访问
	 *
	 * @return
	 */
	@Bean
	public AccessDeniedHandler accessDeniedHandler() {
		return new AccessDeniedHandler() {

			@Override
			public void handle(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, AccessDeniedException e) throws IOException, ServletException {

				JsonResult jsonResult = new JsonResult(JsonResultType.SUCCESS);
				jsonResult.setMessage("请联系管理员获取访问权限");

				ResponseJson(httpServletResponse, HttpStatus.FORBIDDEN.value(), jsonResult.toJSON());
			}
		};

	}

}
