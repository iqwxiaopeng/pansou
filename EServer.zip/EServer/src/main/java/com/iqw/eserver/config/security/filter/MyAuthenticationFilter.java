package com.iqw.eserver.config.security.filter;



import com.iqw.eserver.base.utils.StringUtil;
import com.iqw.eserver.config.Constants;
import com.iqw.eserver.config.MyProperties;
import com.iqw.eserver.config.security.token.TokenUtil;
import io.jsonwebtoken.Claims;
import org.luaj.vm2.ast.Str;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * <p> 访问鉴权 - 每次访问接口都会经过此 </p>
 *
 * @author : zhengqing
 * @description :
 * @date : 2019/10/12 16:17
 */
@Component
public class MyAuthenticationFilter extends OncePerRequestFilter {

    @Autowired
    private MyProperties myProperties;

    @Autowired
    private AuthenticationEntryPoint authenticationEntryPoint;

    protected MyAuthenticationFilter() {

    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {

        String token = request.getHeader(Constants.REQUEST_HEADER);
        if (StringUtil.isNullOrEmpty(token)){
            token = request.getParameter("token");
        }
        if (StringUtil.isNullOrEmpty(token)) {
            //任何人都可以访问的路径则直接放行
            for (String ignoreUrl : myProperties.getAuth().getIgnoreUrls()) {
                AntPathRequestMatcher matcher = new AntPathRequestMatcher(ignoreUrl);
                if (matcher.matches(request)){
                    filterChain.doFilter(request,response);
                    return;
                }
            }

            //需要登录才可以访问的资源 报错
            SecurityContextHolder.clearContext();
            this.authenticationEntryPoint.commence(request, response, null);
            return;
        }

        Claims claims = TokenUtil.GetTokenClaims(token);
        if (claims == null){ //token过期等原因不能用了
            SecurityContextHolder.clearContext();
            this.authenticationEntryPoint.commence(request, response, new BadCredentialsException("TOKEN已过期，请重新登录！"));
            return;
        }


        //检查是否应该刷新token
        String refreshToken = TokenUtil.GetRefreshToken(claims);
        if (StringUtil.isNullOrEmpty(refreshToken) == false){
            // 主动刷新token，并返回给前端
            response.addHeader("RefreshToken", refreshToken);
        }

        //提取token包含相关信息
        Authentication authentication = TokenUtil.getAuthentication(claims);



        SecurityContextHolder.getContext().setAuthentication(authentication);
//        String account = (String)authentication.getPrincipal();
//        request.getSession().setAttribute("username", account);
        //一切正常 让往下走
        filterChain.doFilter(request, response);


    }

}
