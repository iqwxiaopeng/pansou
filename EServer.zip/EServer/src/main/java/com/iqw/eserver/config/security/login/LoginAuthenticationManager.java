package com.iqw.eserver.config.security.login;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.ProviderNotFoundException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.stereotype.Component;

import java.util.Objects;

/** 自定义认证管理器就是为了转调自己提供的认证器来真正执行认证操作
 * <p> 自定义认证管理器  登录认证</p>
 *
 * @author : zhengqing
 * @description :
 * @date : 2019/10/12 14:49
 */
@Component
public class LoginAuthenticationManager implements AuthenticationManager {

    private final LoginAuthenticationProvider loginAuthenticationProvider;

    public LoginAuthenticationManager(LoginAuthenticationProvider loginAuthenticationProvider) {
        this.loginAuthenticationProvider = loginAuthenticationProvider;
    }

    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
        Authentication result = loginAuthenticationProvider.authenticate(authentication);
        if (Objects.nonNull(result)) {
            return result;
        }
        throw new ProviderNotFoundException("Authentication failed!");
    }

}
