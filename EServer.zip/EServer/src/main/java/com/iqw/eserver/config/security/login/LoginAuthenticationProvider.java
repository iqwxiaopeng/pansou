package com.iqw.eserver.config.security.login;


import com.iqw.eserver.config.security.securityuser.UserDetailsServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import java.util.Collection;

/**    对登录用户进行登录认证
 *  <p> 自定义认证处理 </p>
 *
 * @description :
 * @author : zhengqing
 * @date : 2019/10/12 14:49
 */
@Component
public class LoginAuthenticationProvider implements AuthenticationProvider {

    //替换为我们自己的数据来源
    @Autowired
    UserDetailsServiceImpl userDetailsService;


    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
        // 获取前端表单中输入后返回的用户名、密码
        String userName = (String) authentication.getPrincipal();
        String password = (String) authentication.getCredentials();

        // 认证逻辑
        UserDetails userDetails = userDetailsService.loadUserByUsername(userName);//加载用户
        if (null != userDetails) { //加载成功且密码正确则验证通过
            //        boolean isValid = PasswordUtils.isValidPassword(password, userInfo.getPassword(), userInfo.getCurrentUserInfo().getSalt());
            if (password.compareToIgnoreCase( userDetails.getPassword()) == 0) {
                // 获取用户对应的角色id数组
                Collection<? extends GrantedAuthority> authorities= userDetails.getAuthorities();

                // 生成令牌 这里令牌里面存入了:account, password, authorities, 当然你也可以放其他内容
                return new UsernamePasswordAuthenticationToken(userDetails.getUsername(), password, authorities);
            } else {
                throw new BadCredentialsException("密码错误");
            }
        } else {
            throw new UsernameNotFoundException("用户不存在");
        }


    }

    @Override
    public boolean supports(Class<?> aClass) {
        return true;
    }
}
