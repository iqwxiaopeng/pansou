package com.iqw.eserver.config.security.token;



import com.iqw.eserver.config.MyProperties;
import io.jsonwebtoken.*;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.stream.Collectors;

public class TokenUtil {
    public static void SetAuthCfg(MyProperties myProperties){
        EXPIRE_TIME = myProperties.getAuth().getTokenExpireTime()*60*1000;
    }

    private static long EXPIRE_TIME= 15*60*1000; //token创建过期时间
    private static long REFRESH_TIME=10*60*1000; //token刷新增加时间

    private static String TOKEN_SECRET="token123";  //token密钥盐

    private static String AUTHORITIES_KEY="auth";  //权限在token中的key值



    //根据账号 权限信息创建token
    public static String createToken(Authentication authentication) {
        String account = authentication.getName();
        String authorities = authentication.getAuthorities().stream() //权限
                .map(GrantedAuthority::getAuthority)
                .collect(Collectors.joining(","));

        long now = (new Date()).getTime();
        Date validity = new Date(now + EXPIRE_TIME);


        return Jwts.builder()
                .setSubject(account) //账号
                .claim(AUTHORITIES_KEY, authorities)  //权限
                .signWith(SignatureAlgorithm.HS512, TOKEN_SECRET)
                .setExpiration(validity)//过期时间
                .compact();
    }


    //解析token
    public static Claims GetTokenClaims(String authToken){
        Claims claims = null;
        try {
            claims = Jwts.parser().setSigningKey(TOKEN_SECRET).parseClaimsJws(authToken).getBody();
            return claims;

        } catch (Exception e) {
            return null;
        }
    }

    //获取刷新token 不在刷新要求则返回空
    public static String GetRefreshToken(Claims claims){
        String newToken = "";
//        long issuedAt = claims.getIssuedAt().getTime();// token签发时间
        long currentTimeMillis = System.currentTimeMillis();// 当前时间
        long expirationTime = claims.getExpiration().getTime();// token过期时间

        //距离过期差一个刷新时间,就给刷新了
        if (currentTimeMillis + REFRESH_TIME  > expirationTime) {

            long now = (new Date()).getTime();
            Date validity = new Date(now + REFRESH_TIME); //当前时间基础上加一点时间

            newToken = Jwts.builder()
                    .setSubject(claims.getSubject())
//                    .setIssuedAt(now)//签发时间
                    .setExpiration(validity)
                    .signWith(SignatureAlgorithm.HS512, TOKEN_SECRET)
                    .compact();
        }

        return newToken;
    }

    //检查token的合法性
    public static boolean validateToken(String authToken) {
        try {
            Jwts.parser().setSigningKey(AUTHORITIES_KEY).parseClaimsJws(authToken);
            return true;
        } catch (SecurityException | MalformedJwtException e) {
            System.out.println("Invalid JWT signature.");
            e.printStackTrace();
        } catch (ExpiredJwtException e) {
            System.out.println("Expired JWT token.");
            e.printStackTrace();
        } catch (UnsupportedJwtException e) {
            System.out.println("Unsupported JWT token.");
            e.printStackTrace();
        } catch (IllegalArgumentException e) {
            System.out.println("JWT token compact of handler are invalid.");
            e.printStackTrace();
        }
        return false;
    }


    //解析token获取账号 权限信息
    public static Authentication getAuthentication(String token) {
        Claims claims = Jwts.parser()
                .setSigningKey(TOKEN_SECRET)
                .parseClaimsJws(token)
                .getBody();

        Collection<? extends GrantedAuthority> authorities =
                Arrays.stream(claims.get(AUTHORITIES_KEY).toString().split(","))
                        .map(SimpleGrantedAuthority::new)
                        .collect(Collectors.toList());

        String principal = claims.getSubject(); //获取账号
        return new UsernamePasswordAuthenticationToken(principal, token, authorities);
    }

    //获取账号 权限信息
    public static Authentication getAuthentication(Claims claims) {

        Collection<? extends GrantedAuthority> authorities =
                Arrays.stream(claims.get(AUTHORITIES_KEY).toString().split(","))
                        .map(SimpleGrantedAuthority::new)
                        .collect(Collectors.toList());

        String principal = claims.getSubject(); //获取账号
        return new UsernamePasswordAuthenticationToken(principal, null, authorities);
    }


}