package com.iqw.eserver.modules.es.controller;

import com.alibaba.fastjson.JSONObject;
import com.iqw.eserver.base.model.JsonResult;
import com.iqw.eserver.base.model.JsonResultType;
import com.iqw.eserver.base.utils.DateTimeUtil;
import com.iqw.eserver.base.utils.FileUtil;
import com.iqw.eserver.base.utils.StringUtil;
import com.iqw.eserver.modules.es.service.EsService;
import com.iqw.eserver.modules.yunpan.dto.model.FileVO;
import com.iqw.eserver.modules.yunpan.dto.model.NoteVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/es")
@Api(value = "/es", tags  = "es检索相关api")
public class EsSearchController {

    @Autowired
    EsService esService;

    @ResponseBody
    @GetMapping("/search")
    @ApiOperation(value = "ES搜索文件", notes = "ES搜索文件"/*, response = JsonResult.class*/)
    public String Search(String name, String keywords, String remarks, int type) {


        if (StringUtil.isNullOrEmpty(keywords) == false){
            keywords = keywords.toLowerCase();
            String[] keywordsArray =  keywords.split("[\\,\\;\\，\\s]");
            keywords = StringUtil.array2String(keywordsArray);
        }


        List<JSONObject> list = esService.SearchEsItem(name, keywords, remarks, type);


        List<FileVO> voFiles = new ArrayList<>();
        for (JSONObject vFile:list){
            FileVO voFile = new FileVO();
            voFile.setName(vFile.getString("name") );
            voFile.setId((int)vFile.getInteger("id"));
            voFile.setKeyword(vFile.getString("keyword"));
            voFile.setRemarks(vFile.getString("remarks"));
            voFile.setFolderid((int)vFile.getInteger("folderId"));
            long size = vFile.getInteger("size");

            if (size == 0){
                voFile.setDirectory(true);
            }
            voFile.setSize(size);
            voFile.setUpdateTime(DateTimeUtil.getCurrentTimestamp());
            voFile.setExt(FileUtil.getFileExtension(vFile.getString("name")));
            voFiles.add(voFile);
        }

        JsonResult result = new JsonResult(JsonResultType.SUCCESS);
        result.add(voFiles);
        return result.toJSON();
    }

    @ResponseBody
    @GetMapping("/searchnote")
    @ApiOperation(value = "ES搜索随笔", notes = "ES搜索随笔"/*, response = JsonResult.class*/)
    public String SearchNote(String name, String keywords, String remarks, int type) {


        if (StringUtil.isNullOrEmpty(keywords) == false){
            keywords = keywords.toLowerCase();
            String[] keywordsArray =  keywords.split("[\\,\\;\\，\\s]");
            keywords = StringUtil.array2String(keywordsArray);
        }


        List<JSONObject> list = esService.SearchEsNote(name, keywords, remarks, type);


        List<NoteVO> noteVOS = new ArrayList<>();
        for (JSONObject vFile:list){
            NoteVO noteVO = new NoteVO();
            noteVO.setName(vFile.getString("name") );
            noteVO.setId((int)vFile.getInteger("id"));
            noteVO.setKeyword(vFile.getString("keyword"));
            noteVO.setContent(vFile.getString("content"));
            long size = vFile.getInteger("size");

            noteVO.setSize(size);
            noteVO.setGmtModified(DateTimeUtil.getCurrentTimestamp());
            noteVOS.add(noteVO);
        }

        JsonResult result = new JsonResult(JsonResultType.SUCCESS);
        result.add(noteVOS);
        return result.toJSON();
    }

}
