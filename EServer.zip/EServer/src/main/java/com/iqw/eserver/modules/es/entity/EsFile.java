package com.iqw.eserver.modules.es.entity;

import com.alibaba.fastjson.JSONObject;
import com.iqw.eserver.modules.yunpan.entity.PanFile;
import com.iqw.eserver.modules.es.mapper.EsBaseUtil;

import java.util.Map;

/**
 * 对应es数据库的表结构
 */
public class EsFile implements EsModel {
    private PanFile panFile;


    public void setPanFile(PanFile panFile){
        this.panFile = panFile;
    }

    @Override
    public String getEsId() {
        return String.valueOf(panFile.getId());
    }

    @Override
    public String getTableName() {
        return EsFile.class.getSimpleName().toLowerCase();
    }

    @Override
    public  Map<String, String> getTableStruct(){
        Map<String, String> table = EsBaseUtil.getClassTable(PanFile.class);
        table.put("name", "text");
        table.put("remarks", "text");
        return table;
    }


    @Override
    public JSONObject getTableItem()  {
        JSONObject item =  EsBaseUtil.getTableItem(panFile);
        if (item != null){
            String keyword = panFile.getKeyword();
            String[] words = keyword.split(",");
            item.put("keyword", words);
            item.put("id", panFile.getId());
        }
        return item;
    }

}
