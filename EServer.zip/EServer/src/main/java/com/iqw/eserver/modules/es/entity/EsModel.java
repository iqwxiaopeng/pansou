package com.iqw.eserver.modules.es.entity;

import com.alibaba.fastjson.JSONObject;

import java.util.Map;

/**
 * es 基本实体类表结构定义
 */
public interface EsModel {
    //es 条目id
    public String getEsId();
    //es索引名
    public String getTableName();

    //es表结构
    public Map<String, String> getTableStruct();

    //返回 Java对象对应的es表条目
    public JSONObject getTableItem();
}
