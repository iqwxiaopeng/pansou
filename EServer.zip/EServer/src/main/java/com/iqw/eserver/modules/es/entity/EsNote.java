package com.iqw.eserver.modules.es.entity;

import com.alibaba.fastjson.JSONObject;
import com.iqw.eserver.modules.es.mapper.EsBaseUtil;
import com.iqw.eserver.modules.yunpan.entity.PanNote;

import java.util.Map;

/**
 * 对应es数据库的表结构
 */
public class EsNote implements EsModel {
    private PanNote panNote;


    public void setPanNote(PanNote panNote){
        this.panNote = panNote;
    }

    @Override
    public String getEsId() {
        return String.valueOf(panNote.getId());
    }

    @Override
    public String getTableName() {
        return EsNote.class.getSimpleName().toLowerCase();
    }

    @Override
    public  Map<String, String> getTableStruct(){
        Map<String, String> table = EsBaseUtil.getClassTable(PanNote.class);
        table.put("name", "text");
        table.put("remarks", "text");
        return table;
    }


    @Override
    public JSONObject getTableItem()  {
        JSONObject item =  EsBaseUtil.getTableItem(panNote);
        if (item != null){
            String keyword = panNote.getKeyword();
            String[] words = keyword.split(",");
            item.put("keyword", words);
            item.put("id", panNote.getId());
        }
        return item;
    }

}
