package com.iqw.eserver.modules.es.mapper;

import com.alibaba.fastjson.JSONObject;
import com.iqw.eserver.base.utils.StringUtil;
import com.iqw.eserver.util.EsSearchUtil;
import org.apache.commons.lang3.StringUtils;
import org.elasticsearch.action.DocWriteResponse;
import org.elasticsearch.action.admin.indices.delete.DeleteIndexRequest;
import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.bulk.BulkResponse;
import org.elasticsearch.action.delete.DeleteRequest;
import org.elasticsearch.action.delete.DeleteResponse;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.support.IndicesOptions;
import org.elasticsearch.action.support.master.AcknowledgedResponse;
import org.elasticsearch.action.update.UpdateRequest;
import org.elasticsearch.action.update.UpdateResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.client.indices.CreateIndexRequest;
import org.elasticsearch.client.indices.CreateIndexResponse;
import org.elasticsearch.client.indices.GetIndexRequest;
import org.elasticsearch.common.xcontent.XContentType;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 本类提供es原生的基本方法,只支持json格式数据或者json对象的处理
 */
@Component
public class EsBaseUtil {

    @Autowired
    private RestHighLevelClient rhlClient;


    /**
     * 创建索引
     * @param tableName
     * @throws IOException
     */
    private boolean CreateEsTableByJsonString(String tableName, String tableJson) throws IOException {
        CreateIndexRequest request = new CreateIndexRequest(tableName);
        request.mapping(tableJson, XContentType.JSON);
        CreateIndexResponse createIndexResponse = rhlClient.indices().create(request, RequestOptions.DEFAULT);
        if (!createIndexResponse.isAcknowledged()){
            return false;
        }
        return true;
    }


    /**
     * 创建ES表
     * @param tableName    表名
     * @param tableStruct  表结构
     * @throws IOException
     */
    public boolean CreateESTable(String tableName, Map<String, String> tableStruct) throws IOException {
        CreateIndexRequest request = new CreateIndexRequest(tableName);

        JSONObject tableObject = new JSONObject();
        JSONObject fieldObject = new JSONObject();

        for (String key : tableStruct.keySet()) {
            JSONObject typeObject = new JSONObject();
            typeObject.put("type", tableStruct.get(key));
            fieldObject.put(key, typeObject);
        }

        tableObject.put("properties", fieldObject);

        return CreateEsTableByJsonString(tableName, tableObject.toJSONString());
    }

    /**
     * 判断索引是否存在
     * @param tableName 表名
     * @return
     * @throws IOException
     */
    public boolean IsEsTableExist(String tableName) throws IOException {
        GetIndexRequest request = new GetIndexRequest(tableName);
        return rhlClient.indices().exists(request, RequestOptions.DEFAULT);
    }

    /**
     * 删除ES表
     *
     * @param tableName
     * @return
     */
    public boolean DropEsTable(String tableName) throws IOException {
        boolean acknowledged = false;
        DeleteIndexRequest deleteIndexRequest = new DeleteIndexRequest(tableName);
        deleteIndexRequest.indicesOptions(IndicesOptions.LENIENT_EXPAND_OPEN);
        AcknowledgedResponse delete = rhlClient.indices().delete(deleteIndexRequest, RequestOptions.DEFAULT);
        acknowledged = delete.isAcknowledged();

        return acknowledged;
    }



    //插入一条数据
    public boolean InsertItem(String index, JSONObject obj) throws IOException {
        IndexRequest request = new IndexRequest(index);
        Object idObject = obj.get("id");
        if (idObject != null ){
            String id = idObject.toString();
            if( StringUtils.isNotEmpty(id)){
                request.id(id);
            }
        }
        request.source(obj.toJSONString(), XContentType.JSON);
        IndexResponse indexResponse = rhlClient.index(request, RequestOptions.DEFAULT);
        if(indexResponse.getResult() == DocWriteResponse.Result.CREATED)
        {
            return true;
        }
        return false;
    }


    //批量插入数据
    public boolean BulkInsert(String index, List<JSONObject> objList) throws IOException {
        BulkRequest bulkRequest = new BulkRequest();
        for (JSONObject obj:objList){
            IndexRequest request = new IndexRequest(index);
            Object idObject = obj.get("id");
            if (idObject != null ){
                String id = idObject.toString();
                if( StringUtils.isNotEmpty(id)){
                    request.id(id);
                }
            }
            request.source(obj.toJSONString(), XContentType.JSON);
            bulkRequest.add(request);
        }

        BulkResponse bulkResponse = rhlClient.bulk(bulkRequest, RequestOptions.DEFAULT);
        if(bulkResponse.hasFailures())
        {
            return false;
        }
        return true;
    }



    //更新一条数据
    public boolean UpdateItem(String index, String id, JSONObject obj) throws IOException {
        UpdateRequest  request = new UpdateRequest(index, id);
        request.doc(obj.toJSONString(), XContentType.JSON);
        UpdateResponse indexResponse = rhlClient.update(request, RequestOptions.DEFAULT);
        if(indexResponse.getResult() == DocWriteResponse.Result.UPDATED)
        {
            return true;
        }
        return false;
    }

    //更新一条数据
    public List<JSONObject> SearchItem(String index, SearchSourceBuilder builder) throws IOException {
        SearchRequest searchRequest = new SearchRequest(index);
        searchRequest.source(builder);
        List<JSONObject> jsonList = new ArrayList<>();

        SearchResponse response = rhlClient.search(searchRequest, RequestOptions.DEFAULT);
        System.out.println(response);
        for (SearchHit searchHitFields : response.getHits()) {
            Map<String, Object> objmap = searchHitFields.getSourceAsMap();
            JSONObject jsonObj=new JSONObject(objmap);
            jsonList.add(jsonObj);
        }
        return jsonList;
    }


    //批量更新
    public boolean BulkUpdate(String index, List<JSONObject> objList) throws IOException {
        BulkRequest bulkRequest = new BulkRequest();
        for (JSONObject obj:objList){
            String id = "";
            Object idObject = obj.get("id");
            if (idObject != null ){
                id = idObject.toString();
            }
            if( StringUtils.isNotEmpty(id)){
                UpdateRequest request = new UpdateRequest(index, id);
                request.doc(obj.toJSONString(), XContentType.JSON);
                bulkRequest.add(request);
            }
        }

        BulkResponse bulkResponse = rhlClient.bulk(bulkRequest, RequestOptions.DEFAULT);
        if(bulkResponse.hasFailures())
        {
            return false;
        }
        return true;
    }



    //删除一条数据
    public boolean DeleteItem(String index,  String id ) throws IOException {
        DeleteRequest request = new DeleteRequest(index, id);
        DeleteResponse deleteResponse = rhlClient.delete(request, RequestOptions.DEFAULT);
        if (! (deleteResponse.getResult() == DocWriteResponse.Result.DELETED)){
            return false;
        }
        return true;
    }

    //批量删除
    public boolean BulkDelete(String index, List<String> idList) throws IOException {
        BulkRequest bulkRequest = new BulkRequest();
        for (String id:idList){
            DeleteRequest request = new DeleteRequest(index, id);
            bulkRequest.add(request);
        }

        BulkResponse bulkResponse = rhlClient.bulk(bulkRequest, RequestOptions.DEFAULT);
        if(bulkResponse.hasFailures())
        {
            return false;
        }
        return true;
    }




    //-----------定期删除----------------

    private boolean Delete500OutDateData(String db, String tb, String curTimeStr, String typepath){
        boolean bHave = false;
        Map<String, String> rangeMap = new HashMap<String, String>();
        if(curTimeStr != null ){
            rangeMap.put("timein", curTimeStr );
        }

        Map<String, String> equalMap = new HashMap<String, String>();
        if(typepath != null){
            equalMap.put("path", typepath);
        }

        SearchSourceBuilder sourceBuilder =  EsSearchUtil.GetSourceLGBuilder(rangeMap,equalMap, null ,0, 500);
        sourceBuilder.fetchSource(new String[]{"id"}, new String[]{});

        SearchRequest searchRequest = new SearchRequest(tb.toLowerCase());
        searchRequest.types("_doc");
        searchRequest.source(sourceBuilder);

        try {
            SearchResponse response = rhlClient.search(searchRequest, RequestOptions.DEFAULT);
            System.out.println(response);
            for (SearchHit searchHitFields : response.getHits()) {
                Map<String, Object> objmap = searchHitFields.getSourceAsMap();
                JSONObject jsonObj = new JSONObject(objmap);

                bHave = true;
            }
        }catch (IOException e) {
            e.printStackTrace();
        }
        return bHave;
    }


    /**
     * 将java类型转换为es类型
     * @param type
     * @return
     */

    public static String JavaTypeToEsType(String type){
        String retType = "keyword";
        switch (type){
            case "boolean":
                retType =   "boolean";
                break;
            case "byte":
                retType =   "binary";
                break;
            case "double":
                retType =   "double";
                break;
            case "float":
                retType =   "float";
                break;
            case "long":
                retType =   "long";
                break;
            case "integer":
                retType =   "integer";
                break;
            case "short":
                retType =   "short";
                break;
            case "String":
//                retType =    "text";
                retType =  "keyword";
                break;
            case "Timestamp":
                retType =    "date";
                break;

            default:
                retType =  "keyword";
                break;
        }
        return  retType;
    }

    /**
     * java类对应的es表结构
     * @param tableClass
     * @return
     */
    public static Map<String, String> getClassTable(Class<?> tableClass){
        Map<String, String> EsTable = new HashMap<>();

        // 获取对象属性
        Field[] fields = tableClass.getDeclaredFields();
        for(Field field: fields){
            String name = field.getName();  //属性名
            String type = field.getType().getSimpleName(); //属性类型名
            String esType = JavaTypeToEsType(type);
            EsTable.put(name, esType);
        }
        return EsTable;
    }

    /**
     * java对象对应的es表条目
     * @param obj
     * @return
     */
    public static JSONObject getTableItem(Object obj)  {
        JSONObject item = new JSONObject();
        String name = "";
        Object value = null;

        // 获取对象属性
        Field[] fields = obj.getClass().getDeclaredFields();
        for(Field field: fields){
            name = field.getName();  //属性名
            field.setAccessible(true);
            try {
                value = field.get(obj);
            } catch (IllegalAccessException e) {
                return null;
            }
            item.put(name, value);
        }
        return item;
    }


    /**
     * 创建ES表
     * @param tableClass    表
     * @throws IOException
     */
    public boolean CreateESTable(Class<?> tableClass)  {

        Map<String, String> EsTable = getClassTable(tableClass);

        try {
            CreateESTable(tableClass.getSimpleName().toLowerCase(), EsTable);
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
        return  true;
    }


    /**
     * 插入ES表条目
     * @param obj    条目
     * @throws IOException
     */
    public boolean InsertESTable(Object obj, String indexCol)   {

        JSONObject item = new JSONObject();

        // 获取对象属性
        Field[] fields = obj.getClass().getDeclaredFields();
        for(Field field: fields){
            String name = field.getName();  //属性名
            field.setAccessible(true);
            try {
                Object value = field.get(obj);
                item.put(name, value);
                if (StringUtil.isEquals(name, indexCol)){
                    item.put("id", value); //必须指定个索引字段
                }
            } catch (IllegalAccessException e) {
                return false;
            }
        }
        try {
            InsertItem(obj.getClass().getSimpleName().toLowerCase(), item);
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
        return  true;
    }



}
