package com.iqw.eserver.modules.es.mapper;

import java.io.IOException;

import com.alibaba.fastjson.JSONObject;
import com.iqw.eserver.modules.es.entity.EsModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * 本类提供继承了EsEntity的java类使用
 */

@Component
public class EsDaoUtil {

    @Autowired
    private EsBaseUtil esUtil;

    /**
     * 创建ES表
     * @param esObj    表对象
     * @throws IOException
     */
    public boolean IsTableExist(EsModel esObj)  {
        try {
            boolean bExist = esUtil.IsEsTableExist(esObj.getTableName());
            return  bExist;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }


    /**
     * 创建ES表
     * @param esObj    表对象
     * @throws IOException
     */
    public boolean Create(EsModel esObj)  {

        Map<String, String> EsTable = esObj.getTableStruct();

        try {
            esUtil.CreateESTable(esObj.getTableName(), EsTable);
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
        return  true;
    }


    /**
     * 插入ES表条目
     * @param obj    条目
     * @throws IOException
     */
    public boolean Insert(EsModel obj)   {
        JSONObject item = obj.getTableItem();
        try {
            esUtil.InsertItem(obj.getTableName(), item);
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
        return  true;
    }

    /**
     * 删除ES表条目

     * @throws IOException
     */
    public boolean deleteById(String tbName, long id)   {

        try {
            esUtil.DeleteItem(tbName, String.valueOf(id));
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
        return  true;
    }


    /**
     * 删除ES表条目

     * @throws IOException
     */
    public boolean deleteById(Class<?> T, int id)   {

        try {
            esUtil.DeleteItem(T.getSimpleName().toLowerCase(), String.valueOf(id));
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
        return  true;
    }
}