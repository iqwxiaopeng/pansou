package com.iqw.eserver.modules.es.service;

import com.alibaba.fastjson.JSONObject;
import com.iqw.eserver.SysConstants;
import com.iqw.eserver.modules.es.entity.EsFile;
import com.iqw.eserver.modules.es.entity.EsNote;
import com.iqw.eserver.modules.es.mapper.EsBaseUtil;
import com.iqw.eserver.util.EsSearchUtil;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class EsService {

    @Autowired
    private EsBaseUtil esBaseUtil;


    //根据检索条件 从es搜索信息
    public List<JSONObject> SearchEsItem(String name, String keywords, String desc, int type){

        Map<String, String> listlMap = new HashMap<String, String>();
        if(keywords != null){
            listlMap.put("keyword", keywords);
        }

        Map<String, String> likeMap = new HashMap<String, String>();
        if(desc != null){
            likeMap.put("remarks", desc);
        }
        if(name != null){
            likeMap.put("name", name);
        }

        SearchSourceBuilder builder =  null;

        if (type == SysConstants.SEARCH_BY_KEYWORD){
            builder = EsSearchUtil.GetSourceBuilder(null, null, listlMap,0,100);

        }else {
            builder = EsSearchUtil.GetSourceBuilder(null, likeMap, listlMap,0,100);
        }

        List<JSONObject> objList = null;
        try {
            objList = esBaseUtil.SearchItem(new EsFile().getTableName(), builder);
        } catch (IOException e) {
            e.printStackTrace();
        }

        return objList;

    }

    public List<JSONObject> SearchEsNote(String name, String keywords, String remarks, int type) {
        Map<String, String> listlMap = new HashMap<String, String>();
        if(keywords != null){
            listlMap.put("keyword", keywords);
        }

        Map<String, String> likeMap = new HashMap<String, String>();
        if(remarks != null){
            likeMap.put("remarks", remarks);
        }
        if(name != null){
            likeMap.put("name", name);
        }

        SearchSourceBuilder builder =  null;

        if (type == SysConstants.SEARCH_BY_KEYWORD){
            builder = EsSearchUtil.GetSourceBuilder(null, null, listlMap,0,100);

        }else {
            builder = EsSearchUtil.GetSourceBuilder(null, likeMap, listlMap,0,100);
        }

        List<JSONObject> objList = null;
        try {
            objList = esBaseUtil.SearchItem(new EsNote().getTableName(), builder);
        } catch (IOException e) {
            e.printStackTrace();
        }

        return objList;
    }
}
