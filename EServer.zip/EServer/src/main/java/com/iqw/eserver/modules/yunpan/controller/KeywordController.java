package com.iqw.eserver.modules.yunpan.controller;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.iqw.eserver.base.model.JsonResult;
import com.iqw.eserver.base.model.JsonResultType;
import com.iqw.eserver.base.utils.StringUtil;
import com.iqw.eserver.modules.yunpan.entity.KeywordGlobal;
import com.iqw.eserver.modules.yunpan.entity.PanNote;
import com.iqw.eserver.modules.yunpan.service.IKeywordGlobalService;
import com.iqw.eserver.modules.yunpan.service.IPanNoteService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/keyword")
@Api(value = "/keyword", tags  = "关键词条目表")
public class KeywordController {

    @Autowired
    IKeywordGlobalService keywordGlobalService;




    /**
     * 获取目录文件列表
     * @return
     */
    @ResponseBody
    @GetMapping("/list")
    @ApiOperation(value = "获取关键词条目", notes = "获取关键词条目"/*, response = JsonResult.class*/)
    public String ListKeywords() {
        String username = (String) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

        List<KeywordGlobal> voList= keywordGlobalService.selectList(new EntityWrapper<KeywordGlobal>().gt("refnum",0).orderBy("gmt_modified"));


        JsonResult result = new JsonResult(JsonResultType.SUCCESS);
        result.add(voList);
        return result.toJSON();
    }






}
