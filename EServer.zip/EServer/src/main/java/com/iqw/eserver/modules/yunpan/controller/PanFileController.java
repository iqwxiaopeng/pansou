package com.iqw.eserver.modules.yunpan.controller;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.iqw.eserver.SysConstants;
import com.iqw.eserver.base.model.JsonResult;
import com.iqw.eserver.base.model.JsonResultType;
import com.iqw.eserver.base.utils.DateTimeUtil;
import com.iqw.eserver.base.utils.FileUtil;
import com.iqw.eserver.base.utils.Md5Util;
import com.iqw.eserver.base.utils.StringUtil;
import com.iqw.eserver.modules.system.entity.User;
import com.iqw.eserver.modules.yunpan.dto.model.FileVO;
import com.iqw.eserver.modules.yunpan.entity.PanFile;
import com.iqw.eserver.modules.yunpan.entity.UploadingFile;
import com.iqw.eserver.modules.yunpan.service.IPanFileService;
import com.iqw.eserver.modules.yunpan.service.IStoreNodeService;
import com.iqw.eserver.modules.yunpan.service.IUploadingFileService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.sql.Wrapper;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/panfile")
@Api(value = "/panfile", tags  = "云盘文件操作相关API")
public class PanFileController {

    @Autowired
    IPanFileService panFileService;

    /**
     * 新建文件夹
     * @param folderId  文件夹id
     * @param name      文件夹名
     * @param keywords  文件夹关键词
     * @param remarks      文件夹描述信息
     * @return
     */
    @ResponseBody
    @GetMapping("/newdir")
    @ApiOperation(value = "新建文件夹", notes = "新建文件夹"/*, response = JsonResult.class*/)
    public String NewDir(long folderId, String name,  String keywords, String remarks) {


        boolean bSuccess = panFileService.newDirectory (folderId, (long) 0, name, keywords, remarks);
        JsonResult result = new JsonResult(JsonResultType.SUCCESS);

        if (bSuccess == false){
            result.setType(JsonResultType.ERROR);
            result.setMessage("创建失败(位置错误或文件存在)");
        }

        return result.toJSON();
    }


    /**
     * 获取目录文件列表
     * @param folderId 目录id
     * @param pageNum
     * @param pageSize
     * @return
     */
    @ResponseBody
    @GetMapping("/listdir")
    @ApiOperation(value = "获取目录文件列表", notes = "获取目录文件列表"/*, response = JsonResult.class*/)
    public String ListDir(long folderId, Integer pageNum, Integer pageSize) {
        String username = (String) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if (pageNum == null || pageNum == 0 || pageSize == null || pageSize == 0){
            pageNum = 1;
            pageSize=10;
        }
        PageHelper.startPage(pageNum, pageSize);
        List<FileVO> voList= panFileService.listFiles(0, folderId);
        PageInfo<FileVO> pageInfo = new PageInfo<>(voList);

        JsonResult result = new JsonResult(JsonResultType.SUCCESS);
        result.add(pageInfo);
        return result.toJSON();
    }

    /**
     * 获取目录文件列表
     * @param folderId 目录id
     * @return
     */
    @ResponseBody
    @GetMapping("/listdirfile")
    @ApiOperation(value = "获取目录文件列表", notes = "获取目录文件列表"/*, response = JsonResult.class*/)
    public String ListDirectorys(long folderId) {
        String username = (String) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

        List<FileVO> voList= panFileService.listDirectorys(0, folderId);


        JsonResult result = new JsonResult(JsonResultType.SUCCESS);
        result.add(voList);
        return result.toJSON();
    }

    /**
     * 移动文件到
     * @param folderId 目录id
     * @return
     */
    @ResponseBody
    @GetMapping("/movefile")
    @ApiOperation(value = "移动文件到", notes = "移动文件到"/*, response = JsonResult.class*/)
    public String moveFiles(long folderId, String ids, boolean keepboth) {

        List<Long> idList = StringUtil.string2LongList(ids);
        List<Long> errIds = new ArrayList<>();
        boolean bSuccess = panFileService.moveFiles (idList, errIds,folderId, keepboth);
        JsonResult result = new JsonResult(JsonResultType.SUCCESS);

        if (bSuccess == false){
            result.setType(JsonResultType.ERROR);
            result.setMessage("移动文件失败(位置错误或文件重名)");
        }
        result.add(errIds);

        return result.toJSON();
    }


    /**
     * 查看文件属性
     * @param id 文件id
     * @return
     */
    @ResponseBody
    @GetMapping("/property")
    @ApiOperation(value = "查看文件属性", notes = "查看文件属性"/*, response = JsonResult.class*/)
    public String GetFileProperty(String id) {

//        Esitemlog objProp = storeService.GetFileProperty(Integer.parseInt(id));
//        JsonResult result = new JsonResult(JsonResultType.SUCCESS);
//
//        if (objProp == null){
//            result.setType(JsonResultType.ERROR);
//            result.setMessage("发生错误");
//        }

//        return result.toJSON();
        return "";
    }

    /**
     * 查看文件属性
     * @param id 文件id
     * @return
     */
    @ResponseBody
    @GetMapping("/update")
    @ApiOperation(value = "更新文件信息", notes = "更新文件信息"/*, response = JsonResult.class*/)
    public String UpdateFileInfo(long id, String name,  String keywords, String remarks) {
        if (StringUtil.isNullOrEmpty(keywords) == false){
            keywords = keywords.toLowerCase();
            String[] keywordsArray =  keywords.split("[\\,\\;\\，\\s]");
            keywords = StringUtil.array2String(keywordsArray);
        }



        boolean bSuccess = panFileService.updateFileInfo(id, name, keywords, remarks);
        JsonResult result = new JsonResult(JsonResultType.SUCCESS);

        if (bSuccess == false){
            result.setType(JsonResultType.ERROR);
            result.setMessage("信息更新失败");
        }else{
            result.setType(JsonResultType.SUCCESS);
        }
        return result.toJSON();
    }

    /**
     * 丢弃文件夹内所有的文件到垃圾回收站
     *
     * @param ids
     * @return
     */

    @ResponseBody
    @GetMapping("/delete")
    @ApiOperation(value = "删除文件", notes = "删除文件"/*, response = JsonResult.class*/)
    public String  deleteDirectoryToTrash(String ids) {
        List<Long> idList = StringUtil.string2LongList(ids);
        boolean bSuccess = panFileService.deleteFilesToTrash(idList);
        JsonResult result = new JsonResult(JsonResultType.SUCCESS);
        if (bSuccess == false){
            result.setType(JsonResultType.ERROR);
            result.setMessage("移动文件失败(位置错误或文件重名)");
        }

        return result.toJSON();
    }



    //上传下载
    /**
     * 打理本地文件,单机模式暂时开此接口
     * @param localFilePath  文件本地路径
     * @param fileName       文件名
     * @param folderId       虚拟路径
     * @param keywords 关键词
     * @param remarks     描述信息
     * @return
     */
    @ResponseBody
    @PostMapping("/newfile")
    @ApiOperation(value = "打理本地文件", notes = "打理本地文件"/*, response = JsonResult.class*/)
    public String UploadLocalFile(String localFilePath, String fileName, Long folderId, String keywords, String remarks) {

        boolean bSuccess = panFileService.newFile(folderId, (long) 0,fileName,localFilePath, keywords, remarks);
        JsonResult result = new JsonResult(JsonResultType.SUCCESS);

        if (bSuccess == false){
            result.setType(JsonResultType.ERROR);
            result.setMessage("发生错误");
        }else{
            try {
                FileUtil.deleteFile(localFilePath + "/"+fileName);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return result.toJSON();
    }



    @GetMapping("/import")
    @ApiOperation(value = "上传文件", notes = "上传文件"/*, response = JsonResult.class*/)
    public String getServerFileData(int chunkNumber, int chunkSize, long totalSize, int totalChunks, String identifier,
                                    String filename, String relativePath,long folderId,HttpServletRequest request)  {

        try{
            String uploadFilePath = downloadFolder + "upload" + "/" + identifier;

            boolean bSkipUpload = storeNodeService.isFileExit(identifier);
            if (bSkipUpload == false){

            }

            UploadingFile uploadingFile = new UploadingFile();
            uploadingFile.setFolderId(folderId);
            uploadingFile.setName(filename);
            uploadingFile.setRelativePath(relativePath);
            uploadingFile.setSize(totalSize);
            uploadingFile.setMd5(identifier);
            uploadingFileService.save(uploadingFile);


            if(FileUtil.isFileExist(uploadFilePath ) == false){
                RandomAccessFile randomAccessFile = new RandomAccessFile(uploadFilePath, "rw");
                randomAccessFile.setLength(totalSize);
                randomAccessFile.close();
            }


            String downloadURI = downloadURL + "upload/" + identifier;
            String fileURL = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort()+downloadURI;

            System.out.println(fileURL);
            JsonResult result = new JsonResult(JsonResultType.SUCCESS);
            String time = DateTimeUtil.getDateTimeString();
            result.add("filepath", time);
            return result.toJSON();
        }catch (Exception e){
            JsonResult result = new JsonResult(JsonResultType.ERROR);
            return result.toJSON();
        }

    }


    @PostMapping("/import")
    public String importData(int chunkNumber, int chunkSize, long totalSize, int totalChunks, String identifier,
                             String filename, String relativePath,long folderId, int currentChunkSize,HttpServletRequest request)  {

        try{
            long lastPostion = (chunkNumber - 1) * chunkSize;

            String uploadFilePath = downloadFolder + "upload" + "/" + identifier;

            MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
            MultipartFile file = multipartRequest.getFile("upfile");

            RandomAccessFile randomAccessFile = new RandomAccessFile(uploadFilePath, "rw");
            randomAccessFile.seek(lastPostion);
            randomAccessFile.write(file.getBytes(), 0, currentChunkSize);
            randomAccessFile.close();



            String downloadURI = downloadURL + "upload/" + identifier;
            String fileURL = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort()+downloadURI;

            if (chunkNumber == totalChunks){
                System.out.println("传输完成");
                List<UploadingFile> uploadingFileList = uploadingFileService.selectList(new EntityWrapper<UploadingFile>().eq("md5",identifier));
                for(UploadingFile uploadingFile:uploadingFileList){
                    panFileService.newFile(uploadingFile.getFolderId(), (long) 0,uploadingFile.getName(),uploadingFile.getMd5(), null, null);
                    uploadingFileService.deleteById(uploadingFile.getId());
                }

            }
            System.out.println(fileURL);
            JsonResult result = new JsonResult(JsonResultType.SUCCESS);
            return result.toJSON();
        }catch (Exception e){
            JsonResult result = new JsonResult(JsonResultType.ERROR);
            return result.toJSON();
        }

    }


    /**
     * 下载文件
     * @param ids  要下载的文件
     * @return
     */
    @ResponseBody
    @PostMapping("/download")
    @ApiOperation(value = "下载文件", notes = "下载文件"/*, response = JsonResult.class*/)
    public String DownloadFile(String ids, HttpServletRequest request) {

        List<String> files = new ArrayList<>();


        List<Long> idList = StringUtil.string2LongList(ids);
        List<PanFile> panFileList = panFileService.selectBatchIds(idList);
        String serverFolderPath = downloadFolder ;
        String serverFilePath = serverFolderPath;
        for (PanFile panFile:panFileList){
            if (panFile.getSize() > 0){
                serverFilePath = serverFolderPath + panFile.getName();
                storeNodeService.getFile((long) 0, panFile.getMd5(), serverFilePath);
                String downloadURI = downloadURL + panFile.getName();
//                String fileURL = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort()+downloadURI;
                String fileURL = request.getScheme() + "://192.168.1.145:8089"+downloadURI;

                files.add(fileURL);

            }
        }

        JsonResult result = new JsonResult(JsonResultType.SUCCESS);
        result.add(files);
        return result.toJSON();
    }


    @Autowired
    IStoreNodeService storeNodeService;

    @Value("${app.download}")
    private String downloadFolder;

    @Value("${app.downloadURL}")
    private String downloadURL;


    @Autowired
    IUploadingFileService uploadingFileService;
}
