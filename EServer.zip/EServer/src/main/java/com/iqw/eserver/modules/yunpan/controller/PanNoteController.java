package com.iqw.eserver.modules.yunpan.controller;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.iqw.eserver.base.model.JsonResult;
import com.iqw.eserver.base.model.JsonResultType;

import com.iqw.eserver.base.utils.StringUtil;
import com.iqw.eserver.modules.yunpan.dto.model.FileVO;

import com.iqw.eserver.modules.yunpan.entity.PanNote;
import com.iqw.eserver.modules.yunpan.service.IPanNoteService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/pannote")
@Api(value = "/pannote", tags  = "云盘随笔操作相关API")
public class PanNoteController {

    @Autowired
    IPanNoteService panNoteService;

    /**
     * 新建文件夹
     * @param name      文件夹名
     * @param keywords  文件夹关键词
     * @param remarks      文件夹描述信息
     * @return
     */
    @ResponseBody
    @GetMapping("/new")
    @ApiOperation(value = "新建随笔", notes = "新建随笔"/*, response = JsonResult.class*/)
    public String NewNote( String name,  String keywords, String remarks) {


        boolean bSuccess = panNoteService.newNote ((long) 0, name, keywords, remarks);
        JsonResult result = new JsonResult(JsonResultType.SUCCESS);

        if (bSuccess == false){
            result.setType(JsonResultType.ERROR);
            result.setMessage("创建失败");
        }

        return result.toJSON();
    }



    /**
     * 获取目录文件列表
     * @return
     */
    @ResponseBody
    @GetMapping("/list")
    @ApiOperation(value = "获取随笔列表", notes = "获取随笔列表"/*, response = JsonResult.class*/)
    public String ListNotes() {
        String username = (String) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

        List<PanNote> voList= panNoteService.selectList(new EntityWrapper<PanNote>().orderBy("gmt_modified"));


        JsonResult result = new JsonResult(JsonResultType.SUCCESS);
        result.add(voList);
        return result.toJSON();
    }



    /**
     * 查看文件属性
     * @param id 文件id
     * @return
     */
    @ResponseBody
    @GetMapping("/update")
    @ApiOperation(value = "更新随笔信息", notes = "更新随笔信息"/*, response = JsonResult.class*/)
    public String UpdateFileInfo(long id, String name,  String keywords, String remarks) {
        if (StringUtil.isNullOrEmpty(keywords) == false){
            keywords = keywords.toLowerCase();
            String[] keywordsArray =  keywords.split("[\\,\\;\\，\\s]");
            keywords = StringUtil.array2String(keywordsArray);
        }



        boolean bSuccess = panNoteService.updateNote(id, name, keywords, remarks);
        JsonResult result = new JsonResult(JsonResultType.SUCCESS);

        if (bSuccess == false){
            result.setType(JsonResultType.ERROR);
            result.setMessage("信息更新失败");
        }else{
            result.setType(JsonResultType.SUCCESS);
        }
        return result.toJSON();
    }




    /**
     * 丢弃文件夹内所有的文件到垃圾回收站
     *
     * @param ids
     * @return
     */

    @ResponseBody
    @GetMapping("/delete")
    @ApiOperation(value = "删除随笔", notes = "删除随笔"/*, response = JsonResult.class*/)
    public String  deleteDirectoryToTrash(String ids) {
        List<Long> idList = StringUtil.string2LongList(ids);
        boolean bSuccess = panNoteService.deleteNotesToTrash(idList);
        JsonResult result = new JsonResult(JsonResultType.SUCCESS);
        if (bSuccess == false){
            result.setType(JsonResultType.ERROR);
            result.setMessage("删除随便失败(位置错误或文件重名)");
        }

        return result.toJSON();
    }


}
