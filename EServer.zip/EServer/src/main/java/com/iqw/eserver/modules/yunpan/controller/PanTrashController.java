package com.iqw.eserver.modules.yunpan.controller;

import io.swagger.annotations.Api;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/pantrash")
@Api(value = "/pantrash", tags  = "垃圾回收站相关API")
public class PanTrashController {
}
