package com.iqw.eserver.modules.yunpan.controller;

import com.iqw.eserver.modules.yunpan.service.IStoreNodeService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/storenode")
@Api(value = "/storenode", tags  = "存储相关api")
public class StoreNodeController {


    @Autowired
    IStoreNodeService storeNodeService;
    /**
     * 新增存储节点
     */
    @ResponseBody
    @GetMapping("/add")
    @ApiOperation(value = "新增存储节点", notes = "新增存储节点"/*, response = JsonResult.class*/)
    public String RegisterNode(String storepath, long capacity) {

        long userid = 0;
        boolean bResult = storeNodeService.registerStoreNode(userid, storepath, capacity);
        if (bResult == false)
        {
            return "false";
        }
        return "true";
    }

    /**
     * 删除存储节点
     */
    @ResponseBody
    @GetMapping("/del")
    @ApiOperation(value = "移除存储节点", notes = "移除存储节点"/*, response = JsonResult.class*/)
    public String RemoveNode(long id) {

        long userid = 0;
        boolean bResult = storeNodeService.removeStoreNode(userid, id);
        if (bResult == false)
        {
            return "false";
        }
        return "true";
    }

    /**
     * 查询数据
     */
    @ResponseBody
    @GetMapping("/delete")
    @ApiOperation(value = "删除数据", notes = "删除数据"/*, response = JsonResult.class*/)
    public String deleteItem(String path, String ids, boolean type) {

        return "";
    }

    /**
     * 查询数据
     */
    @ResponseBody
    @GetMapping("/update")
    @ApiOperation(value = "修改数据", notes = "修改数据"/*, response = JsonResult.class*/)
    public String deleteItem(String id, String datapath, String keywords, String desc) {

        return "";
    }



}
