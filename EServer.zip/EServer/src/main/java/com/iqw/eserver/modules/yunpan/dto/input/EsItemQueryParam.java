package com.iqw.eserver.modules.yunpan.dto.input;

import com.iqw.eserver.modules.common.dto.input.BasePageQuery;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
* es存储条目表 查询参数
*
* @author: PanSou
* @description:
* @date: 2020-07-22
*/
@Data
@ApiModel(description = "es存储条目表  查询参数")
public class EsItemQueryParam extends BasePageQuery {
    @ApiModelProperty(value = "id")
    private Integer id;


}
