package com.iqw.eserver.modules.yunpan.dto.input;

import com.iqw.eserver.modules.common.dto.input.BasePageQuery;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
* 文件扩展名定义表 查询参数
*
* @author: PanSou
* @description:
* @date: 2020-07-22
*/
@Data
@ApiModel(description = "文件扩展名定义表  查询参数")
public class FileExtQueryParam extends BasePageQuery {
    @ApiModelProperty(value = "id")
    private Integer id;


}
