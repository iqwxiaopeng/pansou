package com.iqw.eserver.modules.yunpan.dto.input;

import com.iqw.eserver.modules.common.dto.input.BasePageQuery;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
* 云盘文件表 查询参数
*
* @author: PanSou
* @description:
* @date: 2020-07-22
*/
@Data
@ApiModel(description = "云盘文件表  查询参数")
public class PanFileQueryParam extends BasePageQuery {
    @ApiModelProperty(value = "id")
    private Long id;

    @ApiModelProperty(value = "用户id")
    private Long userId;

    @ApiModelProperty(value = "删除前其所在的目录id")
    private Long folderId;

    @ApiModelProperty(value = "访问开始时间")
    private Date startTime;

    @ApiModelProperty(value = "访问结束时间")
    private Date endTime;
}
