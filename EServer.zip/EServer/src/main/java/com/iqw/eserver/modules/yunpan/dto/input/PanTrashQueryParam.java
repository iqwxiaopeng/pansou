package com.iqw.eserver.modules.yunpan.dto.input;

import com.baomidou.mybatisplus.annotations.TableField;
import com.iqw.eserver.modules.common.dto.input.BasePageQuery;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
* 垃圾回站条目表 查询参数
*
* @author: PanSou
* @description:
* @date: 2020-07-22
*/
@Data
@ApiModel(description = "垃圾回站条目表  查询参数")
public class PanTrashQueryParam extends BasePageQuery {
    @ApiModelProperty(value = "id")
    private Integer id;

    @ApiModelProperty(value = "用户id")
    private Long userId;


    @ApiModelProperty(value = "是否显示")
    private String visible;

    @ApiModelProperty(value = "删除前其所在的目录id")
    private Long folderId;

    @ApiModelProperty(value = "垃圾类型(文件,目录,随笔,日记等)")
    private Integer type;
}
