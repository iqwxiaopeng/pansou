package com.iqw.eserver.modules.yunpan.dto.input;

import com.baomidou.mybatisplus.annotations.TableField;
import com.iqw.eserver.modules.common.dto.input.BasePageQuery;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
* 重复文件表 查询参数
*
* @author: PanSou
* @description:
* @date: 2020-07-22
*/
@Data
@ApiModel(description = "重复文件表  查询参数")
public class StoreConflictQueryParam extends BasePageQuery {
    @ApiModelProperty(value = "id")
    private Integer id;

    @ApiModelProperty(value = "冲突的md5码")
    private String fileMd5;

    @ApiModelProperty(value = "冲突次数")
    private Integer repeatNum;

}
