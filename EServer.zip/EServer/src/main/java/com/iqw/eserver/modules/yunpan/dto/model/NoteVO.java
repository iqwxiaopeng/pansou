package com.iqw.eserver.modules.yunpan.dto.model;

import lombok.Data;

import java.sql.Timestamp;

/**
 * 云盘预览文件列表文件对象
 */
@Data
public class NoteVO {

    private long id;

    private long folderid;

    /**
     * 文件民
     */
    private String name;

    /**
     * 文件类型
     */
//    private int type;

    /**
     * 大小
     */
    private long size;

    /**
     * 图标
     */
    private String icon;

    /**
     * 更新时间
     */
    Timestamp gmtModified;

    String ext;

    String path;

    String keyword;

    boolean directory;

    String  content;

}
