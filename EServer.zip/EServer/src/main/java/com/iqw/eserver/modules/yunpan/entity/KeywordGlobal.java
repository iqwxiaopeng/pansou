package com.iqw.eserver.modules.yunpan.entity;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.Length;
import javax.validation.constraints.NotBlank;
import java.io.Serializable;

import com.baomidou.mybatisplus.enums.IdType;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.enums.IdType;
import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableName;
import com.iqw.eserver.modules.common.entity.BaseEntity;
import lombok.Data;

/**
* <p>  系统全部关键词表  </p>
*
* @author: PanSou
* @date: 2020-07-22
*/

@Data
@ApiModel(description = "系统全部关键词表 ")
@TableName("t_keyword_global")
public class KeywordGlobal extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /**
    * 关键词id
    */
    @ApiModelProperty(value = "关键词id")
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
    * 关键词
    */
    @ApiModelProperty(value = "关键词")
    @TableField("keyword")
    private String keyword;

    /**
    * 关键词大类0未知
    */
    @ApiModelProperty(value = "关键词大类0未知")
    @TableField("type_id")
    private Integer typeId;

    /**
    * 被引用次数
    */
    @ApiModelProperty(value = "被引用次数")
    @TableField("refnum")
    private Integer refnum;



    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}