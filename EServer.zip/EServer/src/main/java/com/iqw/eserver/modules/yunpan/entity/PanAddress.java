package com.iqw.eserver.modules.yunpan.entity;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.Length;
import javax.validation.constraints.NotBlank;
import java.io.Serializable;

import java.util.Date;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.enums.IdType;
import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableName;
import com.iqw.eserver.modules.common.entity.BaseEntity;
import lombok.Data;

/**
* <p>  通讯录表  </p>
*
* @author: PanSou
* @date: 2020-07-22
*/

@Data
@ApiModel(description = "通讯录表 ")
@TableName("t_pan_address")
public class PanAddress extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /**
    * 主键ID
    */
    @ApiModelProperty(value = "主键ID")
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
    * 姓名
    */
    @ApiModelProperty(value = "姓名")
    @TableField("name")
    private String name;

    /**
    * 文件关键词
    */
    @ApiModelProperty(value = "文件关键词")
    @TableField("keyword")
    private String keyword;

    /**
    * 分类目录
    */
    @ApiModelProperty(value = "分类目录")
    @TableField("folder_id")
    private Integer folderId;

    /**
    * 所有者
    */
    @ApiModelProperty(value = "所有者")
    @TableField("user_id")
    private Integer userId;

    /**
    * 手机号码
    */
    @ApiModelProperty(value = "手机号码")
    @TableField("phone")
    private String phone;

    /**
    * 生日
    */
    @ApiModelProperty(value = "生日")
    @TableField("birthday")
    private Date birthday;

    /**
    * 性别
    */
    @ApiModelProperty(value = "性别")
    @TableField("sex")
    private String sex;

    /**
    * 年龄
    */
    @ApiModelProperty(value = "年龄")
    @TableField("age")
    private Integer age;

    /**
    * 0未婚 1已婚
    */
    @ApiModelProperty(value = "0未婚 1已婚")
    @TableField("married")
    private String married;

    /**
    * 备注
    */
    @ApiModelProperty(value = "备注")
    @TableField("remarks")
    private String remarks;

    /**
    * 籍贯
    */
    @ApiModelProperty(value = "籍贯")
    @TableField("native_place")
    private String nativePlace;

    /**
    * 家庭住址
    */
    @ApiModelProperty(value = "家庭住址")
    @TableField("home_address")
    private String homeAddress;

    /**
    * 大学
    */
    @ApiModelProperty(value = "大学")
    @TableField("college")
    private String college;

    /**
    * 专业
    */
    @ApiModelProperty(value = "专业")
    @TableField("major")
    private String major;



    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}