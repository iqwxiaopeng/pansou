package com.iqw.eserver.modules.yunpan.entity;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.Length;
import javax.validation.constraints.NotBlank;
import java.io.Serializable;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.enums.IdType;
import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableName;
import com.iqw.eserver.modules.common.entity.BaseEntity;
import lombok.Data;

/**
* <p>  卡密表  </p>
*
* @author: PanSou
* @date: 2020-07-22
*/

@Data
@ApiModel(description = "卡密表 ")
@TableName("t_pan_card")
public class PanCard extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /**
    * 主键ID
    */
    @ApiModelProperty(value = "主键ID")
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
    * 卡片名
    */
    @ApiModelProperty(value = "卡片名")
    @TableField("name")
    private String name;

    /**
    * 描述信息
    */
    @ApiModelProperty(value = "描述信息")
    @TableField("remarks")
    private String remarks;

    /**
    * 卡关键词
    */
    @ApiModelProperty(value = "卡关键词")
    @TableField("keyword")
    private String keyword;

    /**
    * 卡额度
    */
    @ApiModelProperty(value = "卡额度")
    @TableField("money")
    private Integer money;

    /**
    * 持有者
    */
    @ApiModelProperty(value = "持有者")
    @TableField("user_id")
    private Integer userId;

    /**
    * 卡号
    */
    @ApiModelProperty(value = "卡号")
    @TableField("code")
    private String code;

    /**
    * 密码
    */
    @ApiModelProperty(value = "密码")
    @TableField("pwd")
    private String pwd;

    /**
    * 私密码(作用于密码)
    */
    @ApiModelProperty(value = "私密码(作用于密码)")
    @TableField("private_code")
    private String privateCode;



    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}