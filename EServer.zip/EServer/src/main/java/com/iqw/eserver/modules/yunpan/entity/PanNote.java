package com.iqw.eserver.modules.yunpan.entity;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.Length;
import javax.validation.constraints.NotBlank;
import java.io.Serializable;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.enums.IdType;
import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableName;
import com.iqw.eserver.modules.common.entity.BaseEntity;
import lombok.Data;

/**
* <p>  随笔表  </p>
*
* @author: PanSou
* @date: 2020-07-22
*/

@Data
@ApiModel(description = "随笔表 ")
@TableName("t_pan_note")
public class PanNote extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /**
    * 主键ID
    */
    @ApiModelProperty(value = "主键ID")
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /**
    * 随笔名
    */
    @ApiModelProperty(value = "随笔名")
    @TableField("name")
    private String name;

    /**
    * 随笔关键词
    */
    @ApiModelProperty(value = "随笔关键词")
    @TableField("keyword")
    private String keyword;

    /**
    * 随笔所在目录
    */
    @ApiModelProperty(value = "随笔所在目录")
    @TableField("folder_id")
    private Integer folderId;

    /**
    * 随笔大小
    */
    @ApiModelProperty(value = "随笔大小")
    @TableField("size")
    private Integer size;

    /**
    * 创造者
    */
    @ApiModelProperty(value = "创造者")
    @TableField("user_id")
    private Long userId;

    /**
    * 随笔内容
    */
    @ApiModelProperty(value = "随笔内容")
    @TableField("content")
    private String content;



    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}