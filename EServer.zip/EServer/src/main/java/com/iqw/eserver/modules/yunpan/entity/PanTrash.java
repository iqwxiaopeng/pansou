package com.iqw.eserver.modules.yunpan.entity;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.Length;
import javax.validation.constraints.NotBlank;
import java.io.Serializable;

import com.baomidou.mybatisplus.enums.IdType;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.enums.IdType;
import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableName;
import com.iqw.eserver.modules.common.entity.BaseEntity;
import lombok.Data;

/**
* <p>  垃圾回站条目表  </p>
*
* @author: PanSou
* @date: 2020-07-24
*/

@Data
@ApiModel(description = "垃圾回站条目表 ")
@TableName("t_pan_trash")
public class PanTrash extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /**
    * 主键ID
    */
    @ApiModelProperty(value = "主键ID")
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /**
    * 垃圾条目id(不唯一)
    */
    @ApiModelProperty(value = "垃圾条目id(不唯一)")
    @TableField("item_id")
    private Long itemId;

    /**
    * 垃圾类型(文件,目录,随笔,日记等)
    */
    @ApiModelProperty(value = "垃圾类型(文件,目录,随笔,日记等)")
    @TableField("type")
    private Integer type;

    /**
    * 大小
    */
    @ApiModelProperty(value = "大小")
    @TableField("size")
    private Long size;

    /**
    * 关键词
    */
    @ApiModelProperty(value = "关键词")
    @TableField("keyword")
    private String keyword;

    /**
    * 描述信息
    */
    @ApiModelProperty(value = "描述信息")
    @TableField("remarks")
    private String remarks;

    /**
    * 名字
    */
    @ApiModelProperty(value = "名字")
    @TableField("name")
    private String name;

    /**
    * md5码
    */
    @ApiModelProperty(value = "md5码")
    @TableField("md5")
    private String md5;

    /**
    * 删除前其所在的路径目录id列表(显示节点需要)
    */
    @ApiModelProperty(value = "删除前其所在的路径目录id列表(显示节点需要)")
    @TableField("path_ids")
    private String pathIds;

    /**
    * 删除路径(显示节点需要)
    */
    @ApiModelProperty(value = "删除路径(显示节点需要)")
    @TableField("path_name")
    private String pathName;

    /**
    * 删除前其所在的目录id
    */
    @ApiModelProperty(value = "删除前其所在的目录id")
    @TableField("folder_id")
    private Long folderId;

    /**
    * 所属用户
    */
    @ApiModelProperty(value = "所属用户")
    @TableField("user_id")
    private Long userId;

    /**
    * 0显示 1隐藏
    */
    @ApiModelProperty(value = "0显示 1隐藏")
    @TableField("visible")
    private String visible;



    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}