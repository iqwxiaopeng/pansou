package com.iqw.eserver.modules.yunpan.entity;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.Length;
import javax.validation.constraints.NotBlank;
import java.io.Serializable;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.enums.IdType;
import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableName;
import com.iqw.eserver.modules.common.entity.BaseEntity;
import lombok.Data;

/**
* <p>  重复文件表  </p>
*
* @author: PanSou
* @date: 2020-07-22
*/

@Data
@ApiModel(description = "重复文件表 ")
@TableName("t_store_conflict")
public class StoreConflict extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /**
    * 主键ID
    */
    @ApiModelProperty(value = "主键ID")
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /**
    * 冲突的md5码
    */
    @ApiModelProperty(value = "冲突的md5码")
    @TableField("file_md5")
    private String fileMd5;

    /**
    * 冲突次数
    */
    @ApiModelProperty(value = "冲突次数")
    @TableField("repeat_num")
    private Integer repeatNum;

    /**
    * 冲突文件大小
    */
    @ApiModelProperty(value = "冲突文件大小")
    @TableField("file_size")
    private Long fileSize;

    /**
    * 冲突文件在disk中的名字
    */
    @ApiModelProperty(value = "冲突文件在disk中的名字")
    @TableField("file_name")
    private String fileName;



    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}