package com.iqw.eserver.modules.yunpan.entity;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.Length;
import javax.validation.constraints.NotBlank;
import java.io.Serializable;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.enums.IdType;
import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableName;
import com.iqw.eserver.modules.common.entity.BaseEntity;
import lombok.Data;

/**
* <p>  分布式哈希存储节点表  </p>
*
* @author: PanSou
* @date: 2020-07-22
*/

@Data
@ApiModel(description = "分布式哈希存储节点表 ")
@TableName("t_store_dht")
public class StoreDht extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /**
    * 主键ID
    */
    @ApiModelProperty(value = "主键ID")
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /**
    * dht节点md5唯一码
    */
    @ApiModelProperty(value = "dht节点md5唯一码")
    @TableField("node_hash")
    private String nodeHash;

    /**
    * dht节点所属真实节点id(t_store_node)表中
    */
    @ApiModelProperty(value = "dht节点所属真实节点id(t_store_node)表中")
    @TableField("store_node_id")
    private Long storeNodeId;



    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}