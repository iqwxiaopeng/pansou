package com.iqw.eserver.modules.yunpan.entity;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.Length;
import javax.validation.constraints.NotBlank;
import java.io.Serializable;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.enums.IdType;
import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableName;
import com.iqw.eserver.modules.common.entity.BaseEntity;
import lombok.Data;

/**
* <p>  物理存储节点表  </p>
*
* @author: PanSou
* @date: 2020-07-22
*/

@Data
@ApiModel(description = "物理存储节点表 ")
@TableName("t_store_node")
public class StoreNode extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /**
    * 主键ID
    */
    @ApiModelProperty(value = "主键ID")
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /**
    * 节点创建者
    */
    @ApiModelProperty(value = "节点创建者")
    @TableField("user_id")
    private Long userId;

    /**
    * 节点容量
    */
    @ApiModelProperty(value = "节点容量")
    @TableField("capacity")
    private Long capacity;

    /**
    * 节点可用容量
    */
    @ApiModelProperty(value = "节点可用容量")
    @TableField("capacity_left")
    private Long capacityLeft;

    /**
    * 节点状态(0可用  1不可用)
    */
    @ApiModelProperty(value = "节点状态(0可用  1不可用)")
    @TableField("node_state")
    private String nodeState;

    /**
    * 存储路径
    */
    @ApiModelProperty(value = "存储路径")
    @TableField("store_path")
    private String storePath;



    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}