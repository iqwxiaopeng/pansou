package com.iqw.eserver.modules.yunpan.entity;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.Length;
import javax.validation.constraints.NotBlank;
import java.io.Serializable;

import com.baomidou.mybatisplus.enums.IdType;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.enums.IdType;
import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableName;
import com.iqw.eserver.modules.common.entity.BaseEntity;
import lombok.Data;

/**
* <p>  云盘文件表  </p>
*
* @author: PanSou
* @date: 2020-08-05
*/

@Data
@ApiModel(description = "云盘文件表 ")
@TableName("t_uploading_file")
public class UploadingFile extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /**
    * 主键ID
    */
    @ApiModelProperty(value = "主键ID")
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /**
    * 文件名
    */
    @ApiModelProperty(value = "文件名")
    @TableField("name")
    private String name;

    /**
    * 文件md5
    */
    @ApiModelProperty(value = "文件md5")
    @TableField("md5")
    private String md5;

    /**
    * 文件待传目录
    */
    @ApiModelProperty(value = "文件待传目录")
    @TableField("folder_id")
    private Long folderId;

    /**
    * 相对路径
    */
    @ApiModelProperty(value = "相对路径")
    @TableField("relative_path")
    private String relativePath;

    /**
    * 文件大小
    */
    @ApiModelProperty(value = "文件大小")
    @TableField("size")
    private Long size;

    /**
    * 所有者
    */
    @ApiModelProperty(value = "所有者")
    @TableField("user_id")
    private Integer userId;



    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}