package com.iqw.eserver.modules.yunpan.mapper;

import com.iqw.eserver.modules.yunpan.entity.KeywordGlobal;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.iqw.eserver.modules.yunpan.dto.input.KeywordGlobalQueryParam;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;
/**
* <p> 系统全部关键词表  Mapper 接口 </p>
*
* @author : PanSou
* @date : 2020-07-22
*/
public interface KeywordGlobalMapper extends BaseMapper<KeywordGlobal> {

    /**
    * 列表分页
    *
    * @param page
    * @param filter
    * @return
    */
    List<KeywordGlobal> selectKeywordGlobals(Pagination page, @Param("filter") KeywordGlobalQueryParam filter);

    /**
    * 列表
    *
    * @param filter
    * @return
    */
    List<KeywordGlobal> selectKeywordGlobals(@Param("filter") KeywordGlobalQueryParam filter);


    /**
     * 获取关键字
     * @return
     */
    @Select("SELECT * FROM t_keyword_global WHERE keyword = #{keyword} limit 1 ")
    KeywordGlobal selectByKeyword(@Param("keyword") String keyword);

    /**
     * 获取关键字
     * @return
     */
    @Select("SELECT * FROM t_keyword_global limit #{limit} ")
    List<KeywordGlobal>  selectByLimit(@Param("limit") int limit);

    /**
     * 获取关键字
     * @return
     */
    @Select("SELECT * FROM t_keyword_global WHERE keyword like concat('%',#{word},'%') limit #{limit} ")
    List<KeywordGlobal> selectLikeByKeyword(@Param("word") String word, @Param("limit") int limit);
}
