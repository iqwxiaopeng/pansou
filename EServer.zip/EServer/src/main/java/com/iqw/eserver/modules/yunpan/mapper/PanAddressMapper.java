package com.iqw.eserver.modules.yunpan.mapper;

import com.iqw.eserver.modules.yunpan.entity.PanAddress;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.iqw.eserver.modules.yunpan.dto.input.PanAddressQueryParam;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;
import org.apache.ibatis.annotations.Param;
import java.util.List;
/**
* <p> 通讯录表  Mapper 接口 </p>
*
* @author : PanSou
* @date : 2020-07-22
*/
public interface PanAddressMapper extends BaseMapper<PanAddress> {

    /**
    * 列表分页
    *
    * @param page
    * @param filter
    * @return
    */
    List<PanAddress> selectPanAddresss(Pagination page, @Param("filter") PanAddressQueryParam filter);

    /**
    * 列表
    *
    * @param filter
    * @return
    */
    List<PanAddress> selectPanAddresss(@Param("filter") PanAddressQueryParam filter);
}
