package com.iqw.eserver.modules.yunpan.mapper;

import com.iqw.eserver.modules.yunpan.entity.PanTrash;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.iqw.eserver.modules.yunpan.dto.input.PanTrashQueryParam;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;
import org.apache.ibatis.annotations.Param;
import java.util.List;
/**
* <p> 垃圾回站条目表  Mapper 接口 </p>
*
* @author : PanSou
* @date : 2020-07-22
*/
public interface PanTrashMapper extends BaseMapper<PanTrash> {

    /**
    * 列表分页
    *
    * @param page
    * @param filter
    * @return
    */
    List<PanTrash> selectPanTrashs(Pagination page, @Param("filter") PanTrashQueryParam filter);

    /**
    * 列表
    *
    * @param filter
    * @return
    */
    List<PanTrash> selectPanTrashs(@Param("filter") PanTrashQueryParam filter);
}
