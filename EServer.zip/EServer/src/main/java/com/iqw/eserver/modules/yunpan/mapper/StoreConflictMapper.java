package com.iqw.eserver.modules.yunpan.mapper;

import com.iqw.eserver.modules.yunpan.entity.StoreConflict;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.iqw.eserver.modules.yunpan.dto.input.StoreConflictQueryParam;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;
import org.apache.ibatis.annotations.Param;
import java.util.List;
/**
* <p> 重复文件表  Mapper 接口 </p>
*
* @author : PanSou
* @date : 2020-07-22
*/
public interface StoreConflictMapper extends BaseMapper<StoreConflict> {

    /**
    * 列表分页
    *
    * @param page
    * @param filter
    * @return
    */
    List<StoreConflict> selectStoreConflicts(Pagination page, @Param("filter") StoreConflictQueryParam filter);

    /**
    * 列表
    *
    * @param filter
    * @return
    */
    List<StoreConflict> selectStoreConflicts(@Param("filter") StoreConflictQueryParam filter);

    /**
     * 根据filemd5查找节点
     */
    StoreConflict selectByFileMd5(@Param("fileMd5") String fileMd5);
}
