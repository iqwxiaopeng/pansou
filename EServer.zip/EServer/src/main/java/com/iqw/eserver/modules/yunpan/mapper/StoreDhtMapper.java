package com.iqw.eserver.modules.yunpan.mapper;

import com.iqw.eserver.modules.yunpan.entity.StoreDht;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.iqw.eserver.modules.yunpan.dto.input.StoreDhtQueryParam;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;
/**
* <p> 分布式哈希存储节点表  Mapper 接口 </p>
*
* @author : PanSou
* @date : 2020-07-22
*/
public interface StoreDhtMapper extends BaseMapper<StoreDht> {

    /**
    * 列表分页
    *
    * @param page
    * @param filter
    * @return
    */
    List<StoreDht> selectStoreDhts(Pagination page, @Param("filter") StoreDhtQueryParam filter);

    /**
    * 列表
    *
    * @param filter
    * @return
    */
    List<StoreDht> selectStoreDhts(@Param("filter") StoreDhtQueryParam filter);

    /**
     * 获取物理节点的所有虚拟节点表
     * @return
     */
    List<StoreDht> selectByStoreNodeId(@Param("storeNodeId") Long storeNodeId);

    /**
     * 删除物理节点的所有虚拟节点表
     * @return
     */
    Integer deleteByStoreNodeId(@Param("storeNodeId") Long storeNodeId);

    /**
     * 获取最大的虚拟点
     * @return
     */
    StoreDht selectMaxDht();

    /**
     * 获取最小的虚拟点
     * @return
     */
    StoreDht selectMinDht();

    /**
     * 获取恰好大于给定点的虚拟点
     * @param node_hash
     * @return
     */
    StoreDht selectJustBigByNodeHash(String node_hash);

    /**
     * 获取恰好小于给定点的虚拟点
     * @param node_hash
     * @return
     */
    StoreDht selectJustSmallByNodeHash(String node_hash);


}
