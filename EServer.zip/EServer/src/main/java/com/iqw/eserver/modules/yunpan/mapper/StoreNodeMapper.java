package com.iqw.eserver.modules.yunpan.mapper;

import com.iqw.eserver.modules.yunpan.entity.StoreNode;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.iqw.eserver.modules.yunpan.dto.input.StoreNodeQueryParam;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;
import org.apache.ibatis.annotations.Param;
import java.util.List;
/**
* <p> 物理存储节点表  Mapper 接口 </p>
*
* @author : PanSou
* @date : 2020-07-22
*/
public interface StoreNodeMapper extends BaseMapper<StoreNode> {

    /**
    * 列表分页
    *
    * @param page
    * @param filter
    * @return
    */
    List<StoreNode> selectStoreNodes(Pagination page, @Param("filter") StoreNodeQueryParam filter);

    /**
    * 列表
    *
    * @param filter
    * @return
    */
    List<StoreNode> selectStoreNodes(@Param("filter") StoreNodeQueryParam filter);


    /**
     * 检索剩余容量小于等于指定容量的节点
     * @return
     */
    List<StoreNode> selectSmallByCapacityLeft(long capacity_left);


    /**
     * 检索路径所属节点
     * @return
     */
    List<StoreNode> selectByPath(@Param("storePath") String storePath);
}
