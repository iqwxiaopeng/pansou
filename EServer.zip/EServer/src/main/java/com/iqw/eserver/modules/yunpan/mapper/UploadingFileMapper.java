package com.iqw.eserver.modules.yunpan.mapper;

import com.iqw.eserver.modules.yunpan.entity.UploadingFile;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.iqw.eserver.modules.yunpan.dto.input.UploadingFileQueryParam;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;
import org.apache.ibatis.annotations.Param;
import java.util.List;
/**
* <p> 云盘文件表  Mapper 接口 </p>
*
* @author : PanSou
* @date : 2020-08-05
*/
public interface UploadingFileMapper extends BaseMapper<UploadingFile> {

    /**
    * 列表分页
    *
    * @param page
    * @param filter
    * @return
    */
    List<UploadingFile> selectUploadingFiles(Pagination page, @Param("filter") UploadingFileQueryParam filter);

    /**
    * 列表
    *
    * @param filter
    * @return
    */
    List<UploadingFile> selectUploadingFiles(@Param("filter") UploadingFileQueryParam filter);
}
