package com.iqw.eserver.modules.yunpan.service;

import com.iqw.eserver.modules.yunpan.entity.KeywordGlobal;
import com.baomidou.mybatisplus.service.IService;
import com.baomidou.mybatisplus.plugins.Page;
import com.iqw.eserver.modules.yunpan.dto.input.KeywordGlobalQueryParam;
import java.util.List;

/**
* <p>* 系统全部关键词表 服务类</p>
*
* @author : PanSou
* @date : 2020-07-22
*/
public interface IKeywordGlobalService extends IService<KeywordGlobal> {

    /**
    * 系统全部关键词表列表分页
    *
    * @param page
    * @param param
    * @return
    */
    void listPage(Page<KeywordGlobal> page, KeywordGlobalQueryParam param);


    /**
    * 保存系统全部关键词表
    *
    * @param input
    */
    Integer save(KeywordGlobal input);


    /**
    * 系统全部关键词表列表
    *
    * @param param
    * @return
    */
    List<KeywordGlobal> list(KeywordGlobalQueryParam param);


    void changeKeyWordRef(String word, int refChange);

    void changeKeyWordListRef(List<String> word, int refChange);
}
