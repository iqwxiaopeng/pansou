package com.iqw.eserver.modules.yunpan.service;

import com.iqw.eserver.modules.yunpan.entity.PanAddress;
import com.baomidou.mybatisplus.service.IService;
import com.baomidou.mybatisplus.plugins.Page;
import com.iqw.eserver.modules.yunpan.dto.input.PanAddressQueryParam;
import java.util.List;

/**
* <p>* 通讯录表 服务类</p>
*
* @author : PanSou
* @date : 2020-07-22
*/
public interface IPanAddressService extends IService<PanAddress> {

    /**
    * 通讯录表列表分页
    *
    * @param page
    * @param param
    * @return
    */
    void listPage(Page<PanAddress> page, PanAddressQueryParam param);


    /**
    * 保存通讯录表
    *
    * @param input
    */
    Integer save(PanAddress input);


    /**
    * 通讯录表列表
    *
    * @param param
    * @return
    */
    List<PanAddress> list(PanAddressQueryParam param);

}
