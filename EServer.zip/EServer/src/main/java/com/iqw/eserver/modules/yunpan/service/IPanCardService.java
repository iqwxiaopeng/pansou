package com.iqw.eserver.modules.yunpan.service;

import com.iqw.eserver.modules.yunpan.entity.PanCard;
import com.baomidou.mybatisplus.service.IService;
import com.baomidou.mybatisplus.plugins.Page;
import com.iqw.eserver.modules.yunpan.dto.input.PanCardQueryParam;
import java.util.List;

/**
* <p>* 卡密表 服务类</p>
*
* @author : PanSou
* @date : 2020-07-22
*/
public interface IPanCardService extends IService<PanCard> {

    /**
    * 卡密表列表分页
    *
    * @param page
    * @param param
    * @return
    */
    void listPage(Page<PanCard> page, PanCardQueryParam param);


    /**
    * 保存卡密表
    *
    * @param input
    */
    Integer save(PanCard input);


    /**
    * 卡密表列表
    *
    * @param param
    * @return
    */
    List<PanCard> list(PanCardQueryParam param);

}
