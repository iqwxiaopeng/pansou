package com.iqw.eserver.modules.yunpan.service;

import com.iqw.eserver.modules.yunpan.dto.model.FileVO;
import com.iqw.eserver.modules.yunpan.entity.PanFile;
import com.baomidou.mybatisplus.service.IService;
import com.baomidou.mybatisplus.plugins.Page;
import com.iqw.eserver.modules.yunpan.dto.input.PanFileQueryParam;
import java.util.List;

/**
* <p>* 云盘文件表 服务类</p>
*
* @author : PanSou
* @date : 2020-07-22
*/
public interface IPanFileService extends IService<PanFile> {

    /**
    * 云盘文件表列表分页
    *
    * @param page
    * @param param
    * @return
    */
    void listPage(Page<PanFile> page, PanFileQueryParam param);


    /**
    * 保存云盘文件表
    *
    * @param input
    */
    Long save(PanFile input);


    /**
    * 云盘文件表列表
    *
    * @param param
    * @return
    */
    List<PanFile> list(PanFileQueryParam param);



    /**
     * 移动文件夹位置
     * @param idList
     * @return
     */
    boolean moveFiles(List<Long> idList, List<Long> errIds, Long parent_id, boolean bKeepBoth);


    /**
     * 复制文件夹
     * @param idList
     * @param parent_id 要复制到的位置
     * @return
     */
    boolean copyFiles(List<Long> idList,List<Long> errIds, Long parent_id, boolean bKeepBoth);



    /**
     * 新建用户文件 es相关
     * @param parent_id 所在目录
     * @param name
     * @return
     */
    boolean newFile(Long parent_id, Long user_id, String name, String filePath, String keyword, String description);


    /**
     * 新建用户文件 es相关
     * @param folder_id 所在目录
     * @param name
     * @return
     */
    boolean newDirectory(Long folder_id, Long user_id, String name, String keyword, String description);

    /**
     * 更新文件信息
     * @param id
     * @param name
     * @return
     */
    boolean updateFileInfo(Long id, String name, String keyword, String description);



    /**
     *拉取显示文件列表 0是拉取根目录
     * @param folder_id
     * @return
     */
    List<FileVO> listFiles(long userId, long folder_id);

    /**
     *拉取子目录
     * @param folder_id
     * @return
     */
    List<FileVO> listDirectorys(long userId, long folder_id);

    /**
     * 丢弃文件到垃圾回收站
     * @param idList
     * @return
     */
    boolean deleteFilesToTrash(List<Long> idList);
}
