package com.iqw.eserver.modules.yunpan.service;

import com.iqw.eserver.modules.yunpan.entity.PanNote;
import com.baomidou.mybatisplus.service.IService;
import com.baomidou.mybatisplus.plugins.Page;
import com.iqw.eserver.modules.yunpan.dto.input.PanNoteQueryParam;
import java.util.List;

/**
* <p>* 随笔表 服务类</p>
*
* @author : PanSou
* @date : 2020-07-22
*/
public interface IPanNoteService extends IService<PanNote> {

    /**
    * 随笔表列表分页
    *
    * @param page
    * @param param
    * @return
    */
    void listPage(Page<PanNote> page, PanNoteQueryParam param);


    /**
    * 保存随笔表
    *
    * @param input
    */
    Long save(PanNote input);


    /**
    * 随笔表列表
    *
    * @param param
    * @return
    */
    List<PanNote> list(PanNoteQueryParam param);

    /**
     * 新建随笔
     * @param userId
     * @param name
     * @param keywords
     * @param remarks
     * @return
     */
    boolean newNote(long userId, String name, String keywords, String remarks);

    /**
     * 更新随笔
     * @param id
     * @param name
     * @param keywords
     * @param remarks
     * @return
     */
    boolean updateNote(long id, String name, String keywords, String remarks);


    /**
     * 删除随笔
     * @param idList
     * @return
     */
    boolean deleteNotesToTrash(List<Long> idList);
}
