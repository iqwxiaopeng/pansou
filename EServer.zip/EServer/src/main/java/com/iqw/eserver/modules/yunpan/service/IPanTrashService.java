package com.iqw.eserver.modules.yunpan.service;

import com.iqw.eserver.modules.yunpan.entity.PanTrash;
import com.baomidou.mybatisplus.service.IService;
import com.baomidou.mybatisplus.plugins.Page;
import com.iqw.eserver.modules.yunpan.dto.input.PanTrashQueryParam;
import io.swagger.models.auth.In;

import java.io.IOException;
import java.util.List;

/**
* <p>* 垃圾回站条目表 服务类</p>
*
* @author : PanSou
* @date : 2020-07-22
*/
public interface IPanTrashService extends IService<PanTrash> {

    /**
    * 垃圾回站条目表列表分页
    *
    * @param page
    * @param param
    * @return
    */
    void listPage(Page<PanTrash> page, PanTrashQueryParam param);


    /**
    * 保存垃圾回站条目表
    *
    * @param input
    */
    Long save(PanTrash input);


    /**
    * 垃圾回站条目表列表
    *
    * @param param
    * @return
    */
    List<PanTrash> list(PanTrashQueryParam param);

    /**
     * 清空回收站 需要实际删除文件
     * @return
     */
    boolean emptyTrash(Long user_id) throws IOException;


    /**
     * 还原回收站内容 还原必须先拉还原提示只能一个个还原
     * @param overWrite 是否替换已有
     * @param user_id
     * @return
     */
    boolean restoreTrash(Long id, Long user_id, boolean overWrite);


    /**
     * 还原回收站内容 还原必须先拉还原提示只能一个个还原
     * @param user_id
     * @return
     */
    boolean restoreAllTrash(Long id, Long user_id, List<Boolean> overWriteList);




    /**
     * 拉回收站列表
     * @param user_id
     * @return
     */
    boolean listTrash(Long user_id);
}
