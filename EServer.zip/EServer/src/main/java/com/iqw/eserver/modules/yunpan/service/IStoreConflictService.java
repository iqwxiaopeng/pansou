package com.iqw.eserver.modules.yunpan.service;

import com.iqw.eserver.modules.yunpan.entity.StoreConflict;
import com.baomidou.mybatisplus.service.IService;
import com.baomidou.mybatisplus.plugins.Page;
import com.iqw.eserver.modules.yunpan.dto.input.StoreConflictQueryParam;
import java.util.List;

/**
* <p>* 重复文件表 服务类</p>
*
* @author : PanSou
* @date : 2020-07-22
*/
public interface IStoreConflictService extends IService<StoreConflict> {

    /**
    * 重复文件表列表分页
    *
    * @param page
    * @param param
    * @return
    */
    void listPage(Page<StoreConflict> page, StoreConflictQueryParam param);


    /**
    * 保存重复文件表
    *
     * @param input
     * @return
     */
    Long save(StoreConflict input);


    /**
    * 重复文件表列表
    *
    * @param param
    * @return
    */
    List<StoreConflict> list(StoreConflictQueryParam param);



}
