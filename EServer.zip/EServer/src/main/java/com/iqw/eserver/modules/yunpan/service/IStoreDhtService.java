package com.iqw.eserver.modules.yunpan.service;

import com.iqw.eserver.modules.yunpan.entity.StoreDht;
import com.baomidou.mybatisplus.service.IService;
import com.baomidou.mybatisplus.plugins.Page;
import com.iqw.eserver.modules.yunpan.dto.input.StoreDhtQueryParam;
import java.util.List;

/**
* <p>* 分布式哈希存储节点表 服务类</p>
*
* @author : PanSou
* @date : 2020-07-22
*/
public interface IStoreDhtService extends IService<StoreDht> {

    /**
    * 分布式哈希存储节点表列表分页
    *
    * @param page
    * @param param
    * @return
    */
    void listPage(Page<StoreDht> page, StoreDhtQueryParam param);


    /**
    * 保存分布式哈希存储节点表
    *
     * @param input
     * @return
     */
    Long save(StoreDht input);


    /**
    * 分布式哈希存储节点表列表
    *
    * @param param
    * @return
    */
    List<StoreDht> list(StoreDhtQueryParam param);


    /**
     * 获取哈希的2邻居节点 0为小，1为大
     *
     * @param hashTag
     * @return
     */
     List<StoreDht> getClostDht(String hashTag);


    /**
     * 获取哈希映射的虚拟节点 以恰好大存储
     *
     * @param hashTag
     * @return
     */
    public StoreDht getMappingDht(String hashTag);

}
