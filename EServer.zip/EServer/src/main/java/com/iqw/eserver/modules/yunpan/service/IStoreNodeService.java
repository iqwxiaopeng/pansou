package com.iqw.eserver.modules.yunpan.service;

import com.iqw.eserver.modules.yunpan.entity.StoreNode;
import com.baomidou.mybatisplus.service.IService;
import com.baomidou.mybatisplus.plugins.Page;
import com.iqw.eserver.modules.yunpan.dto.input.StoreNodeQueryParam;

import java.io.IOException;
import java.util.List;

/**
* <p>* 物理存储节点表 服务类</p>
*
* @author : PanSou
* @date : 2020-07-22
*/
public interface IStoreNodeService extends IService<StoreNode> {

    /**
    * 物理存储节点表列表分页
    *
    * @param page
    * @param param
    * @return
    */
    void listPage(Page<StoreNode> page, StoreNodeQueryParam param);


    /**
    * 保存物理存储节点表
    *
     * @param input
     * @return
     */
    Long save(StoreNode input);


    /**
    * 物理存储节点表列表
    *
    * @param param
    * @return
    */
    List<StoreNode> list(StoreNodeQueryParam param);


    /**
     * 注册数据节点
     *
     * @param userId
     * @param storePath
     * @param capacity
     *
     * @return 成功true 失败false
     */
    boolean registerStoreNode(Long userId, String storePath, Long capacity);


    /**
     * 移除数据节点
     *
     * @param userId
     * @param id
     *
     * @return 成功true 失败false
     */
    boolean removeStoreNode(Long userId, Long id);


    /**
     * 物理扩容
     *
     * @param userId
     * @param id
     * @param capacityChange 正为扩容 符号为降容 降容不能低于实际存储
     *
     * @return 成功true 失败false
     */
    boolean changeStoreCapacity(Long userId, Long id, long capacityChange);


    /**
     * 存储文件数据 检查重复
     *
     * @param userId
     *
     * @return 成功true 失败false
     */
    boolean storeFile(Long userId, String fileTag, String filePath);


    /**
     * 存储文件数据 检查重复
     *
     * @param userId
     *
     * @return 成功true 失败false
     */
    boolean getFile(Long userId, String fileTag, String outPath);

    /**
     * 检查文件是否存在
     *
     * @param fileTag
     *
     * @return 成功true 失败false
     */
    boolean isFileExit(String fileTag);

    /**
     * 存储重复文件
     *
     * @param userId
     *
     * @return 成功true 失败false
     */
    boolean storeExistFile(Long userId, String fileTag,String fileName, long fileSize);


    /**
     * 删除文件数据 检查引用
     *
     * @param userId
     *
     * @return 成功true 失败false
     */
    boolean removeFile(Long userId, String fileTag) throws IOException;

}
