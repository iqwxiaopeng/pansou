package com.iqw.eserver.modules.yunpan.service;

import com.iqw.eserver.modules.yunpan.entity.UploadingFile;
import com.baomidou.mybatisplus.service.IService;
import com.baomidou.mybatisplus.plugins.Page;
import com.iqw.eserver.modules.yunpan.dto.input.UploadingFileQueryParam;
import java.util.List;

/**
* <p>* 云盘文件表 服务类</p>
*
* @author : PanSou
* @date : 2020-08-05
*/
public interface IUploadingFileService extends IService<UploadingFile> {

    /**
    * 云盘文件表列表分页
    *
    * @param page
    * @param param
    * @return
    */
    void listPage(Page<UploadingFile> page, UploadingFileQueryParam param);


    /**
    * 保存云盘文件表
    *
    * @param input
    */
    Long save(UploadingFile input);


    /**
    * 云盘文件表列表
    *
    * @param param
    * @return
    */
    List<UploadingFile> list(UploadingFileQueryParam param);

}
