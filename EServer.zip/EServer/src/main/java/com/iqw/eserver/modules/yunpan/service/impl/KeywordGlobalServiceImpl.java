package com.iqw.eserver.modules.yunpan.service.impl;

import com.baomidou.mybatisplus.plugins.Page;
import com.iqw.eserver.base.utils.HashUtil;
import com.iqw.eserver.modules.yunpan.entity.KeywordGlobal;
import com.iqw.eserver.modules.yunpan.mapper.KeywordGlobalMapper;
import com.iqw.eserver.modules.yunpan.service.IKeywordGlobalService;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.iqw.eserver.modules.yunpan.dto.input.KeywordGlobalQueryParam;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

/**
* <p> 系统全部关键词表 服务类</p>
*
* @author: PanSou
* @date: 2020-07-22
*/
@Service
@Transactional
public class KeywordGlobalServiceImpl extends ServiceImpl<KeywordGlobalMapper, KeywordGlobal> implements IKeywordGlobalService {

    @Autowired(required = false)
    KeywordGlobalMapper keywordGlobalMapper;


    @Override
    public void listPage(Page<KeywordGlobal> page, KeywordGlobalQueryParam filter) {
        page.setRecords(keywordGlobalMapper.selectKeywordGlobals(page, filter));
    }

    @Override
    public List<KeywordGlobal> list(KeywordGlobalQueryParam filter) {
        return keywordGlobalMapper.selectKeywordGlobals(filter);
    }


    private void addKeyWordRef(String keyword, int refNum) {
        KeywordGlobal keywordGlobal = new KeywordGlobal();
        keywordGlobal.setRefnum(refNum);
        keywordGlobal.setTypeId(0);

        KeywordGlobal tmp = keywordGlobalMapper.selectByKeyword(keyword);
        if (tmp == null){
            keywordGlobal.setKeyword(keyword);
            save(keywordGlobal);
        }else {
            tmp.setRefnum(tmp.getRefnum() + refNum);
            save(tmp);
        }

    }

    //减少关键词的引用计数
    private void subKeyWordRef(String word, int refChange)
    {
        KeywordGlobal keywordGlobal = keywordGlobalMapper.selectByKeyword(word);
        if (keywordGlobal == null){
            return;
        }else {
            int ref = keywordGlobal.getRefnum() - refChange;
            if (ref < 0){
                ref = 0;
            }
            keywordGlobal.setRefnum(ref);
            save(keywordGlobal);
        }
    }

    @Override
    public void changeKeyWordRef(String word, int refChange){
        if (refChange > 0){
            addKeyWordRef(word, refChange);
        }else{
            subKeyWordRef(word, -refChange);
        }
    }

    @Override
    public void changeKeyWordListRef(List<String> word, int refChange) {
        for (String keyword:word){
            changeKeyWordRef(keyword, refChange);
        }
    }

    @Override
    public Integer save(KeywordGlobal param) {
        if (param.getId()!=null) {
            keywordGlobalMapper.updateById(param);
        } else {
            keywordGlobalMapper.insert(param);
        }
        return param.getId();
    }

}
