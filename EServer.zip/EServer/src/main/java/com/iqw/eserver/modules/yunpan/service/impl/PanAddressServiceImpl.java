package com.iqw.eserver.modules.yunpan.service.impl;

import com.baomidou.mybatisplus.plugins.Page;
import com.iqw.eserver.modules.yunpan.entity.PanAddress;
import com.iqw.eserver.modules.yunpan.mapper.PanAddressMapper;
import com.iqw.eserver.modules.yunpan.service.IPanAddressService;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.iqw.eserver.modules.yunpan.dto.input.PanAddressQueryParam;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

/**
* <p> 通讯录表 服务类</p>
*
* @author: PanSou
* @date: 2020-07-22
*/
@Service
@Transactional
public class PanAddressServiceImpl extends ServiceImpl<PanAddressMapper, PanAddress> implements IPanAddressService {

    @Autowired(required = false)
    PanAddressMapper panAddressMapper;


    @Override
    public void listPage(Page<PanAddress> page, PanAddressQueryParam filter) {
        page.setRecords(panAddressMapper.selectPanAddresss(page, filter));
    }

    @Override
    public List<PanAddress> list(PanAddressQueryParam filter) {
        return panAddressMapper.selectPanAddresss(filter);
    }

    @Override
    public Integer save(PanAddress param) {
        if (param.getId()!=null) {
            panAddressMapper.updateById(param);
        } else {
            panAddressMapper.insert(param);
        }
        return param.getId();
    }

}
