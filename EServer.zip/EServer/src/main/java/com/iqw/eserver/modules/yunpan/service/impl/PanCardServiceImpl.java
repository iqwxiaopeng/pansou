package com.iqw.eserver.modules.yunpan.service.impl;

import com.baomidou.mybatisplus.plugins.Page;
import com.iqw.eserver.modules.yunpan.entity.PanCard;
import com.iqw.eserver.modules.yunpan.mapper.PanCardMapper;
import com.iqw.eserver.modules.yunpan.service.IPanCardService;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.iqw.eserver.modules.yunpan.dto.input.PanCardQueryParam;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

/**
* <p> 卡密表 服务类</p>
*
* @author: PanSou
* @date: 2020-07-22
*/
@Service
@Transactional
public class PanCardServiceImpl extends ServiceImpl<PanCardMapper, PanCard> implements IPanCardService {

    @Autowired(required = false)
    PanCardMapper panCardMapper;


    @Override
    public void listPage(Page<PanCard> page, PanCardQueryParam filter) {
        page.setRecords(panCardMapper.selectPanCards(page, filter));
    }

    @Override
    public List<PanCard> list(PanCardQueryParam filter) {
        return panCardMapper.selectPanCards(filter);
    }

    @Override
    public Integer save(PanCard param) {
        if (param.getId()!=null) {
            panCardMapper.updateById(param);
        } else {
            panCardMapper.insert(param);
        }
        return param.getId();
    }

}
