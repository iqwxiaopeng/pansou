package com.iqw.eserver.modules.yunpan.service.impl;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.iqw.eserver.base.utils.FileUtil;
import com.iqw.eserver.base.utils.Md5Util;
import com.iqw.eserver.base.utils.StringUtil;
//import com.iqw.eserver.modules.es.entity.EsFile;
import com.iqw.eserver.modules.es.entity.EsFile;
import com.iqw.eserver.modules.es.mapper.EsDaoUtil;
import com.iqw.eserver.modules.yunpan.dto.model.FileVO;
import com.iqw.eserver.modules.yunpan.entity.PanFile;
import com.iqw.eserver.modules.yunpan.entity.PanTrash;
import com.iqw.eserver.modules.yunpan.mapper.KeywordGlobalMapper;
import com.iqw.eserver.modules.yunpan.mapper.PanFileMapper;
import com.iqw.eserver.modules.yunpan.service.IKeywordGlobalService;
import com.iqw.eserver.modules.yunpan.service.IPanFileService;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.iqw.eserver.modules.yunpan.dto.input.PanFileQueryParam;
import com.iqw.eserver.modules.yunpan.service.IPanTrashService;
import com.iqw.eserver.modules.yunpan.service.IStoreNodeService;
//import com.iqw.eserver.modules.es.mapper.EsDaoUtil;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Timestamp;
import java.util.*;

/**
* <p> 云盘文件表 服务类</p>
*
* @author: PanSou
* @date: 2020-07-22
*/
@Service
@Transactional
public class PanFileServiceImpl extends ServiceImpl<PanFileMapper, PanFile> implements IPanFileService {

    @Autowired(required = false)
    PanFileMapper panFileMapper;

    @Autowired(required = false)
    IKeywordGlobalService keywordGlobalService;


    @Autowired(required = false)
    IStoreNodeService storeNodeService;

    @Autowired(required = false)
    IPanTrashService panTrashService;

    @Autowired
    private EsDaoUtil esDaoUtil;

    private boolean IsDirecory(PanFile panFile){
        if (panFile.getSize() == 0){
            return  true;
        }
        return false;
    }

    private FileVO panFileToFileVO(PanFile panFile){
        FileVO fileVO = new FileVO();
        fileVO.setId(panFile.getId());
        fileVO.setName(panFile.getName());
        fileVO.setExt(FileUtil.getFileExtension(panFile.getName()));
        fileVO.setUpdateTime(new Timestamp(panFile.getGmtModified().getTime()));
        fileVO.setDirectory(IsDirecory(panFile));
        fileVO.setSize(panFile.getSize());
        fileVO.setKeyword(panFile.getKeyword());
        fileVO.setRemarks(panFile.getRemarks());
        return fileVO;
    }

    private PanTrash panFileToTrash(PanFile panFile){
        PanTrash panTrash = new PanTrash();
        panTrash.setFolderId(panFile.getFolderId());
        panTrash.setItemId(panFile.getId());
        panTrash.setKeyword(panFile.getKeyword());
        panTrash.setMd5(panFile.getMd5());
        panTrash.setSize(panFile.getSize());
        panTrash.setName(panFile.getName());

        return panTrash;
    }


    //列出磁盘下的文件夹
    private List<PanFile> listSubFoldersByFolder(Long folderId) {
        List<PanFile> panFolderList = panFileMapper.selectList(new EntityWrapper<PanFile>().eq("folder_id", folderId)
        .and().eq("size", 0));
        return panFolderList;
    }

    //递归找出所有盘文件
    private List<PanFile> listSubFilesByFolder(Long folderId, boolean bReserve) {
        List<Long> longList = new ArrayList<>();
        longList.add(folderId);
        return listSubFilesByFolderList(longList, bReserve);
    }

    //递归找出所有盘文件
    private List<PanFile> listSubFilesByFolderList(List<Long> folderList, boolean bReserve) {
        List<PanFile> panFiles = new ArrayList<>();
        PanFile panFile = null;

        List<PanFile> panFileList = panFileMapper.selectList(new EntityWrapper<PanFile>().in("folder_id", folderList));
        if (bReserve == false){
            return panFileList;
        }

        Queue<PanFile> panFileQueue = new LinkedList<>();
        panFileQueue.addAll(panFileList);
        while (panFileQueue.size() > 0 ){
            //队列弹出一个 装一个
            panFile = panFileQueue.poll();
            panFiles.add(panFile);

            //目录进行递归
            if (IsDirecory(panFile) ){
                panFileList = panFileMapper.selectList(new EntityWrapper<PanFile>().eq("folder_id", panFile.getId()));
                if (panFileList.size() > 0){
                    panFileQueue.addAll(panFileList);
                }
            }
        }
        return panFiles;
    }


    //列出磁盘下的文件夹
    private boolean checkFolderFileValid(Long folderId, String fileName) {
        List<PanFile> panFiles = panFileMapper.selectList(new EntityWrapper<PanFile>().eq("folder_id", folderId).and().eq("name", fileName) );
        if (panFiles.size() > 0){ //名字不可重复
            return false;
        }
        return true;
    }


    /**
     * 检查位置变更 返回可正常移动的文件
     * @param idList
     * @param errIds
     * @param parent_id
     * @param bKeepBoth
     * @return
     */
    public List<PanFile> checkMove(List<Long> idList, List<Long> errIds, Long parent_id, boolean bKeepBoth) {

        PanFile parentFile = selectById(parent_id);
        if (parentFile == null && parent_id != 0){
            return null;
        }

        List<PanFile> panFiles = new ArrayList<>();

        boolean bValid = false;
        List<PanFile> panFileList =  selectBatchIds(idList);
        for (PanFile panFile:panFileList){
            if(panFile.getFolderId() == parent_id){ //无需移动的
                continue;
            }

            bValid = checkFolderFileValid(parent_id, panFile.getName());
            if (bValid == false && bKeepBoth == false){
                errIds.add(panFile.getId());// 让用户选择
            }else{
                String newName = "";
                int i = 1;
                while (bValid == false){
                    newName = panFile.getName() + "(" + i + ")";
                    bValid = checkFolderFileValid(parent_id, newName);
                    ++i;
                }
                if (bValid == false){
                    panFile.setName(newName);
                }

                panFile.setFolderId(parent_id);

                panFiles.add(panFile); //只移动校验合格文件
            }

        }
        return panFiles;

    }

        @Override
    public void listPage(Page<PanFile> page, PanFileQueryParam filter) {
        page.setRecords(panFileMapper.selectPanFiles(page, filter));
    }

    @Override
    public List<PanFile> list(PanFileQueryParam filter) {
        return panFileMapper.selectPanFiles(filter);
    }


    @Override
    public boolean moveFiles(List<Long> idList, List<Long> errIds, Long parent_id, boolean bKeepBoth) {

        //移动前的校验
        List<PanFile> panFiles = checkMove(idList, errIds, parent_id, bKeepBoth);
        if (panFiles == null){
            return false;
        }
        updateBatchById(panFiles);
        return true;
    }

    @Override
    public boolean copyFiles(List<Long> idList, List<Long> errIds, Long parent_id, boolean bKeepBoth) {

        long userID = 0;
        //新旧目录id对照表
        Map<Long, Long> cpToRealMap = new HashMap<>();
        List<Long> longList = new ArrayList<>();
        //移动前的校验
        List<PanFile> panFiles = checkMove(idList, errIds, parent_id, bKeepBoth);

        long tempId = -1;
        for (PanFile panFile:panFiles){
            tempId = panFile.getId();

            panFile.setId(null);
            panFile.setFolderId(parent_id);
            save(panFile);

            if (IsDirecory(panFile)){
                cpToRealMap.put(tempId, panFile.getId());
            }
            else
            {
                storeNodeService.storeExistFile(userID, panFile.getMd5(), panFile.getName(), panFile.getSize());
            }
            longList.add(tempId);
        }

        long newParentId = -1;
        panFiles = listSubFilesByFolderList(longList, true);
        for (PanFile panFile:panFiles) {
            tempId = panFile.getId();
            newParentId = cpToRealMap.get(panFile.getFolderId());
            panFile.setFolderId(newParentId);
            panFile.setId(null);
            save(panFile);

            if (IsDirecory(panFile)){
                cpToRealMap.put(tempId, panFile.getId());
            }
            else
            {
                storeNodeService.storeExistFile(userID, panFile.getMd5(), panFile.getName(), panFile.getSize());
            }
        }

        return true;
    }


    @Override
    public boolean newFile(Long folderId, Long user_id, String name, String filePath, String keyword, String description) {
        boolean bRet = checkFolderFileValid(folderId, name);
        if (bRet == false){
            return bRet;
        }
        filePath = downloadFolder + "upload" + "/" + filePath;

        bRet = FileUtil.isFileExist(filePath);
        if (bRet == false){
            return bRet;
        }


        long fileSize = FileUtil.getFileSize(filePath);
        String fileMd5 = Md5Util.GetFileMd5(filePath);

//        String fileMd5 = FileUtil.getFileName(filePath);
        PanFile panFile = new PanFile();
        panFile.setName(name);
        panFile.setFolderId(folderId);
        panFile.setKeyword(keyword);
        panFile.setUserId(user_id);
        panFile.setMd5(fileMd5);
        panFile.setSize(fileSize);

        bRet = storeNodeService.storeFile(user_id, fileMd5, filePath);
        if (bRet == false){
            return false;
        }

        save(panFile);

        //这个文件参与es检索
        if ( (StringUtil.isNullOrEmpty(description) == false) ||
                (StringUtil.isNullOrEmpty(keyword) == false ) ){


            EsFile item = new EsFile();
            item.setPanFile(panFile);
            esDaoUtil.Insert(item);

            if (StringUtil.isNullOrEmpty(keyword) == false){
                List<String> keywordList = StringUtil.string2List(keyword);
                keywordGlobalService.changeKeyWordListRef(keywordList, 1);
            }
        }



        return true;
    }

    @Override
    public boolean newDirectory(Long folder_id, Long user_id, String name, String keyword, String description) {
        boolean bValid = checkFolderFileValid(folder_id, name);
        if (bValid == false){
            return false;
        }

        if (StringUtil.isNullOrEmpty(keyword) == false){
            keyword = keyword.toLowerCase();
            String[] keywordsArray =  keyword.split("[\\,\\;\\，\\s]");
            keyword = StringUtil.array2String(keywordsArray);
        }

        PanFile panFile = new PanFile();
        panFile.setName(name);
        panFile.setFolderId(folder_id);
        panFile.setKeyword(keyword);
        panFile.setUserId(user_id);
        panFile.setMd5("");
        panFile.setSize((long) 0);
        save(panFile);

        //这个文件参与es检索
        if ( (StringUtil.isNullOrEmpty(description) == false) ||
                (StringUtil.isNullOrEmpty(keyword) == false ) ){

            EsFile item = new EsFile();
            item.setPanFile(panFile);
            esDaoUtil.Insert(item);

            if (StringUtil.isNullOrEmpty(keyword) == false){
                List<String> keywordList = StringUtil.string2List(keyword);
                keywordGlobalService.changeKeyWordListRef(keywordList, 1);
            }
        }

        return true;
    }

    @Override
    public boolean updateFileInfo(Long id, String name, String keyword, String description) {
        PanFile panFile = selectById(id);
        if (panFile == null){
            return false;
        }

        //文件命名检测
        List<PanFile> panFiles = panFileMapper.selectList(new EntityWrapper<PanFile>().eq("folder_id", panFile.getFolderId()).and().eq("name", name) );
        if (panFiles.size() > 1){ //名字不可重复
            return false;
        }else if (panFiles.size() == 1){
            if( panFiles.get(0).getId() != id){
                return false;
            }
        }


        String oldKeyWords = panFile.getKeyword();

        panFile.setName(name);
        panFile.setKeyword(keyword);
        panFile.setRemarks(description);
        save(panFile);

        //这个文件参与es检索
        if ( (StringUtil.isNullOrEmpty(description) == false) ||
                (StringUtil.isNullOrEmpty(keyword) == false ) ){

            EsFile item = new EsFile();
            item.setPanFile(panFile);
            esDaoUtil.deleteById(item.getTableName(), panFile.getId());
            esDaoUtil.Insert(item);

            //旧有的keyword引用计数减除
            if (StringUtil.isNullOrEmpty(oldKeyWords) == false){
                List<String> keywordList = StringUtil.string2List(oldKeyWords);
                keywordGlobalService.changeKeyWordListRef(keywordList, -1);
            }

            if (StringUtil.isNullOrEmpty(keyword) == false){
                List<String> keywordList = StringUtil.string2List(keyword);
                keywordGlobalService.changeKeyWordListRef(keywordList, 1);
            }
        }

        return true;
    }

    @Override
    public List<FileVO> listFiles(long userId, long folder_id) {
        List<FileVO> voList = new ArrayList<>();
        List<PanFile> panFiles = listSubFilesByFolder(folder_id, false);
        for (PanFile panFile:panFiles){
            FileVO fileVO = panFileToFileVO(panFile);
            voList.add(fileVO);
        }
        return voList;
    }

    @Override
    public List<FileVO> listDirectorys(long userId, long folder_id) {
        List<FileVO> voList = new ArrayList<>();
        List<PanFile> panFiles = listSubFoldersByFolder(folder_id);
        for (PanFile panFile:panFiles){
            FileVO fileVO = panFileToFileVO(panFile);
            voList.add(fileVO);
        }
        return voList;
    }

    @Override
    public boolean deleteFilesToTrash(List<Long> idList) {
        List<Long> panFileIds = new ArrayList<>();
        List<PanTrash> panTrashList = new ArrayList<>();

        List<PanFile> panSubFiles = listSubFilesByFolderList(idList, true);
        List<PanFile> panTopFiles = selectBatchIds(idList);

        for (PanFile panFile:panSubFiles){
            PanTrash panTrash = panFileToTrash(panFile);
            panTrash.setVisible("0");
            panTrashList.add(panTrash);
            panFileIds.add(panFile.getId());
        }

        //用户直接勾选的文件
        for (PanFile panFile:panTopFiles){
            PanTrash panTrash = panFileToTrash(panFile);
            panTrash.setVisible("1");
            panTrashList.add(panTrash);
            panFileIds.add(panFile.getId());
        }

        panTrashService.insertBatch(panTrashList);

        String esTbName = new EsFile().getTableName();
        for (PanTrash panTrash: panTrashList){
            if (StringUtil.isNullOrEmpty( panTrash.getKeyword())!=true || StringUtil.isNullOrEmpty(panTrash.getRemarks())!= true  ){
                esDaoUtil.deleteById(esTbName, panTrash.getItemId() );

                if(StringUtil.isNullOrEmpty(panTrash.getKeyword()) == false){
                    List<String> keywordList = StringUtil.string2List(panTrash.getKeyword());
                    keywordGlobalService.changeKeyWordListRef(keywordList, -1);
                }
            }
        }
        deleteBatchIds(panFileIds);
        return true;
    }


    @Override
    public Long save(PanFile param) {
        if (param.getId()!=null) {
            panFileMapper.updateById(param);
        } else {
            panFileMapper.insert(param);
        }
        return param.getId();
    }


    @Value("${app.download}")
    private String downloadFolder;

}
