package com.iqw.eserver.modules.yunpan.service.impl;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.iqw.eserver.base.utils.StringUtil;
import com.iqw.eserver.modules.es.entity.EsFile;
import com.iqw.eserver.modules.es.entity.EsNote;
import com.iqw.eserver.modules.es.mapper.EsDaoUtil;
import com.iqw.eserver.modules.yunpan.entity.PanFile;
import com.iqw.eserver.modules.yunpan.entity.PanNote;
import com.iqw.eserver.modules.yunpan.entity.PanTrash;
import com.iqw.eserver.modules.yunpan.mapper.PanNoteMapper;
import com.iqw.eserver.modules.yunpan.service.IKeywordGlobalService;
import com.iqw.eserver.modules.yunpan.service.IPanNoteService;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.iqw.eserver.modules.yunpan.dto.input.PanNoteQueryParam;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

/**
* <p> 随笔表 服务类</p>
*
* @author: PanSou
* @date: 2020-07-22
*/
@Service
@Transactional
public class PanNoteServiceImpl extends ServiceImpl<PanNoteMapper, PanNote> implements IPanNoteService {

    @Autowired(required = false)
    PanNoteMapper panNoteMapper;


    @Autowired
    private EsDaoUtil esDaoUtil;

//    @Autowired(required = false)
//    IKeywordGlobalService keywordGlobalService;


    @Override
    public void listPage(Page<PanNote> page, PanNoteQueryParam filter) {
        page.setRecords(panNoteMapper.selectPanNotes(page, filter));
    }

    @Override
    public List<PanNote> list(PanNoteQueryParam filter) {
        return panNoteMapper.selectPanNotes(filter);
    }

    @Override
    public boolean newNote(long userId, String name, String keywords, String remarks) {

        if (StringUtil.isNullOrEmpty(keywords) == false){
            keywords = keywords.toLowerCase();
            String[] keywordsArray =  keywords.split("[\\,\\;\\，\\s]");
            keywords = StringUtil.array2String(keywordsArray);
        }

        PanNote panNote = new PanNote();
        panNote.setName(name);
        panNote.setFolderId(0);
        panNote.setKeyword(keywords);
        panNote.setUserId(userId);
        panNote.setSize( remarks.length());
        panNote.setContent(remarks);
        save(panNote);

        //这个文件参与es检索
        if ( (StringUtil.isNullOrEmpty(remarks) == false) ||
                (StringUtil.isNullOrEmpty(keywords) == false ) ){

            EsNote item = new EsNote();
            item.setPanNote(panNote);
            esDaoUtil.Insert(item);

//            if (StringUtil.isNullOrEmpty(keywords) == false){
//                List<String> keywordList = StringUtil.string2List(keywords);
//                keywordNoteService.changeKeyWordListRef(keywordList, 1);
//            }
        }

        return true;
    }

    @Override
    public boolean updateNote(long id, String name, String keywords, String remarks) {
        //文件命名检测
        PanNote panNote = panNoteMapper.selectById(id);
        if (panNote == null){ //
            return false;
        }


        String oldKeyWords = panNote.getKeyword();

        panNote.setName(name);
        panNote.setKeyword(keywords);
        panNote.setContent(remarks);
        save(panNote);

        //这个文件参与es检索
        if ( (StringUtil.isNullOrEmpty(remarks) == false) ||
                (StringUtil.isNullOrEmpty(keywords) == false ) ){

            EsNote item = new EsNote();
            item.setPanNote(panNote);
            esDaoUtil.deleteById(item.getTableName(), panNote.getId());
            esDaoUtil.Insert(item);

            //旧有的keyword引用计数减除
//            if (StringUtil.isNullOrEmpty(oldKeyWords) == false){
//                List<String> keywordList = StringUtil.string2List(oldKeyWords);
//                keywordGlobalService.changeKeyWordListRef(keywordList, -1);
//            }
//
//            if (StringUtil.isNullOrEmpty(keyword) == false){
//                List<String> keywordList = StringUtil.string2List(keyword);
//                keywordGlobalService.changeKeyWordListRef(keywordList, 1);
//            }
        }

        return true;

    }

    @Override
    public boolean deleteNotesToTrash(List<Long> idList) {

        String esTbName = new EsNote().getTableName();

//        if (StringUtil.isNullOrEmpty( panTrash.getKeyword())!=true || StringUtil.isNullOrEmpty(panTrash.getRemarks())!= true  ){
            esDaoUtil.deleteById(esTbName, idList.get(0) );

//            if(StringUtil.isNullOrEmpty(panTrash.getKeyword()) == false){
//                List<String> keywordList = StringUtil.string2List(panTrash.getKeyword());
//                keywordGlobalService.changeKeyWordListRef(keywordList, -1);
//            }

//        }

        deleteBatchIds(idList);
        return true;
    }


    @Override
    public Long save(PanNote param) {
        if (param.getId()!=null) {
            panNoteMapper.updateById(param);
        } else {
            panNoteMapper.insert(param);
        }
        return param.getId();
    }

}
