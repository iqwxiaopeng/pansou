package com.iqw.eserver.modules.yunpan.service.impl;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.iqw.eserver.SysConstants;
import com.iqw.eserver.modules.yunpan.entity.PanTrash;
import com.iqw.eserver.modules.yunpan.mapper.PanTrashMapper;
import com.iqw.eserver.modules.yunpan.service.IPanTrashService;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.iqw.eserver.modules.yunpan.dto.input.PanTrashQueryParam;
import com.iqw.eserver.modules.yunpan.service.IStoreNodeService;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.util.List;

/**
* <p> 垃圾回站条目表 服务类</p>
*
* @author: PanSou
* @date: 2020-07-22
*/
@Service
@Transactional
public class PanTrashServiceImpl extends ServiceImpl<PanTrashMapper, PanTrash> implements IPanTrashService {

    @Autowired(required = false)
    PanTrashMapper panTrashMapper;

    @Autowired(required = false)
    IStoreNodeService storeNodeService;

    @Override
    public void listPage(Page<PanTrash> page, PanTrashQueryParam filter) {
        page.setRecords(panTrashMapper.selectPanTrashs(page, filter));
    }

    @Override
    public List<PanTrash> list(PanTrashQueryParam filter) {
        return panTrashMapper.selectPanTrashs(filter);
    }


    @Override
    public boolean emptyTrash(Long user_id) throws IOException {
        PanTrashQueryParam panTrashQueryParam = new PanTrashQueryParam();
        //panTrashQueryParam.setType(SysConstants.PANFILETYPE_FILE); // 设置类型
        panTrashQueryParam.setUserId(user_id);
        List<PanTrash> panTrashes= panTrashMapper.selectPanTrashs(panTrashQueryParam);
        for (PanTrash panTrash:panTrashes){
            storeNodeService.removeFile(panTrash.getUserId(), panTrash.getMd5());
        }

        panTrashMapper.delete(new EntityWrapper<PanTrash>().eq("user_id", user_id));
        return false;
    }

    @Override
    public boolean restoreTrash(Long id, Long user_id, boolean overWrite) {
        PanTrash panTrash = panTrashMapper.selectById(id);
        panTrash.getFolderId();
        return false;
    }

    @Override
    public boolean restoreAllTrash(Long id, Long user_id, List<Boolean> overWriteList) {
        return false;
    }


    @Override
    public boolean listTrash(Long user_id) {
        PanTrashQueryParam panTrashQueryParam = new PanTrashQueryParam();
        panTrashQueryParam.setVisible("0");
        panTrashQueryParam.setUserId(user_id);
        List<PanTrash> panTrashes= panTrashMapper.selectPanTrashs(panTrashQueryParam);
        return false;
    }

    @Override
    public Long save(PanTrash param) {
        if (param.getId()!=null) {
            panTrashMapper.updateById(param);
        } else {
            panTrashMapper.insert(param);
        }
        return param.getId();
    }

}
