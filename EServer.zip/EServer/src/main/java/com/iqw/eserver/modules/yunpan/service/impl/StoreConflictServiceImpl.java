package com.iqw.eserver.modules.yunpan.service.impl;

import com.baomidou.mybatisplus.plugins.Page;
import com.iqw.eserver.modules.yunpan.entity.StoreConflict;
import com.iqw.eserver.modules.yunpan.mapper.StoreConflictMapper;
import com.iqw.eserver.modules.yunpan.service.IStoreConflictService;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.iqw.eserver.modules.yunpan.dto.input.StoreConflictQueryParam;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

/**
* <p> 重复文件表 服务类</p>
*
* @author: PanSou
* @date: 2020-07-22
*/
@Service
@Transactional
public class StoreConflictServiceImpl extends ServiceImpl<StoreConflictMapper, StoreConflict> implements IStoreConflictService {

    @Autowired(required = false)
    StoreConflictMapper storeConflictMapper;


    @Override
    public void listPage(Page<StoreConflict> page, StoreConflictQueryParam filter) {
        page.setRecords(storeConflictMapper.selectStoreConflicts(page, filter));
    }

    @Override
    public List<StoreConflict> list(StoreConflictQueryParam filter) {
        return storeConflictMapper.selectStoreConflicts(filter);
    }

    @Override
    public Long save(StoreConflict param) {
        if (param.getId()!=null) {
            storeConflictMapper.updateById(param);
        } else {
            storeConflictMapper.insert(param);
        }
        return param.getId();
    }

}
