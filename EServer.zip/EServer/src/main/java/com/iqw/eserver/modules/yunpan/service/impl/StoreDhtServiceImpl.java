package com.iqw.eserver.modules.yunpan.service.impl;

import com.baomidou.mybatisplus.plugins.Page;
import com.iqw.eserver.modules.yunpan.entity.StoreDht;
import com.iqw.eserver.modules.yunpan.mapper.StoreDhtMapper;
import com.iqw.eserver.modules.yunpan.service.IStoreDhtService;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.iqw.eserver.modules.yunpan.dto.input.StoreDhtQueryParam;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

/**
* <p> 分布式哈希存储节点表 服务类</p>
*
* @author: PanSou
* @date: 2020-07-22
*/
@Service
@Transactional
public class StoreDhtServiceImpl extends ServiceImpl<StoreDhtMapper, StoreDht> implements IStoreDhtService {

    @Autowired(required = false)
    StoreDhtMapper storeDhtMapper;


    @Override
    public void listPage(Page<StoreDht> page, StoreDhtQueryParam filter) {
        page.setRecords(storeDhtMapper.selectStoreDhts(page, filter));
    }

    @Override
    public List<StoreDht> list(StoreDhtQueryParam filter) {
        return storeDhtMapper.selectStoreDhts(filter);
    }

    @Override
    public List<StoreDht> getClostDht(String hashTag) {
        List<StoreDht> storeDhtList = new ArrayList<>();
        StoreDht storeDht = storeDhtMapper.selectJustBigByNodeHash(hashTag);
        if (storeDht == null){
            storeDht = storeDhtMapper.selectMinDht();
        }
        storeDhtList.add(storeDht);

        storeDht = storeDhtMapper.selectJustSmallByNodeHash(hashTag);
        if (storeDht == null){
            storeDht = storeDhtMapper.selectMaxDht();
        }
        storeDhtList.add(storeDht);
        return storeDhtList;
    }

    @Override
    public StoreDht getMappingDht(String hashTag) {
        StoreDht storeDht = storeDhtMapper.selectJustBigByNodeHash(hashTag);
        if (storeDht == null){
            storeDht = storeDhtMapper.selectMinDht();
        }
        return storeDht;
    }

    @Override
    public Long save(StoreDht param) {
        if (param.getId()!=null) {
            storeDhtMapper.updateById(param);
        } else {
            storeDhtMapper.insert(param);
        }
        return param.getId();
    }

}
