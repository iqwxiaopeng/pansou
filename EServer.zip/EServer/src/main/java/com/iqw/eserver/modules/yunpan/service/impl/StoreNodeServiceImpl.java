package com.iqw.eserver.modules.yunpan.service.impl;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.iqw.eserver.SysConstants;
import com.iqw.eserver.base.utils.FileUtil;
import com.iqw.eserver.base.utils.Md5Util;
import com.iqw.eserver.modules.yunpan.dto.input.StoreDhtQueryParam;
import com.iqw.eserver.modules.yunpan.entity.StoreConflict;
import com.iqw.eserver.modules.yunpan.entity.StoreDht;
import com.iqw.eserver.modules.yunpan.entity.StoreNode;
import com.iqw.eserver.modules.yunpan.mapper.StoreConflictMapper;
import com.iqw.eserver.modules.yunpan.mapper.StoreDhtMapper;
import com.iqw.eserver.modules.yunpan.mapper.StoreNodeMapper;
import com.iqw.eserver.modules.yunpan.service.IStoreDhtService;
import com.iqw.eserver.modules.yunpan.service.IStoreNodeService;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.iqw.eserver.modules.yunpan.dto.input.StoreNodeQueryParam;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
* <p> 物理存储节点表 服务类</p>
*
* @author: PanSou
* @date: 2020-07-22
*/
@Service
@Transactional
public class StoreNodeServiceImpl extends ServiceImpl<StoreNodeMapper, StoreNode> implements IStoreNodeService {

    @Autowired(required = false)
    StoreNodeMapper storeNodeMapper;

    @Autowired(required = false)
    StoreDhtMapper storeDhtMapper;

    @Autowired(required = false)
    IStoreDhtService storeDhtService;

    @Autowired(required = false)
    StoreConflictMapper storeConflictMapper;



    @Override
    public void listPage(Page<StoreNode> page, StoreNodeQueryParam filter) {
        page.setRecords(storeNodeMapper.selectStoreNodes(page, filter));
    }

    @Override
    public List<StoreNode> list(StoreNodeQueryParam filter) {
        return storeNodeMapper.selectStoreNodes(filter);
    }

    @Override
    public boolean registerStoreNode(Long userId, String storePath, Long capacity) {

        List<StoreNode> storeNodeList = storeNodeMapper.selectByPath(storePath);
        if (storeNodeList.size() > 0){
            return false;
        }

        StoreNode storeNode = new StoreNode();
        storeNode.setCapacity(capacity);
        storeNode.setCapacityLeft(capacity);
        storeNode.setUserId(userId);
        storeNode.setStorePath(storePath);
        storeNode.setNodeState("1");
        save(storeNode);

        StoreDht storeDht = new StoreDht();
        storeDht.setStoreNodeId(storeNode.getId());


        StoreDhtQueryParam storeDhtQueryParam = new StoreDhtQueryParam();
        List<String> hashList = new ArrayList<>();
        String hashSource = Long.valueOf(userId + System.currentTimeMillis()).toString() + storePath;
        String dhtHash = "";
        for (int i = 0; i < SysConstants.VNODENUM_PERNODE; i++){
            dhtHash = Md5Util.GetStringMd5(hashSource + i);
            storeDhtQueryParam.setNodeHash(dhtHash);
            List<StoreDht> dhtList = storeDhtMapper.selectStoreDhts(storeDhtQueryParam);
            if (dhtList.size() == 0){
                storeDht.setNodeHash(dhtHash);
                storeDhtMapper.insert(storeDht);
            }
        }

        storeNode.setNodeState("0");
        save(storeNode);

        return true;
    }

    @Override
    public boolean removeStoreNode(Long userId, Long id)
    {
        StoreNode storeNode = storeNodeMapper.selectById(id);
        if (storeNode == null){
            return false;
        }

        storeDhtMapper.delete(new EntityWrapper<StoreDht>().eq("store_node_id", storeNode.getId()));
        storeNodeMapper.deleteById(id);
        return true;
    }

    @Override
    public boolean changeStoreCapacity(Long id, Long userId,  long capacityChange) {
        StoreNode storeNode = storeNodeMapper.selectById(id);
        if (storeNode == null){
            return false;
        }
        long usedCapacity = storeNode.getCapacity() - storeNode.getCapacityLeft() + 1024;
        if (storeNode.getCapacity() + capacityChange < usedCapacity){
            return false;
        }

        storeNode.setCapacity(storeNode.getCapacity() + capacityChange);
        storeNode.setCapacityLeft(storeNode.getCapacityLeft() + capacityChange);

        return true;
    }

    @Override
    public boolean storeFile(Long userId, String fileTag, String filePath) {
        String fileName = FileUtil.getFileName(filePath);
        Long fileSize = FileUtil.getFileSize(filePath);
        StoreDht storeDht=storeDhtService.getMappingDht(fileTag);
        StoreNode storeNode = storeNodeMapper.selectById(storeDht.getStoreNodeId());


        String newFilePath = storeNode.getStorePath() + "/"+storeDht.getNodeHash() +"/" + fileTag;
        if(FileUtil.isFileExist(newFilePath) == true){

            StoreConflict storeConflict = storeConflictMapper.selectByFileMd5(fileTag);
            if (storeConflict != null){
                storeConflict.setRepeatNum(storeConflict.getRepeatNum() + 1);
                storeConflictMapper.updateById(storeConflict);
            }else {
                storeConflict = new StoreConflict();
                storeConflict.setFileMd5(fileTag);
                storeConflict.setRepeatNum(2);
                storeConflict.setFileName(fileName);
                storeConflict.setFileSize(fileSize);
                storeConflictMapper.insert(storeConflict);
            }

            return true;
        }

        if (storeNode.getCapacityLeft() < fileSize){ //存储空间不足
            return false;
        }

        storeNode.setCapacityLeft(storeNode.getCapacityLeft()-fileSize);
        storeNodeMapper.updateById(storeNode);
        FileUtil.copyFile(filePath, newFilePath);
        return true;
    }

    @Override
    public boolean getFile(Long userId, String fileTag, String outPath) {
        StoreDht storeDht=storeDhtService.getMappingDht(fileTag);
        StoreNode storeNode = storeNodeMapper.selectById(storeDht.getStoreNodeId());
        String storeFilePath = storeNode.getStorePath() + "/"+storeDht.getNodeHash() +"/" + fileTag;
        if(FileUtil.isFileExist(storeFilePath) == true) {
            return FileUtil.copyFile(storeFilePath, outPath);
        }
        return false;
    }

    @Override
    public boolean isFileExit(String fileTag) {
        StoreDht storeDht=storeDhtService.getMappingDht(fileTag);
        StoreNode storeNode = storeNodeMapper.selectById(storeDht.getStoreNodeId());
        String storeFilePath = storeNode.getStorePath() + "/"+storeDht.getNodeHash() +"/" + fileTag;
        return FileUtil.isFileExist(storeFilePath);

    }

    @Override
    public boolean storeExistFile(Long userId, String fileTag,String fileName, long fileSize) {

        StoreConflict storeConflict = storeConflictMapper.selectByFileMd5(fileTag);
        if (storeConflict != null){
            storeConflict.setRepeatNum(storeConflict.getRepeatNum() + 1);
            storeConflictMapper.updateById(storeConflict);
        }else {
            storeConflict = new StoreConflict();
            storeConflict.setFileMd5(fileTag);
            storeConflict.setRepeatNum(2);
            storeConflict.setFileName(fileName);
            storeConflict.setFileSize(fileSize);
            storeConflictMapper.insert(storeConflict);
        }
        return true;
    }

    @Override
    public boolean removeFile(Long userId, String fileTag) throws IOException {
        StoreDht storeDht=storeDhtService.getMappingDht(fileTag);
        StoreNode storeNode = storeNodeMapper.selectById(storeDht.getStoreNodeId());
        String filePath = storeNode.getStorePath() + "/" + fileTag;

        if (FileUtil.isFileExist(filePath) == false){
            return false;
        }

        Long fileSize = FileUtil.getFileSize(filePath);

        StoreConflict storeConflict = storeConflictMapper.selectByFileMd5(fileTag);
        if (storeConflict != null){
            if (storeConflict.getRepeatNum() > 1)
            {
                storeConflict.setRepeatNum(storeConflict.getRepeatNum() - 1);
                storeConflictMapper.updateById(storeConflict);
            }else{
                storeConflictMapper.deleteById(storeConflict);
            }



            return  true;
        }

        storeNode.setCapacityLeft(storeNode.getCapacityLeft() + fileSize);
        storeNodeMapper.updateById(storeNode);
        FileUtil.deleteFile(filePath);
        return true;
    }

    @Override
    public Long save(StoreNode param) {
        if (param.getId()!=null) {
            storeNodeMapper.updateById(param);
        } else {
            storeNodeMapper.insert(param);
        }
        return param.getId();
    }

}
