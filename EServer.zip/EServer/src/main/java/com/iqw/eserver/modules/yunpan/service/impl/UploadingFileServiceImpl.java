package com.iqw.eserver.modules.yunpan.service.impl;

import com.baomidou.mybatisplus.plugins.Page;
import com.iqw.eserver.modules.yunpan.entity.UploadingFile;
import com.iqw.eserver.modules.yunpan.mapper.UploadingFileMapper;
import com.iqw.eserver.modules.yunpan.service.IUploadingFileService;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.iqw.eserver.modules.yunpan.dto.input.UploadingFileQueryParam;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

/**
* <p> 云盘文件表 服务类</p>
*
* @author: PanSou
* @date: 2020-08-05
*/
@Service
@Transactional
public class UploadingFileServiceImpl extends ServiceImpl<UploadingFileMapper, UploadingFile> implements IUploadingFileService {

    @Autowired
    UploadingFileMapper uploadingFileMapper;


    @Override
    public void listPage(Page<UploadingFile> page, UploadingFileQueryParam filter) {
        page.setRecords(uploadingFileMapper.selectUploadingFiles(page, filter));
    }

    @Override
    public List<UploadingFile> list(UploadingFileQueryParam filter) {
        return uploadingFileMapper.selectUploadingFiles(filter);
    }

    @Override
    public Long save(UploadingFile param) {
        if (param.getId()!=null) {
            uploadingFileMapper.updateById(param);
        } else {
            uploadingFileMapper.insert(param);
        }
        return param.getId();
    }

}
