package com.iqw.eserver.util;

import com.baomidou.mybatisplus.enums.IdType;
import com.baomidou.mybatisplus.exceptions.MybatisPlusException;
import com.baomidou.mybatisplus.generator.AutoGenerator;
import com.baomidou.mybatisplus.generator.InjectionConfig;
import com.baomidou.mybatisplus.generator.config.*;
import com.baomidou.mybatisplus.generator.config.po.TableInfo;
import com.baomidou.mybatisplus.generator.config.rules.NamingStrategy;
import com.baomidou.mybatisplus.generator.engine.AbstractTemplateEngine;
import com.baomidou.mybatisplus.generator.engine.FreemarkerTemplateEngine;
import com.baomidou.mybatisplus.generator.engine.VelocityTemplateEngine;
import org.apache.commons.lang3.StringUtils;

import java.text.MessageFormat;
import java.util.*;

/**模版地址: https://github.com/baomidou/mybatis-plus/tree/3.0/mybatis-plus-generator/src/main/resources/templates
 * 官方地址: https://mp.baomidou.com/config/generator-config.html#activerecord
 * 自动生成mybatis-plus所需要的 entity,dao,xml文件
 */
public class AutoGeneratorTool {


    /**
     * 私有化构造
     */
    private AutoGeneratorTool() {
        super();
    }

    /**
     * 代码生成main
     */
    public static void main(String[] args) {

        AutoGeneratorTool.codeGen();
    }



    /**
     * 数据源配置
     */
    private static final String DATA_SOURCE_URL =
            "jdbc:mysql://127.0.0.1:3306/freedisk?allowMultiQueries=true&useUnicode=true&characterEncoding=UTF8&zeroDateTimeBehavior=convertToNull&useSSL=false";
    private static final String DATA_SOURCE_USERNAME = "root";
    private static final String DATA_SOURCE_PASSWORD = "root";
    private static final String DATA_SOURCE_DRIVER_NAME = "com.mysql.jdbc.Driver";

    /**
     * 父类字段 注意这里的字段子类不会生成
     */
    private static final String SUPER_ENTITY_ID = "id"; //父类定义的字段子类不会生成
    private static final String SUPER_ENTITY_CREATE_TIME = "gmt_create";
    private static final String SUPER_ENTITY_EDIT_TIME = "gmt_modified";
    private static final String SUPER_ENTITY_DELETED = "deleted";
//    private static final String[] SUPER_ENTITY_COLUMNS =
//            {SUPER_ENTITY_ID, SUPER_ENTITY_CREATE_TIME, SUPER_ENTITY_EDIT_TIME, SUPER_ENTITY_DELETED};

    private static final String[] SUPER_ENTITY_COLUMNS =
            {SUPER_ENTITY_CREATE_TIME, SUPER_ENTITY_EDIT_TIME};

    /**
     * 父类配置 模块包路径
     */
    private static final String PACKAGE_PARENT = "com.iqw.eserver.modules";

    private static final String SUPER_ENTITY = PACKAGE_PARENT + ".common.entity.BaseEntity";
//    private static final String SUPER_CONTROLLER = PACKAGE_PARENT + ".demo.codegen.base.BaseController";
    private static final String SUPER_CONTROLLER = "com.iqw.eserver.modules.common.dto.input.BasePageQuery"; //用来生成dto文件
//    private static final String SUPER_SERVICE = PACKAGE_PARENT + ".common.service.";
    private static final String SUPER_SERVICE = "com.baomidou.mybatisplus.service.IService"; //service 接口
    private static final String SUPER_SERVICE_IMPL = "com.baomidou.mybatisplus.service.impl.ServiceImpl";
//    private static final String SUPER_SERVICE_IMPL = PACKAGE_PARENT + ".demo.codegen.base.BaseServiceImpl";

    /**
     * 包名配置 子模块名
     */
//    private static final String PACKAGE_PARENT_CONTROLLER = PACKAGE_PARENT + ".{0}.web.controller";
    private static final String PACKAGE_PARENT_CONTROLLER = PACKAGE_PARENT + ".{0}.dto.input"; //用来生成dto
    private static final String PACKAGE_PARENT_SERVICE = PACKAGE_PARENT + ".{0}.service";
    private static final String PACKAGE_PARENT_SERVICE_IMPL = PACKAGE_PARENT + ".{0}.service.impl";
    private static final String PACKAGE_PARENT_MAPPER = PACKAGE_PARENT + ".{0}.mapper";
    private static final String PACKAGE_PARENT_MAPPER_XML = PACKAGE_PARENT + ".{0}.mapper.xml";
    private static final String PACKAGE_PARENT_ENTITY = PACKAGE_PARENT + ".{0}.entity";

    //自定义
    private static  String PACKAGE_PARENT_DTO = PACKAGE_PARENT + ".{0}.dto";


    /**
     * 全局配置
     */
    private static final String GLOBAL_OUTPUT_DIR = "D:\\autoGen";
    private static final String GLOBAL_AUTHOR = "PanSou";

    /**
     * <p>
     * 读取控制台内容
     * </p>
     */
    private static String scanner(String tip) {
        Scanner scanner = new Scanner(System.in);
        StringBuilder help = new StringBuilder();
        help.append("请输入" + tip + "：");
        System.out.println(help.toString());
        if (scanner.hasNext()) {
            String ipt = scanner.next();
            if (StringUtils.isNotEmpty(ipt)) {
                return ipt;
            }
        }
        throw new MybatisPlusException("请输入正确的" + tip + "！");
    }

    public static void codeGen() {

        // 代码生成器
        AutoGenerator mpg = new AutoGenerator();

        // 全局配置
        GlobalConfig globalConfig = AutoGeneratorTool.getCodeGenGlobalConfig();
        mpg.setGlobalConfig(globalConfig);

        // 数据源配置
        DataSourceConfig dataSource = AutoGeneratorTool.getCodeGenDataSourceConfig();
        mpg.setDataSource(dataSource);

        // 包配置
        PackageConfig packageInfo = AutoGeneratorTool.getCodeGenPackageConfig();
        mpg.setPackageInfo(packageInfo);

        // 数据库表策略配置
        StrategyConfig strategy = AutoGeneratorTool.getCodeGenStrategyConfig();
        mpg.setStrategy(strategy);

        // 模板配置
        TemplateConfig template = AutoGeneratorTool.getCodeGenTemplateConfig();
        mpg.setTemplate(template);

        // 模板引擎配置
        AbstractTemplateEngine templateEngine = AutoGeneratorTool.getCodeGenTemplateEngine();
        mpg.setTemplateEngine(templateEngine);

        // 自定义注入篇配置
        InjectionConfig cfg = AutoGeneratorTool.getCodeGenInjectionConfig();
        mpg.setCfg(cfg);

        mpg.execute();

    }

    /**
     * 模板配置
     *
     * @return TemplateConfig
     */
    private static TemplateConfig getCodeGenTemplateConfig() {
        TemplateConfig templateConfig= new TemplateConfig();
//        templateConfig.setEntity("template/custommodel");
        return templateConfig;
    }

    /**
     * 自定义注入篇配置
     *
     * @return InjectionConfig
     */
    private static InjectionConfig getCodeGenInjectionConfig() {
        return new InjectionConfig() {

            @Override
            public void initMap() {
                //把一些自定义的值传递进模版
                Map<String, Object> selfParam = new HashMap<>();
                selfParam.put("dto", PACKAGE_PARENT_DTO);
                this.setMap(selfParam);
                System.out.println("InjectionConfig initMap");
            }
        };
    }

    /**
     * 模板引擎配置
     *
     * @return AbstractTemplateEngine
     */
    private static AbstractTemplateEngine getCodeGenTemplateEngine() {
//        return new VelocityTemplateEngine();
        return new FreemarkerTemplateEngine(); //使用功能强大的freemaker
    }


    /**
     * 策略配置
     *
     * @return StrategyConfig
     */
    private static StrategyConfig getCodeGenStrategyConfig() {
        StrategyConfig strategy = new StrategyConfig();
        // 设置表前缀
        strategy.setTablePrefix("t_");
        // 数据库表映射到实体的命名策略
        strategy.setNaming(NamingStrategy.underline_to_camel);
        // 数据库表字段映射到实体的命名策略, 未指定按照 naming 执行
        strategy.setColumnNaming(NamingStrategy.underline_to_camel);
        // 自定义继承的Entity类全称，带包名
        strategy.setSuperEntityClass(SUPER_ENTITY);
        // 自定义继承的Controller类全称，带包名
        strategy.setSuperControllerClass(SUPER_CONTROLLER);
        // 自定义继承的Service类全称，带包名
        strategy.setSuperServiceClass(SUPER_SERVICE);
        // 自定义继承的ServiceImpl类全称，带包名
        strategy.setSuperServiceImplClass(SUPER_SERVICE_IMPL);
        // 自定义基础的Entity类，公共字段
        strategy.setSuperEntityColumns(SUPER_ENTITY_COLUMNS);
        // 自定义继承的Mapper类全称，带包名
        strategy.setEntityLombokModel(true);
        // 生成 @RestController 控制器
        strategy.setRestControllerStyle(true);
        // 驼峰转连字符
        strategy.setControllerMappingHyphenStyle(true);
        // 逻辑删除属性名称
        strategy.setLogicDeleteFieldName(SUPER_ENTITY_DELETED);
        // 需要包含的表名，允许正则表达式（与exclude二选一配置）
//        strategy.setInclude(scanner("表名，多个英文逗号分割").split(",")); //想生成整个库的,注释掉即可
        //strategy.setExclude(); 也可以排除不想要的表
        strategy.setExclude(new String[] { "cloud_disk_file","duplicate_file","keyword","node","esitemlog",
                "r_ktable","trash_file","virtual_file","t_sys_log","t_sys_role","t_sys_menu","t_sys_role_menu","t_sys_user","t_sys_user_role"});

        return strategy;
    }

    /**
     * 获取全局配置
     *
     * @return GlobalConfig
     */
    private static GlobalConfig getCodeGenGlobalConfig() {
        GlobalConfig gc = new GlobalConfig();
        // 生成文件的输出目录,默认值：D 盘根目录
        gc.setOutputDir(GLOBAL_OUTPUT_DIR);
        // 是否覆盖已有文件,默认值：false
        gc.setFileOverride(Boolean.TRUE);
        // 是否打开输出目录,默认值：true
        gc.setOpen(Boolean.TRUE);
        // 是否在xml中添加二级缓存配置,默认值：`false
        gc.setEnableCache(Boolean.FALSE);
        // 开发人员,默认值：NULL
        gc.setAuthor(GLOBAL_AUTHOR);
        // 开启 Kotlin 模式,默认值：false
        gc.setKotlin(Boolean.FALSE);
//        // 开启 swagger2 模式,默认值：false
//        gc.setSwagger2(Boolean.FALSE);
        // 开启 ActiveRecord 模式,默认值：false
        gc.setActiveRecord(Boolean.TRUE);
        // 开启 BaseResultMap,默认值：false
        gc.setBaseResultMap(Boolean.TRUE);
        // 开启 baseColumnList,默认值：false
        gc.setBaseColumnList(Boolean.FALSE);
//        // 时间类型对应策略,默认值：TIME_PACK
//        gc.setDateType(DateType.TIME_PACK);
//        // 实体命名方式,默认值：null 例如：%sEntity 生成 UserEntity
//        gc.setEntityName(null);
        // mapper 命名方式,默认值：null 例如：%sDao 生成 UserDao
        gc.setMapperName("%sMapper");
        // Mapper xml 命名方式,默认值：null 例如：%sDao 生成 UserDao.xml
        gc.setXmlName(null);
        // service 命名方式,默认值：null 例如：%sBusiness 生成 UserBusiness
        gc.setServiceName("I%sService");
        // service 命名方式,默认值：null 例如：%sBusinessImpl 生成 UserBusinessImpl
        gc.setServiceImplName("%sServiceImpl");
        // controller 命名方式,默认值：null 例如：%sAction 生成 UserAction
        gc.setControllerName("%sQueryParam");//这里被用来生成dto
        // 指定生成的主键的ID类型,默认值：null
        gc.setIdType(IdType.ID_WORKER);
        return gc;
    }

    /**
     * 获取包配置
     *
     * @return PackageConfig
     */
    private static PackageConfig getCodeGenPackageConfig() {
        PackageConfig pc = new PackageConfig();
        String modelName = scanner("模块名");

        //给dto位置赋值
        PACKAGE_PARENT_DTO = MessageFormat.format(PACKAGE_PARENT_DTO, modelName);


        pc.setParent("");
        String packageController = MessageFormat.format(PACKAGE_PARENT_CONTROLLER, modelName);
        String packageService = MessageFormat.format(PACKAGE_PARENT_SERVICE, modelName);
        String packageServiceImpl = MessageFormat.format(PACKAGE_PARENT_SERVICE_IMPL, modelName);
        String packageMapper = MessageFormat.format(PACKAGE_PARENT_MAPPER, modelName);
        String packageMapperXml = MessageFormat.format(PACKAGE_PARENT_MAPPER_XML, modelName);
        String packageEntity = MessageFormat.format(PACKAGE_PARENT_ENTITY, modelName);
        pc.setController(packageController);
        pc.setService(packageService);
        pc.setServiceImpl(packageServiceImpl);
        pc.setMapper(packageMapper);
        pc.setXml(packageMapperXml);
        pc.setEntity(packageEntity);
        // 父包模块名
        pc.setModuleName(null);
        return pc;
    }

    /**
     * 获取数据源配置
     *
     * @return DataSourceConfig
     */
    private static DataSourceConfig getCodeGenDataSourceConfig() {
        DataSourceConfig dsc = new DataSourceConfig();
        dsc.setUrl(DATA_SOURCE_URL);
        dsc.setDriverName(DATA_SOURCE_DRIVER_NAME);
        dsc.setUsername(DATA_SOURCE_USERNAME);
        dsc.setPassword(DATA_SOURCE_PASSWORD);
        return dsc;
    }

}

