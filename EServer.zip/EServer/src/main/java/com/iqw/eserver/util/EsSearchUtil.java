package com.iqw.eserver.util;

import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.builder.SearchSourceBuilder;


import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * 本类提供广泛的搜索组织方法
 */

public class EsSearchUtil {



    public static SearchSourceBuilder GetSourceBuilder(Map<String, String> rangeMap, Map<String, String> equalMap, Map<String, String> listMap, int pageIndex, int pageSize){

        SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
        sourceBuilder.from(pageIndex);
        sourceBuilder.size(pageSize);
//        sourceBuilder.fetchSource(new String[]{"id"}, new String[]{});

        BoolQueryBuilder builder = QueryBuilders.boolQuery();

        if( rangeMap != null && rangeMap.size() > 0){
            Iterator<Map.Entry<String, String>> entries = rangeMap.entrySet().iterator();
            while (entries.hasNext()) {
                Map.Entry<String, String> entry = entries.next();

                String ar[] = entry.getValue().split(",");
                if(ar.length > 1){
                    builder.must(QueryBuilders.rangeQuery(entry.getKey()).from(ar[0]).to(ar[1]));
                }
            }
        }

        if(equalMap!=null && equalMap.size() > 0){
            Iterator<Map.Entry<String, String>> entries = equalMap.entrySet().iterator();
            while (entries.hasNext()) {
                Map.Entry<String, String> entry = entries.next();
                builder.must(QueryBuilders.matchQuery(entry.getKey(), entry.getValue()));
//                builder.must(QueryBuilders.termQuery(entry.getKey(), entry.getValue()));
            }

        }

        if(listMap!=null && listMap.size() > 0){
            Iterator<Map.Entry<String, String>> entries = listMap.entrySet().iterator();
            while (entries.hasNext()) {
                Map.Entry<String, String> entry = entries.next();

                List<String> periodList = Arrays.asList( entry.getValue().split(","));
//                if( periodList.size() > 0){
//                    builder.must(QueryBuilders.termsQuery(entry.getKey(), periodList));
//                }
                for (String item : periodList){
                    builder.must(QueryBuilders.termQuery(entry.getKey(), item));
                }
            }
        }

        sourceBuilder.query(builder);

        return sourceBuilder;
    }

    public static SearchSourceBuilder GetSourceLGBuilder(Map<String, String> ltMap, Map<String, String> equalMap, Map<String, String> gtMap, int pageIndex, int pageSize){

        SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
        sourceBuilder.from(pageIndex);
        sourceBuilder.size(pageSize);
//        sourceBuilder.fetchSource(new String[]{"id"}, new String[]{});


        BoolQueryBuilder builder = QueryBuilders.boolQuery();


        if(equalMap!=null && equalMap.size() > 0){
            Iterator<Map.Entry<String, String>> entries = equalMap.entrySet().iterator();
            while (entries.hasNext()) {
                Map.Entry<String, String> entry = entries.next();
                builder.must(QueryBuilders.matchQuery(entry.getKey(), entry.getValue()));
            }
        }

        if(ltMap!=null && ltMap.size() > 0){
            Iterator<Map.Entry<String, String>> entries = ltMap.entrySet().iterator();
            while (entries.hasNext()) {
                Map.Entry<String, String> entry = entries.next();
                builder.must(QueryBuilders.rangeQuery(entry.getKey()).lt(entry.getValue()));
            }
        }

        if(gtMap!=null && gtMap.size() > 0){
            Iterator<Map.Entry<String, String>> entries = gtMap.entrySet().iterator();
            while (entries.hasNext()) {
                Map.Entry<String, String> entry = entries.next();
                builder.must(QueryBuilders.rangeQuery(entry.getKey()).gt(entry.getValue()));
            }
        }
        sourceBuilder.query(builder);

        return sourceBuilder;
    }

//    public static SearchSourceBuilder GetSourceBuilder(Map<String, String> ltMap, Map<String, String> equalMap, Map<String, String> gtMap, int pageIndex, int pageSize){
//
//        SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
//        sourceBuilder.from(pageIndex);
//        sourceBuilder.size(pageSize);
////        sourceBuilder.fetchSource(new String[]{"id"}, new String[]{});
//
//
//        BoolQueryBuilder builder = QueryBuilders.boolQuery();
//
//
//        if(equalMap!=null && equalMap.size() > 0){
//            Iterator<Map.Entry<String, String>> entries = equalMap.entrySet().iterator();
//            while (entries.hasNext()) {
//                Map.Entry<String, String> entry = entries.next();
//                builder.must(QueryBuilders.matchQuery(entry.getKey(), entry.getValue()));
//            }
//        }
//
//        if(ltMap!=null && ltMap.size() > 0){
//            Iterator<Map.Entry<String, String>> entries = ltMap.entrySet().iterator();
//            while (entries.hasNext()) {
//                Map.Entry<String, String> entry = entries.next();
//                builder.must(QueryBuilders.rangeQuery(entry.getKey()).lt(entry.getValue()));
//            }
//        }
//
//        if(gtMap!=null && gtMap.size() > 0){
//            Iterator<Map.Entry<String, String>> entries = gtMap.entrySet().iterator();
//            while (entries.hasNext()) {
//                Map.Entry<String, String> entry = entries.next();
//                builder.must(QueryBuilders.rangeQuery(entry.getKey()).gt(entry.getValue()));
//            }
//        }
//        sourceBuilder.query(builder);
//
//        return sourceBuilder;
//    }


//    public static SearchSourceBuilder GetSourceLGBuilder(String esSql , int pageIndex, int pageSize){
//
//        //esSql = "select id, aa where (id >= 3 and aa in ('Adams','Carter')) or aa contains xx RDER BY Company DESC "
//        SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
//        sourceBuilder.from(pageIndex);
//        sourceBuilder.size(pageSize);
////        sourceBuilder.fetchSource(new String[]{"id"}, new String[]{});
//
//
//        BoolQueryBuilder builder = QueryBuilders.boolQuery();
//
//
//        if(equalMap!=null && equalMap.size() > 0){
//            Iterator<Map.Entry<String, String>> entries = equalMap.entrySet().iterator();
//            while (entries.hasNext()) {
//                Map.Entry<String, String> entry = entries.next();
//                builder.must(QueryBuilders.matchQuery(entry.getKey(), entry.getValue()));
//            }
//        }
//
//        if(ltMap!=null && ltMap.size() > 0){
//            Iterator<Map.Entry<String, String>> entries = ltMap.entrySet().iterator();
//            while (entries.hasNext()) {
//                Map.Entry<String, String> entry = entries.next();
//                builder.must(QueryBuilders.rangeQuery(entry.getKey()).lt(entry.getValue()));
//            }
//        }
//
//        if(gtMap!=null && gtMap.size() > 0){
//            Iterator<Map.Entry<String, String>> entries = gtMap.entrySet().iterator();
//            while (entries.hasNext()) {
//                Map.Entry<String, String> entry = entries.next();
//                builder.must(QueryBuilders.rangeQuery(entry.getKey()).gt(entry.getValue()));
//            }
//        }
//        sourceBuilder.query(builder);
//
//        return sourceBuilder;
//    }


}
