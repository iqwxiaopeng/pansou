package com.iqw.eserver.util;

import com.iqw.eserver.SysConstants;

public class FileTypeUtil {
    public static int getFileTypeByExt(String ext){
        if(ext .compareToIgnoreCase("bt") == 0){
            return SysConstants.FILE_TYPE_BT;
        }
        String  zip[] = {"zip", "tar", "rar", "gzip", "jar", "iso", "uue", "arj", "cab"};
        for(int i = 0; i < zip.length; i++) {
            if(zip[i].compareToIgnoreCase(ext) == 0){
                return SysConstants.FILE_TYPE_ZIP;
            }
        }
        String img[] = {"bmp", "jpg", "jpeg", "png", "tiff", "gif", "pcx", "tga", "exif", "fpx", "svg", "psd",
                "cdr", "pcd", "dxf", "ufo", "eps", "ai", "raw", "wmf"};
        for (int i = 0; i < img.length; i++) {
            if (img[i].compareToIgnoreCase(ext) == 0) {
                return SysConstants.FILE_TYPE_PIC;
            }
        }

        if("pdf".compareToIgnoreCase(ext)==0 ){
            return SysConstants.FILE_TYPE_PDF;
        }

        // 创建文档类型数组
        String document[] = { "txt", "doc", "docx", "xls", "htm", "html", "jsp", "rtf", "wpd",  "ppt" };
        for (int i = 0; i < document.length; i++) {
            if (document[i].compareToIgnoreCase(ext) == 0) {
                return SysConstants.FILE_TYPE_WORD;
            }
        }
        // 创建视频类型数组
        String video[] = { "qsv", "mp4", "avi", "mov", "wmv", "asf", "navi", "3gp", "mkv", "f4v", "rmvb", "webm" };
        for (int i = 0; i < video.length; i++) {
            if (video[i].compareToIgnoreCase(ext) == 0) {
                return SysConstants.FILE_TYPE_VIDEO;
            }
        }
        // 创建音乐类型数组
        String music[] = { "mp3", "wma", "wav", "mod", "ra", "cd", "md", "asf", "aac", "vqf", "ape", "mid", "ogg",
                "m4a", "vqf" };
        for(int i = 0; i < music.length; i++) {
            if (music[i].compareToIgnoreCase(ext) == 0) {
                return SysConstants.FILE_TYPE_MUSIC;
            }
        }
        return SysConstants.FILE_TYPE_UNKNOWN;
    }
}
