登录步骤:
1. LoginAuthenticationProcessingFilter,提取自定义的登录参数,初步进行验证,交由LoginAuthenticationManager认证
2. LoginAuthenticationManager 使用LoginAuthenticationProvider 验证器对用户进行验证
3. LoginAuthenticationProvider 使用UserDetailsServiceImpl加载自定义数据源数据进行校验,有数据则证明用户存在校验成功
4. 最终调用AuthenticationSuccessHandler处理校验成功,生成token,颁发给用户

权限步骤:
1. MyAuthenticationFilter 继承了 OncePerRequestFilter,除了登录外的url必然经过这个过滤器
   a. 提取token,如果没有token,则判断是否非拦截url,是则放行,否则抛出未登录异常
   b. 对提取到的token进行合法性检验,非法则抛异常,和法但接近则生成新的RefreshToken通过header给客户端
   c. 提取token包含的信息(这里是权限信息),透传信息给sercurity框架,以便其他过滤器能拿到
   d. 一切正常则继续让过滤器链往下走
2. UrlFilterInvocationSecurityMetadataSource,这个类主要是获取当前URL所需权限(NULL表示无需权限即可访问)
   a. 用[权限表]中的URL匹配当前用户访问的URL,如果匹配到,则从[角色权限表]获取当前访问URL所需要的角色权限
   b. 对于不在[权限表]的URL,统统放行
3. UrlAccessDecisionManager,这个类是对权限进行判定(2处理后的返回值[角色表]会以参数传进来,1处理后透传给security框架的数剧也会传递进来)
   a. 遍历URL访问所需的角色
   b. 比对token携带的角色信息,来匹配url角色
   c. 匹配到,证明角色具有访问权限,返回null,放行,否则抛异常

