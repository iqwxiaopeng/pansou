local json = require('scripts/json')

local lib = require('scripts/lib')
local dirmgr = dirmgr or {}



function dirmgr.New()
	local vdir =
	{
	    msg={flag=true},
	    file={flag=true},
	    pic={flag=true},
	    music={flag=true}
 	};

    return vdir;
end

function dirmgr.init(str)
   if not dirmgr.vdir then
        dirmgr.vdir = dirmgr.New();
   end
   --file = io.open("E:/mind_server/src/main/resources/scripts/cache.txt",'r');
   --print(file:read('*all'))
   if not dirmgr.TireTree then
    dirmgr.TireTree = json.decode(str);
   end
end

function dirmgr.KeyWord(str)
   local token = lib.SplitUtf8(str);
   return json.encode(token);
end


--增加一个关键字
function dirmgr.AddKeyWord(str)
   local curOp = dirmgr.TireTree;

   local token = lib.SplitUtf8(str);
   for _, v in pairs(token) do
  
         curOp[v] = curOp[v] or {}
         curOp = curOp[v];
   end
   curOp.flag = true;
   return json.encode(dirmgr.TireTree)
end


--移除一个关键词
function dirmgr.DelKeyWord(str)
   local curOp = dirmgr.TireTree;
   local lastKeyTb = curOp;
   local token = lib.SplitUtf8(str);
   local parentTable = {};

   for i = 1, #token do
        local key = token[i];
        table.insert(parentTable, curOp);
        curOp = curOp[key ]
        if(curOp == nil) then
            return json.encode(dirmgr.TireTree); --找不到关键字
        end
   end

   curOp.flag = nil;

    for i = #token, 1 ,-1 do
       local key = token[i];
       local parent = parentTable[i];

       lib.PrintTable(parent)
       if lib.ContainTable(parent[key]) or parent[key].flag ~=nil then
          return json.encode(dirmgr.TireTree);
       else
          parent[key] = nil;
       end
    end

   return json.encode(dirmgr.TireTree)
end

function dirmgr.ListKeyWordTable(var, str, findTb, num)

  if #findTb >= num then
    return
  end

  for k, v in pairs(var) do   
    local vType = type(v);
      if vType == "table" then

         if v.flag ~= nil then
          --print("list one ",str..k);
          table.insert(findTb, str..k);
         end

         dirmgr.ListKeyWordTable(v, str..k, findTb, num);
      end 
    end 

end

--查询一个关键词
function dirmgr.ListKeyWord(str, num)
   local findTb = {};
   local curOp = dirmgr.TireTree;

   local token = lib.SplitUtf8(str);

   local enKey = token[1];
   local c = string.byte(token[1], 1)
   

   if c > 0 and c <= 127 then --英文输入查询
      local enKey = token[1];
      for k, v in pairs(curOp) do
        _,flag = string.find(k, enKey);
        if flag ~= nil then
          table.insert(findTb, k);
        end
      end
      return json.encode(findTb);
   end

   for i = 1, #token do
        local key = token[i];
        curOp = curOp[key]
        if(curOp == nil) then
            return json.encode(findTb); --找不到关键字
        end
   end

   
    if curOp.flag == true then
       table.insert(findTb, str);
    end
 

   dirmgr.ListKeyWordTable(curOp, str, findTb, num)

   return json.encode(findTb)
end



function dirmgr.SplitByKeyWord(str)
   local wordTable = {};
   local curTree = dirmgr.TireTree;


   local token = lib.SplitUtf8(str);

   local startPos    = 1;
   local lastFindPos = 1;

   local i = 1;
   while (i <= #token) do      
      local key = token[i];
      if curTree[key] == nil then -- 解析树层次行进完毕 回溯 其它均继续行进

        print(i,"__",startPos ,"__", lastFindPos,"__notfind",key);
        local keyword=lib.MergeTableValue(token, startPos, lastFindPos)
        table.insert(wordTable, keyword)
        if i > lastFindPos then
          i = lastFindPos;
          print(i,"__",startPos ,"__", lastFindPos,"__sign_i",key);
        end 

        lastFindPos = lastFindPos + 1;
        startPos = lastFindPos;

        curTree = dirmgr.TireTree;
      else 
        if curTree[key].flag then
          lastFindPos = i;
          if(i >= #token) then
            local keyword=lib.MergeTableValue(token, startPos, lastFindPos)
            table.insert(wordTable, keyword)
          end
          print(i,"__",startPos ,"__", lastFindPos,"__key");
        else
          print(i,"__",startPos ,"__notkey");
        end
        curTree = curTree[key];
      end
      i = i + 1;
   end  

   return json.encode(wordTable)
end



function dirmgr.SurePath(path)
   local tbPath = lib.SplitStr(path, '/');
   local curDir = dirmgr.vdir;
   for _, dir in pairs(tbPath) do
        curDir[dir] = curDir[dir] or {};
        curDir = curDir[dir];
   end
   return curDir;
end

function dirmgr.AddFile(path, file, type)
   local opDir = dirmgr.SurePath(path);
   opDir.name=file;
   opDir.type = type;
   return json.encode(dirmgr.vdir)
end

function dirmgr.DelFile(path, file, type)
   local opDir = dirmgr.SurePath(path);
   print(json.encode(opDir));
   opDir.name = nil;
   opDir.type = nil;
   return json.encode(dirmgr.vdir)
end



return dirmgr