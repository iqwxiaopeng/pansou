local json = require('scripts/json')

local lib = require('scripts/lib')
local dirmgr2 = dirmgr2 or {}




function dirmgr2.init(str)

   if not dirmgr2.TireTreeTable then
      dirmgr2.TireTreeTable={};
      dirmgr2.ReverseTireTree = {};
   end
end

function dirmgr2.KeyWord(str)
   local token = lib.SplitUtf8(str);
   return json.encode(token);
end

--每一层均采用一个tire树组织为了支持模糊查询
function dirmgr2.AddLevelKeyWord(token, level)
  if(#token < level) then
    return;
  end
  dirmgr2.TireTreeTable[level] = dirmgr2.TireTreeTable[level] or {};
  local curOp = dirmgr2.TireTreeTable[level];
  local key = token[level];
  for i = level, #token do
    key = token[i];
    curOp[key] = curOp[key] or {}
    curOp = curOp[key];
  end
  curOp.flag = true;
end

--反转树增加关键词 为了支持模糊检索
function dirmgr2.AddReverseKeyWord(token)

  dirmgr2.ReverseTireTree = dirmgr2.ReverseTireTree or {};
  local curOp = dirmgr2.ReverseTireTree;
  local key = token[1];
  for i = #token, 1, -1 do
    key = token[i];
    curOp[key] = curOp[key] or {}
    curOp = curOp[key];
  end
  curOp.flag = true;
end

--增加一个关键字
function dirmgr2.AddKeyWord(str)
   --local curOp = dirmgr2.TireTree;

   local token = lib.SplitUtf8(str);
   for i = 1, #token do
  
        dirmgr2.AddLevelKeyWord(token, i)
   end

   dirmgr2.AddReverseKeyWord(token)
   
   return json.encode(dirmgr2.ReverseTireTree)
end

--错误关键词处理搜索不到的关键词
--parent 最后一个查证的表
--token  用户查询词
--i      出错的词下标
--num    推荐结果数
function dirmgr2.HandUnFind( parent, token, i, num)
    print(i, num); 
  -- body
    local findTb = {};
    local prefix = "";
    for z = 1, i-1 do 
      prefix = prefix..token[z];
    end 
    local sure  = {}; --更可靠的推荐
    local maybe = {}; --一般推荐
    local key = token[i];
    local c = string.byte(key, 1)
    if c > 0 and c <= 127 then  --遇到英文了 
      for k, v in pairs(parent) do
        _,flag = string.find(k, key);
        if flag ~= nil then
            if i < #token then
               if v[token[i+1]] ~= nil then
                if #sure < num then
                  table.insert(sure, k..token[i+1]);
                end
                 
               else
                 if #maybe < num then
                   table.insert(maybe, k);
                 end
                 
               end
            else
              if #maybe < num then
                table.insert(maybe, k);
              end
            end
        end
      end
    end

    for _, v in pairs(sure) do
      table.insert(findTb, prefix..v);
    end
    for _, v in pairs(maybe) do
      table.insert(findTb, prefix..v);
    end
    return  findTb;

end

--反转表取条目
function dirmgr2.ListReservseTable(var, str, findTb, num)
  if #findTb >= num then
    return
  end

  for k, v in pairs(var) do   
    local vType = type(v);
      if vType == "table" then
          local c1 = string.byte(str, 1);
         local c2 = string.byte(k, 1);

         if v.flag ~= nil then
          if lib.IsEnglish(c1) and lib.IsEnglish(c2) then
            table.insert(findTb, k.." "..str);
          else
            table.insert(findTb, k..str);
          end
          
         end
       
         if lib.IsEnglish(c1) and lib.IsEnglish(c2) then
          dirmgr2.ListReservseTable(v, k.." "..str, findTb, num);
         else
          dirmgr2.ListReservseTable(v, k..str, findTb, num);
         end
      end 
    end 

end


--反转树反转查询关键词 
function dirmgr2.ListReservse(tokenSet, num)

  local findTb = {};
  for k, v in pairs(tokenSet) do
    local curOp = dirmgr2.ReverseTireTree;
    local token = lib.SplitUtf8(v);
      for i = #token, 1, -1 do
        key = token[i];
        curOp = curOp[key];
        if curOp == nil then
          return {};
        end
      end
      if curOp.flag == true then --本身是一个关键词
        table.insert(findTb, v);
      end

      dirmgr2.ListReservseTable(curOp, v, findTb, num);

  end
  return findTb;

end

--参数 词  要返回的个数 第几个词开始 默认是从1级别
function dirmgr2.LikeKeyWordList(str, num, level)
  local findTb = {};
  if dirmgr2.TireTreeTable[level] == nil then
    return findTb, true;
  end
  
  local curOp = dirmgr2.TireTreeTable[level];
  local token = lib.SplitUtf8(str);
  local key = token[1];
  local parent = {};
   for i = 1, #token do
        local key = token[i];
        parent = curOp;
        curOp = curOp[key]
        if(curOp == nil) then
           findTb= dirmgr2.HandUnFind(parent, token, i, num)
           return findTb , true;
        end
   end

   if curOp.flag then
      table.insert(findTb, str);
   end
 
 print("___ LikeKeyWordList8888 ", num, level, str)


   dirmgr2.ListKeyWordTable(curOp, str, findTb, num)
   if level == 1 then
     return findTb, true;
   end 
     
   -- findTb = dirmgr2.ListReservse(findTb, num);
   --end
   return findTb, false

end

--参数 词  要返回的个数 第几个词开始 默认是从1级别
function dirmgr2.ListLikeKeyWord(str, num)
  local findTb = {};
  local reserTable = {};
  local tmpTable = {};

  for i = 1, #dirmgr2.TireTreeTable do
   
    
    local levelTable,breal= dirmgr2.LikeKeyWordList(str, num, i);

    for k, v in pairs(levelTable) do
       print("--- ListLikeKeyWord  ", v )
      if breal == false then
        reserTable[v] = true;
      else
        tmpTable[v] = true;
      end

      
    end


  end
  for k, _ in pairs(reserTable) do
    table.insert(findTb, k);
  end
  print("ni xiang chaxun ...")
  lib.PrintTable(findTb);

  findTb = dirmgr2.ListReservse(findTb, num);
  for k, _ in pairs(tmpTable) do
    table.insert(findTb, k);
  end

  for k, v in pairs(findTb) do
      tmpTable[v] = true;
  end
  findTb = {};
  for k, _ in pairs(tmpTable) do
    table.insert(findTb, k);
  end


  return json.encode(findTb);

end



--查询一个关键词
function dirmgr2.ListKeyWord(str, num)
   local findTb = {};
   local curOp = dirmgr2.TireTree;

   local token = lib.SplitUtf8(str);

   local enKey = token[1];
   local c = string.byte(token[1], 1)
   

   if c > 0 and c <= 127 then --英文输入查询
      local enKey = token[1];
      for k, v in pairs(curOp) do
        _,flag = string.find(k, enKey);
        if flag ~= nil then
          table.insert(findTb, k);
        end
      end
      return json.encode(findTb);
   end

   for i = 1, #token do
        local key = token[i];
        curOp = curOp[key]
        if(curOp == nil) then
            return json.encode(findTb); --找不到关键字
        end
   end

   
    if curOp.flag == true then
       table.insert(findTb, str);
    end
 

   dirmgr2.ListKeyWordTable(curOp, str, findTb, num)

   return json.encode(findTb)
end



--移除一个关键词
function dirmgr2.DelLevelKeyWord(TireTree, token, level)
   if TireTree == nil then
    return false
  end

   local curOp = TireTree;
   local lastKeyTb = curOp;
   
   local parentTable = {};

   for i = level, #token do
        local key = token[i];
        table.insert(parentTable, curOp);
        curOp = curOp[key]
        if(curOp == nil) then
            return false; --找不到关键字
        end
   end

   curOp.flag = nil;

    for i = #token, level ,-1 do
       local key = token[i];
       local parent = parentTable[i-level + 1];

       --lib.PrintTable(parent)
       if lib.ContainTable(parent[key]) or parent[key].flag ~=nil then
          return false;
       else
          parent[key] = nil;
       end
    end

   return true
end

--移除一个关键词
function dirmgr2.DelKeyWord(str)
   local token = lib.SplitUtf8(str);
   

   for i = 1, #dirmgr2.TireTreeTable do
      dirmgr2.DelLevelKeyWord(dirmgr2.TireTreeTable[i],token, i);
   end

   local reverToken = {};
   for i=#token,1,-1 do
      table.insert(reverToken, token[i]);
   end
   dirmgr2.DelLevelKeyWord(dirmgr2.ReverseTireTree, reverToken, 1);

   return true
end



function dirmgr2.ListKeyWordTable(var, str, findTb, num)
  local c1 = string.byte(str, string.len(str));
  if #findTb >= num then
    return
  end

  for k, v in pairs(var) do   
    local vType = type(v);
      if vType == "table" then
         local c2 = string.byte(k,1);

         if v.flag ~= nil then
            print("LikeKeyWordList c 1  c 2", c1, c2)
            if lib.IsEnglish(c1) and lib.IsEnglish(c2) then
              table.insert(findTb, str.." "..k);
            else
              table.insert(findTb, str..k);
            end
         end
          if lib.IsEnglish(c1) and lib.IsEnglish(c2) then
             dirmgr2.ListKeyWordTable(v, str.." "..k, findTb, num);

          else
             dirmgr2.ListKeyWordTable(v, str..k, findTb, num);

          end


      end 
    end 

end



--[[

function dirmgr2.SplitByKeyWord(str)
   local wordTable = {};
   local curTree = dirmgr2.TireTree;


   local token = lib.SplitUtf8(str);

   local startPos    = 1;
   local lastFindPos = 1;

   local i = 1;
   while (i <= #token) do      
      local key = token[i];
      if curTree[key] == nil then -- 解析树层次行进完毕 回溯 其它均继续行进

        print(i,"__",startPos ,"__", lastFindPos,"__notfind",key);
        local keyword=lib.MergeTableValue(token, startPos, lastFindPos)
        table.insert(wordTable, keyword)
        if i > lastFindPos then
          i = lastFindPos;
          print(i,"__",startPos ,"__", lastFindPos,"__sign_i",key);
        end 

        lastFindPos = lastFindPos + 1;
        startPos = lastFindPos;

        curTree = dirmgr2.TireTree;
      else 
        if curTree[key].flag then
          lastFindPos = i;
          if(i >= #token) then
            local keyword=lib.MergeTableValue(token, startPos, lastFindPos)
            table.insert(wordTable, keyword)
          end
          print(i,"__",startPos ,"__", lastFindPos,"__key");
        else
          print(i,"__",startPos ,"__notkey");
        end
        curTree = curTree[key];
      end
      i = i + 1;
   end  

   return json.encode(wordTable)
end



function dirmgr2.SurePath(path)
   local tbPath = lib.SplitStr(path, '/');
   local curDir = dirmgr2.vdir;
   for _, dir in pairs(tbPath) do
        curDir[dir] = curDir[dir] or {};
        curDir = curDir[dir];
   end
   return curDir;
end

function dirmgr2.AddFile(path, file, type)
   local opDir = dirmgr2.SurePath(path);
   opDir.name=file;
   opDir.type = type;
   return json.encode(dirmgr2.vdir)
end

function dirmgr2.DelFile(path, file, type)
   local opDir = dirmgr2.SurePath(path);
   print(json.encode(opDir));
   opDir.name = nil;
   opDir.type = nil;
   return json.encode(dirmgr2.vdir)
end
]]


return dirmgr2