local fileutil = fileutil or {}
function fileutil.SplitPath(path)
    local spliter = '/'
    local tbTokenElem = {};
    local nStart = 1;
    local nAt = string.find(path, spliter);
    while nAt do
        if nAt~= nStart then
            tbTokenElem[#tbTokenElem+1] = string.sub(path, nStart, nAt - 1);
        end
        nStart = nAt + 1;
        nAt = string.find(path, spliter, nStart);
    end
    tbTokenElem[#tbTokenElem+1] = string.sub(path, nStart);
    return tbTokenElem;
end




return fileutil;
