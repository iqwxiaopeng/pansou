local lib = lib or {}
function lib.SplitStr(szStrConcat, szSep)
	if (not szSep) then
		szSep = ",";
	end;
	local tbStrElem = {};

	--特殊转义字符指定长度
	local tbSpeSep = {
		["%."] = 1;
	};

	local nSepLen = tbSpeSep[szSep] or #szSep;
	local nStart = 1;
	local nAt = string.find(szStrConcat, szSep);
	while nAt do
		tbStrElem[#tbStrElem+1] = string.sub(szStrConcat, nStart, nAt - 1);
		nStart = nAt + nSepLen;
		nAt = string.find(szStrConcat, szSep, nStart);
	end
	tbStrElem[#tbStrElem+1] = string.sub(szStrConcat, nStart);
	return tbStrElem;
end

function lib.Utf8CharBytes(s, i)
   -- argument defaults
   i = i or 1
   local c = string.byte(s, i)

   -- determine bytes needed for character, based on RFC 3629
   if c > 0 and c <= 127 then
      -- UTF8-1
      return 1
   elseif c >= 194 and c <= 223 then
      -- UTF8-2
      local c2 = string.byte(s, i + 1)
      return 2
   elseif c >= 224 and c <= 239 then
      -- UTF8-3
      local c2 = s:byte(i + 1)
      local c3 = s:byte(i + 2)
      return 3
   elseif c >= 240 and c <= 244 then
      -- UTF8-4
      local c2 = s:byte(i + 1)
      local c3 = s:byte(i + 2)
      local c4 = s:byte(i + 3)
      return 4
   end
end

-- returns the number of characters in a UTF-8 string
   function lib.Utf8Len(s)
      local pos = 1
      local bytes = string.len(s)
      local len = 0

      while pos <= bytes and len ~= chars do
         local c = string.byte(s,pos)
         len = len + 1

         pos = pos + lib.Utf8CharBytes(s, pos)
      end

      if chars ~= nil then
         return pos - 1
      end

      return len
   end


   -- returns the number of characters in a UTF-8 string
   function lib.SplitUtf81(s)
      local token = {};
      local pos = 1
      local bytes = string.len(s)
      local len = 0
      local curIdx = 0;
      local key = "";

      while pos <= bytes do
         len = lib.Utf8CharBytes(s, pos);
         local step = len;
         while(len == 1 and pos+step <= bytes) do
             len = lib.Utf8CharBytes(s, pos + step);
             step = step + len;
         end

         if step > len and len > 1 then --句子中间
              local c = string.sub(s, pos, pos + step - len - 1);
              table.insert(token, c);
              pos = pos + step - len;
              c = string.sub(s, pos, pos + len - 1);
              table.insert(token, c);
              pos = pos + len;
         else --句子到头了
              local c = string.sub(s, pos, pos + step - 1);
              table.insert(token, c);
              pos = pos + step;
         end
      end

      return token;
   end


   function lib.IsLeagelLetter( c )
   	if( (c >= '0' and c <= '9') or
   		(c >= 'a' and c <= 'z') or
   		(c >= 'A' and c <= 'Z')) then
        return true
    else
    	return false
    end
   end

   function lib.IsLeagelUtf8Letter(c )
   	if ((c == " " )or (c == "：") or (c == "？") or (c == "　") or (c == "；") or (c == "【") or (c == "】") ) then
        return false
    else
    	return true
    end
   end


   function lib.IsEnglish( c )
    if c > 0 and c <= 127 then
    
        return true
    else
      return false
    end
   end
   
  -- returns the number of characters in a UTF-8 string
  function lib.SplitUtf8(s)
     local token = {};
     local pos = 1
     local bytes = string.len(s)
     local len = 0
     local key = "";

     while pos <= bytes do
        len = lib.Utf8CharBytes(s, pos);
   
        local c = string.sub(s, pos, pos + len -1);
        if len == 1 then
           if  not lib.IsLeagelLetter(c) then
               if key ~= "" then
                  table.insert(token, key);
                  key = "";
               end
           else
               key = key..string.lower(c);
           end
        else
           if key ~= "" then
               table.insert(token, key);
               key = "";
           end

           if lib.IsLeagelUtf8Letter(c) then
           		table.insert(token, c);
       		end
        end
        pos = pos + len;

     end

     if key ~= "" then
           table.insert(token, key);
           key = "";
     end

     return token;
  end

  function lib.PrintTable(tb)
    print("--------PrintTable----------")
  	for k, v in pairs(tb) do
  		print(k, v)
  	end
  end

  function lib.MergeTableValue(tb, i, j)
  	local key = "";
  	for k=i, j do
  		key = key..tb[k]
  	end
  	return key;
  end

function lib.ContainTable (tb)
    for k,v in pairs(tb) do
        if type(v) == "table" then
        print(k, v,"containtable true")
            return true
        end
    end
    return false
end

function lib.ContainMoreTable (tb)
    local i = 0;
    for k,v in pairs(tb) do
        if type(v) == "table" then
            i = i + 1;
            if(i > 1) then
               return true;
            end
        end
    end

    return false
end

function CopyTB(tb)
	local tbCopy	= {};
	for k, v in pairs(tb) do
		if type(v) == "table" then
			tbCopy[k]	= CopyTB(v);
		else
			tbCopy[k]	= v;
		end
	end;
	return tbCopy;
end



function lib.print_r ( t )
    local print_r_cache={}
    local function sub_print_r(t,indent)
        if (print_r_cache[tostring(t)]) then
            print(indent.."*"..tostring(t))
        else
            print_r_cache[tostring(t)]=true
            if (type(t)=="table") then
                local tLen = #t
                for i = 1, tLen do
                    local val = t[i]
                    if (type(val)=="table") then
                        print(indent.."#["..i.."] => "..tostring(t).." {")
                        sub_print_r(val,indent..string.rep(" ",string.len(i)+8))
                        print(indent..string.rep(" ",string.len(i)+6).."}")
                    elseif (type(val)=="string") then
                        print(indent.."#["..i..'] => "'..val..'"')
                    else
                        print(indent.."#["..i.."] => "..tostring(val))
                    end
                end
                for pos,val in pairs(t) do
                    if type(pos) ~= "number" or math.floor(pos) ~= pos or (pos < 1 or pos > tLen) then
                        if (type(val)=="table") then
                            print(indent.."["..pos.."] => "..tostring(t).." {")
                            sub_print_r(val,indent..string.rep(" ",string.len(pos)+8))
                            print(indent..string.rep(" ",string.len(pos)+6).."}")
                        elseif (type(val)=="string") then
                            print(indent.."["..pos..'] => "'..val..'"')
                        else
                            print(indent.."["..pos.."] => "..tostring(val))
                        end
                    end
                end
            else
                print(indent..tostring(t))
            end
        end
    end

    if (type(t)=="table") then
        print(tostring(t).." {")
        sub_print_r(t,"  ")
        print("}")
    else
        sub_print_r(t,"  ")
    end

    print()
end


return lib