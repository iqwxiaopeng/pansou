//package com.iqw.eserver;
//
//
//import com.iqw.eserver.util.EsOperatorUtil;
//
//import org.junit.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//
//import java.io.IOException;
//
//@SpringBootTest
//class EserverApplicationTests {
//    @Autowired
//    private EsOperatorUtil util;
//    @Test
//    void contextLoads() {
//        try {
//            util.ExistsIndex("megacorp");
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }
//
//}
