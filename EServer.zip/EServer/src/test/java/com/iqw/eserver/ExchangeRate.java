package com.iqw.eserver;

import java.util.Date;

public class ExchangeRate {
    private String fromCurrency;
    private String toCurrency;
    private Date fromDate;
    private Date thruDate;
    private double rate;
}