package com.iqw.eserver;

import org.josql.Query;
import org.josql.QueryParseException;
import com.iqw.eserver.ExchangeRate;

public class josqltest {
    public static void main(String [] arg) throws QueryParseException {
        Query q = new Query();
        q.parse("SELECT aa,bb FROM com.iqw.eserver.ExchangeRate WHERE LastName IN ('Adams','Carter') and age >= 23 and age < 26 and money between 20 and 30");
        q.getWhereClause();
//        q.setVariable("fromCurrency", fromCurrency);
//        q.setVariable("toCurrency", toCurrency);
//        q.setVariable("when", date);
//        return q.execute(getAllExchangeRates()).getResults().get(0).getRate()

    }
}
